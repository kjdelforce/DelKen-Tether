import { pgTable, text, timestamp, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

/**
 * pushSubscriptions
 * ──────────────────
 * One row per (user_id, browser/device) pair. The triple
 * (endpoint, p256dh, auth) is the full Web Push subscription as
 * returned by `pushManager.subscribe()` on the client.
 *
 * `tetherId` is denormalised onto the row so the api-server can find
 * "all subscriptions belonging to my partner" with a single query
 * (`WHERE tether_id = $1 AND user_id <> $2`) without having to look
 * anything up in the (separate) Supabase database where profiles live.
 *
 * `endpoint` is unique — re-subscribing the same browser produces the
 * same endpoint string, and we want to upsert (refresh keys / tether)
 * rather than insert duplicates.
 */
export const pushSubscriptions = pgTable(
  "push_subscriptions",
  {
    endpoint:  text("endpoint").primaryKey(),
    userId:    text("user_id").notNull(),
    tetherId:  text("tether_id").notNull(),
    p256dh:    text("p256dh").notNull(),
    auth:      text("auth").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => ({
    // Hot lookup path: "find subscriptions for the partner inside this
    // tether" runs on every push trigger.
    byTether: index("push_subscriptions_tether_user_idx").on(t.tetherId, t.userId),
  }),
);

export const insertPushSubscriptionSchema = createInsertSchema(pushSubscriptions).omit({
  createdAt: true,
  updatedAt: true,
});
export type InsertPushSubscription = z.infer<typeof insertPushSubscriptionSchema>;
export type PushSubscription = typeof pushSubscriptions.$inferSelect;
