import { Router, type IRouter, type Request, type Response } from "express";
import webpush from "web-push";
import { and, eq, ne } from "drizzle-orm";
import { db, pushSubscriptions } from "@workspace/db";
import { logger } from "../lib/logger";

const router: IRouter = Router();

// ── VAPID configuration ───────────────────────────────────────────
// Keys live in shared environment variables (set via the secrets
// system). The client receives the public half through the vite
// `import.meta.env.VITE_VAPID_PUBLIC_KEY` build-time define; the
// private half stays on the server. If any are missing we log once
// and silently no-op every push trigger so the app keeps working
// even if push isn't configured.
const VAPID_PUBLIC  = process.env["VAPID_PUBLIC_KEY"];
const VAPID_PRIVATE = process.env["VAPID_PRIVATE_KEY"];
const VAPID_SUBJECT = process.env["VAPID_SUBJECT"] ?? "mailto:tether@example.com";

let pushReady = false;
if (VAPID_PUBLIC && VAPID_PRIVATE) {
  webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC, VAPID_PRIVATE);
  pushReady = true;
  logger.info("[push] VAPID configured — push notifications enabled");
} else {
  logger.warn(
    { hasPublic: Boolean(VAPID_PUBLIC), hasPrivate: Boolean(VAPID_PRIVATE) },
    "[push] VAPID keys missing — push triggers will no-op",
  );
}

// ── Body shapes ───────────────────────────────────────────────────
interface SubscribeBody {
  userId?: unknown;
  tetherId?: unknown;
  subscription?: {
    endpoint?: unknown;
    keys?: { p256dh?: unknown; auth?: unknown };
  };
}

interface PushTriggerBody {
  tetherId?: unknown;
  senderId?: unknown;
  senderName?: unknown;
}

function asString(v: unknown): string | null {
  return typeof v === "string" && v.length > 0 ? v : null;
}

// ── POST /api/push/subscribe ──────────────────────────────────────
// Stores (or refreshes) a Web Push subscription for the given user
// inside the given tether. Idempotent on `endpoint` — re-subscribing
// the same browser updates the keys / tether mapping rather than
// creating duplicates.
router.post("/push/subscribe", async (req: Request, res: Response) => {
  const body = req.body as SubscribeBody;
  const userId   = asString(body.userId);
  const tetherId = asString(body.tetherId);
  const endpoint = asString(body.subscription?.endpoint);
  const p256dh   = asString(body.subscription?.keys?.p256dh);
  const auth     = asString(body.subscription?.keys?.auth);

  if (!userId || !tetherId || !endpoint || !p256dh || !auth) {
    return res.status(400).json({ error: "Missing required subscription fields" });
  }

  try {
    // Drizzle's onConflictDoUpdate handles the "already subscribed"
    // case — refreshes the keys + tether and bumps updated_at.
    await db
      .insert(pushSubscriptions)
      .values({ endpoint, userId, tetherId, p256dh, auth })
      .onConflictDoUpdate({
        target: pushSubscriptions.endpoint,
        set: { userId, tetherId, p256dh, auth, updatedAt: new Date() },
      });

    return res.status(204).end();
  } catch (err) {
    logger.error({ err }, "[push] Failed to store subscription");
    return res.status(500).json({ error: "Failed to store subscription" });
  }
});

// ── Delivery helper ───────────────────────────────────────────────
// Sends `payload` to every subscription matching (tether_id = X AND
// user_id != senderId). Subscriptions that come back as 404/410 are
// expired and quietly removed from the table.
async function deliverToPartner(
  tetherId: string,
  senderId: string,
  payload: Record<string, unknown>,
): Promise<{ sent: number; pruned: number; total: number }> {
  if (!pushReady) {
    logger.warn("[push] deliverToPartner called but VAPID not configured");
    return { sent: 0, pruned: 0, total: 0 };
  }

  const recipients = await db
    .select()
    .from(pushSubscriptions)
    .where(
      and(eq(pushSubscriptions.tetherId, tetherId), ne(pushSubscriptions.userId, senderId)),
    );

  if (recipients.length === 0) return { sent: 0, pruned: 0, total: 0 };

  const body = JSON.stringify(payload);
  let sent = 0;
  let pruned = 0;

  await Promise.all(
    recipients.map(async (sub) => {
      try {
        await webpush.sendNotification(
          { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
          body,
        );
        sent += 1;
      } catch (err: unknown) {
        const statusCode = (err as { statusCode?: number })?.statusCode;
        // 404 (Not Found) and 410 (Gone) mean the browser/device has
        // unsubscribed permanently — remove the dead row so we don't
        // keep retrying.
        if (statusCode === 404 || statusCode === 410) {
          await db.delete(pushSubscriptions).where(eq(pushSubscriptions.endpoint, sub.endpoint));
          pruned += 1;
        } else {
          logger.warn({ err, statusCode, endpoint: sub.endpoint }, "[push] Send failed");
        }
      }
    }),
  );

  return { sent, pruned, total: recipients.length };
}

// ── Trigger factory ───────────────────────────────────────────────
// Each named trigger (love, whisper, trivia, daily-connection) sends
// a different title/body/tag/screen but otherwise shares the same
// validation + delivery path. Everything is wrapped in a try/catch
// so a single bad push never bubbles a 500 to the client (which
// would surface as a console error in the user's browser).
function trigger(
  endpoint: string,
  buildPayload: (senderName: string | null) => Record<string, unknown>,
) {
  router.post(endpoint, async (req: Request, res: Response) => {
    const body     = req.body as PushTriggerBody;
    const tetherId = asString(body.tetherId);
    const senderId = asString(body.senderId);
    const senderName = asString(body.senderName);

    if (!tetherId || !senderId) {
      return res.status(400).json({ error: "tetherId and senderId are required" });
    }

    try {
      const result = await deliverToPartner(tetherId, senderId, buildPayload(senderName));
      return res.json(result);
    } catch (err) {
      logger.error({ err, endpoint }, "[push] Trigger failed");
      return res.status(500).json({ error: "Push delivery failed" });
    }
  });
}

// Notification copy is intentionally short and warm — kept under
// 50 characters so iOS lock screens display the full message
// without truncation.
trigger("/push/love", (name) => ({
  title: "💖 A pulse from your Tether",
  body:  name ? `${name} sent you love` : "Someone is thinking of you",
  tag:   "tether-love",
  screen: "home",
}));

trigger("/push/whisper", (name) => ({
  title: "👻 A whisper appeared",
  body:  name ? `${name} left you a secret thought` : "A new whisper is waiting for you",
  tag:   "tether-whisper",
  screen: "home",
}));

trigger("/push/trivia", (name) => ({
  title: "✨ Your turn",
  body:  name ? `${name} answered today's trivia` : "Today's trivia is waiting",
  tag:   "tether-trivia",
  screen: "games",
}));

trigger("/push/daily-connection", (name) => ({
  title: "🪞 Today's connection",
  body:  name ? `${name} answered today's prompt` : "Today's connection prompt is ready",
  tag:   "tether-daily",
  screen: "home",
}));

trigger("/push/love-note", (name) => ({
  title: "💌 A note is waiting",
  body:  name ? `${name} left you a sealed note` : "A sealed note is waiting on your Home screen",
  tag:   "tether-love-note",
  screen: "home",
}));

// ── Two Truths One Lie ────────────────────────────────────────────
// Three event types share one tag so a fresh notification replaces
// the previous one on the lock screen instead of stacking up.
trigger("/push/two-truths-new-round", (name) => ({
  title: "🎭 Two Truths One Lie",
  body:  name
    ? `${name} has written their statements — can you spot the lie?`
    : "Your turn to spot the lie",
  tag:   "tether-two-truths",
  screen: "games",
}));

trigger("/push/two-truths-your-turn", (name) => ({
  title: "🎭 Two Truths One Lie",
  body:  name
    ? `Your turn to write — ${name} wants to guess.`
    : "Your turn to write",
  tag:   "tether-two-truths",
  screen: "games",
}));

// Guess-result notification needs an extra `correct` flag so the
// writer's lock-screen body reflects whether the lie was spotted
// or fell for. Inlined (rather than going through the trigger
// factory) because the factory only takes senderName.
router.post("/push/two-truths-guess", async (req: Request, res: Response) => {
  const body = req.body as PushTriggerBody & { correct?: unknown };
  const tetherId   = asString(body.tetherId);
  const senderId   = asString(body.senderId);
  const senderName = asString(body.senderName);
  const correct    = body.correct === true;

  if (!tetherId || !senderId) {
    return res.status(400).json({ error: "tetherId and senderId are required" });
  }

  try {
    const result = await deliverToPartner(tetherId, senderId, {
      title: "🎭 Two Truths One Lie",
      body:  senderName
        ? (correct
            ? `${senderName} spotted your lie! See the result.`
            : `${senderName} fell for it! See the result.`)
        : (correct ? "Your lie was spotted" : "They fell for your lie"),
      tag:   "tether-two-truths",
      screen: "games",
    });
    return res.json(result);
  } catch (err) {
    logger.error({ err }, "[push] two-truths-guess failed");
    return res.status(500).json({ error: "Push delivery failed" });
  }
});

export default router;
