import { Router, type IRouter, type Request, type Response } from "express";
import { logger } from "../lib/logger";

// ── Anthropic proxy ───────────────────────────────────────────────
// The pasted vanilla JS in the original spec called the Messages
// API directly from the browser with no auth header. That cannot
// work: Anthropic blocks browser-origin calls (no CORS allow-list)
// AND the API key would be shipped to the client on every load,
// which is an immediate leak. Instead the client posts to this
// route and we forward the request server-side using the secret.
//
// The wire format is intentionally minimal: { systemPrompt, messages }.
// We do not stream — the daily insight + chat replies are short
// enough that a single JSON response is simpler and equally fast.
const router: IRouter = Router();

const ANTHROPIC_API_KEY = process.env["ANTHROPIC_API_KEY"];
const ANTHROPIC_MODEL = "claude-sonnet-4-20250514";
const ANTHROPIC_VERSION = "2023-06-01";
const MAX_TOKENS = 1024;

if (!ANTHROPIC_API_KEY) {
  logger.warn(
    "[ai] ANTHROPIC_API_KEY missing — /api/ai/chat will return 503",
  );
} else {
  logger.info("[ai] Anthropic proxy ready");
}

interface AIMessage {
  role: "user" | "assistant";
  content: string;
}

interface ChatBody {
  systemPrompt?: unknown;
  messages?: unknown;
}

function isValidMessage(m: unknown): m is AIMessage {
  if (!m || typeof m !== "object") return false;
  const obj = m as { role?: unknown; content?: unknown };
  return (
    (obj.role === "user" || obj.role === "assistant") &&
    typeof obj.content === "string" &&
    obj.content.length > 0 &&
    obj.content.length < 8000
  );
}

router.post("/ai/chat", async (req: Request, res: Response) => {
  if (!ANTHROPIC_API_KEY) {
    res.status(503).json({ error: "AI is not configured" });
    return;
  }

  const body = req.body as ChatBody;
  const systemPrompt =
    typeof body.systemPrompt === "string" ? body.systemPrompt : "";
  const rawMessages = Array.isArray(body.messages) ? body.messages : [];
  const messages = rawMessages.filter(isValidMessage);

  if (messages.length === 0) {
    res.status(400).json({ error: "messages array required" });
    return;
  }

  // Cap conversation length to avoid runaway token cost.
  const trimmed = messages.slice(-20);

  try {
    const upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": ANTHROPIC_VERSION,
      },
      body: JSON.stringify({
        model: ANTHROPIC_MODEL,
        max_tokens: MAX_TOKENS,
        system: systemPrompt,
        messages: trimmed,
      }),
    });

    if (!upstream.ok) {
      const errText = await upstream.text();
      logger.error(
        { status: upstream.status, body: errText.slice(0, 400) },
        "[ai] upstream error",
      );
      res
        .status(502)
        .json({ error: "AI upstream failed", status: upstream.status });
      return;
    }

    const data = (await upstream.json()) as {
      content?: Array<{ type?: string; text?: string }>;
    };
    // The Messages API returns an array of content blocks; we only
    // care about text blocks. Concatenate them in order so multi-block
    // responses come through intact.
    const reply =
      data.content
        ?.filter((b) => b.type === "text" && typeof b.text === "string")
        .map((b) => b.text!)
        .join("\n")
        .trim() ?? "";

    if (!reply) {
      logger.warn({ data }, "[ai] empty reply from upstream");
      res.status(502).json({ error: "Empty reply" });
      return;
    }

    res.json({ reply });
  } catch (err) {
    logger.error({ err }, "[ai] proxy threw");
    res.status(500).json({ error: "AI proxy error" });
  }
});

export default router;
