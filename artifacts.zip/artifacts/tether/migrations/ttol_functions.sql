-- ─────────────────────────────────────────────────────────────────────────────
-- Two Truths One Lie — fix-up SQL
--
-- Tether uses its own invite-code auth (not Supabase Auth), so
-- auth.uid() is always NULL. The previous policies / functions
-- gated on auth.uid() and could therefore never succeed. This
-- file:
--   1. Drops the unworkable RLS policies and disables RLS on the
--      two_truths_rounds table (matches the rest of the app's
--      "trust the anon key" model — every other table is the
--      same).
--   2. Recreates the helper functions WITHOUT the auth.uid()
--      check, so the writer_id / guesser_id passed by the
--      client is what the row records.
-- Run the whole file in the Supabase SQL Editor.
-- ─────────────────────────────────────────────────────────────────────────────

-- ── 1. Drop policies + disable RLS so SELECTs work for realtime ──────────────
DROP POLICY IF EXISTS "Partners can read their rounds"   ON two_truths_rounds;
DROP POLICY IF EXISTS "Writers can insert rounds"        ON two_truths_rounds;
DROP POLICY IF EXISTS "Guessers can update their guess"  ON two_truths_rounds;
ALTER TABLE two_truths_rounds DISABLE ROW LEVEL SECURITY;


-- ── 2. Insert function — no auth.uid() check ─────────────────────────────────
CREATE OR REPLACE FUNCTION ttol_insert_round(
  p_couple_id    UUID,
  p_writer_id    UUID,
  p_guesser_id   UUID,
  p_statement_1  TEXT,
  p_statement_2  TEXT,
  p_statement_3  TEXT,
  p_lie_index    INTEGER
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id UUID;
BEGIN
  INSERT INTO two_truths_rounds (
    couple_id, writer_id, guesser_id,
    statement_1, statement_2, statement_3,
    lie_index
  ) VALUES (
    p_couple_id, p_writer_id, p_guesser_id,
    p_statement_1, p_statement_2, p_statement_3,
    p_lie_index
  )
  RETURNING id INTO v_id;
  RETURN v_id;
END;
$$;

GRANT EXECUTE ON FUNCTION ttol_insert_round TO anon, authenticated;


-- ── 3. Submit-guess function — no auth.uid() check ───────────────────────────
CREATE OR REPLACE FUNCTION ttol_submit_guess(
  p_round_id    UUID,
  p_guess_index INTEGER
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE two_truths_rounds
  SET guess_index = p_guess_index,
      guessed_at  = NOW(),
      status      = 'completed'
  WHERE id = p_round_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Round not found';
  END IF;
END;
$$;

GRANT EXECUTE ON FUNCTION ttol_submit_guess TO anon, authenticated;
