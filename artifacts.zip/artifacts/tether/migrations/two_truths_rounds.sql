-- ─────────────────────────────────────────────────────────────────────────────
-- Two Truths One Lie — Mind Games card
--
-- Tether uses its own invite-code auth model (not Supabase Auth),
-- so auth.uid() is always NULL inside Postgres. RLS policies that
-- depend on auth.uid() therefore can never succeed. This file
-- creates the table WITHOUT RLS — matching the rest of the app's
-- "trust the anon key" model. Writes are funnelled through the
-- helpers in ttol_functions.sql.
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS two_truths_rounds (
  id           UUID         DEFAULT gen_random_uuid() PRIMARY KEY,
  couple_id    UUID         REFERENCES tethers(id)  ON DELETE CASCADE,
  writer_id    UUID         REFERENCES profiles(id) ON DELETE CASCADE,
  guesser_id   UUID         REFERENCES profiles(id) ON DELETE CASCADE,
  statement_1  TEXT         NOT NULL,
  statement_2  TEXT         NOT NULL,
  statement_3  TEXT         NOT NULL,
  lie_index    INTEGER      NOT NULL CHECK (lie_index   IN (0, 1, 2)),
  guess_index  INTEGER               CHECK (guess_index IN (0, 1, 2)),
  guessed_at   TIMESTAMPTZ,
  created_at   TIMESTAMPTZ  DEFAULT NOW(),
  status       TEXT         DEFAULT 'waiting_for_guess'
                            CHECK (status IN ('waiting_for_guess', 'completed'))
);

CREATE INDEX IF NOT EXISTS two_truths_rounds_couple_status_idx
  ON two_truths_rounds (couple_id, status, created_at DESC);

-- No RLS (matches the rest of this app's tables).
ALTER TABLE two_truths_rounds DISABLE ROW LEVEL SECURITY;

-- Realtime broadcasts INSERT/UPDATE for this table
ALTER PUBLICATION supabase_realtime ADD TABLE two_truths_rounds;
