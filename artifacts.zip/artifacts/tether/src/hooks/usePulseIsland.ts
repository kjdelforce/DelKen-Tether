import { useEffect, useRef } from "react";
import { supabase } from "@/lib/supabaseClient";
import { useAuth } from "@/lib/AuthContext";
import { showPulseIsland } from "@/lib/dynamicIsland";
import { triggerHeartbeatPulse } from "@/components/HeartbeatPulseBorder";
import type { RealtimePostgresInsertPayload } from "@supabase/supabase-js";

interface LoveMessageRow {
  id:         string;
  sender_id:  string;
  read_at:    string | null;
  created_at: string;
}

/**
 * usePulseIsland — global Supabase realtime listener for incoming
 * pulses. Mounted once inside `<AppShell/>` so the island fires no
 * matter which page is active.
 *
 * Lives ALONGSIDE `useUnreadLoveYou` (which only mounts on Home and
 * shows the full-screen receive overlay). The island is intentionally
 * brief — a passing acknowledgement, not a modal.
 *
 * De-duplicates on row id so React StrictMode double-mounts and
 * re-subscriptions can't double-fire.
 */
export function usePulseIsland() {
  const { profile, partnerProfile, tether } = useAuth();
  const seenIds = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (!tether?.id || !partnerProfile?.id || !profile?.id) return;

    const partnerId = partnerProfile.id;
    const partnerName = partnerProfile.full_name?.split(" ")[0];
    const tetherId = tether.id;

    const channel = supabase
      .channel(`pulse_island_${tetherId}`)
      .on(
        "postgres_changes",
        {
          event:  "INSERT",
          schema: "public",
          table:  "love_messages",
          filter: `tether_id=eq.${tetherId}`,
        },
        (payload: RealtimePostgresInsertPayload<LoveMessageRow>) => {
          const row = payload.new;
          if (!row || row.sender_id !== partnerId) return;
          if (seenIds.current.has(row.id)) return;
          seenIds.current.add(row.id);
          // Cap memory: drop oldest after 50 entries.
          if (seenIds.current.size > 50) {
            const first = seenIds.current.values().next().value as string | undefined;
            if (first) seenIds.current.delete(first);
          }
          showPulseIsland(partnerName);
          // Heartbeat border ripples around the screen on the receiver's
          // device — a soft, organic "their pulse just landed" cue that
          // complements the dynamic island and the receive overlay.
          triggerHeartbeatPulse();
        },
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [tether?.id, partnerProfile?.id, partnerProfile?.full_name, profile?.id]);
}
