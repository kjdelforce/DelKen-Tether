import * as React from "react";

const KEY = "tether_safe_view_enabled";

function read(): boolean {
  try {
    return localStorage.getItem(KEY) === "true";
  } catch {
    return false;
  }
}

interface SafeViewContextValue {
  enabled: boolean;
  toggle: (on: boolean) => void;
}

const SafeViewContext = React.createContext<SafeViewContextValue>({
  enabled: false,
  toggle: () => {},
});

/**
 * Per-device, localStorage-only privacy mode. NEVER syncs to Supabase
 * or to the partner's app — it can only ever mask the local user's own
 * screen. Toggling adds/removes a `safe-view-active` class on <body>
 * so global CSS (the floating 🛡️ badge, plus any nested
 * `.safe-blur-wrap.is-safe` content) can react instantly.
 */
export function SafeViewProvider({ children }: { children: React.ReactNode }) {
  const [enabled, setEnabled] = React.useState<boolean>(read);

  React.useEffect(() => {
    const cls = "safe-view-active";
    if (enabled) {
      document.body.classList.add(cls);
    } else {
      document.body.classList.remove(cls);
    }
    return () => {
      document.body.classList.remove(cls);
    };
  }, [enabled]);

  const toggle = React.useCallback((on: boolean) => {
    try {
      localStorage.setItem(KEY, on ? "true" : "false");
    } catch {
      /* ignore quota / private-mode failures — Safe View is best-effort */
    }
    setEnabled(on);
  }, []);

  const value = React.useMemo<SafeViewContextValue>(
    () => ({ enabled, toggle }),
    [enabled, toggle],
  );

  return (
    <SafeViewContext.Provider value={value}>
      {children}
    </SafeViewContext.Provider>
  );
}

export function useSafeView(): SafeViewContextValue {
  return React.useContext(SafeViewContext);
}
