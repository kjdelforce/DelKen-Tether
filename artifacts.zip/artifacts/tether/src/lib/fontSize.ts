// ── Tether — User content text size ─────────────────────────────
//
// Adjusts the font size of every element that displays text the
// user (or their partner) typed. App labels, headings, nav items
// and buttons are explicitly excluded — only user-typed content
// resizes.
//
// Strategy:
//   1.  Persist the chosen size in localStorage under
//       `tether_user_font_size` (12-28pt, default 16).
//   2.  Set `--user-content-size` on <html> so anything that opts
//       in to that variable picks up the size — even elements
//       rendered after the change.
//   3.  Inject one <style> tag at boot that maps every selector
//       in USER_CONTENT_SELECTORS (and the `[data-user-content]`
//       opt-in attribute) to `font-size: var(--user-content-size)`.
//       That means React doesn't have to know about font size at
//       all — pages just tag a node and the styles flow through.
//
// `data-user-content` opt-in is the preferred way to add new
// surfaces. Dropping a static class into the array below is the
// fallback for places where the markup can't be touched.

export const FONT_SIZE_KEY  = "tether_user_font_size";
export const DEFAULT_SIZE   = 16;
export const MIN_SIZE       = 12;
export const MAX_SIZE       = 28;
export const SIZE_PRESETS   = [12, 14, 16, 20, 24, 28] as const;
export const PRESET_LABELS  = ["XS", "S", "M", "L", "XL", "XXL"] as const;

// CSS selectors that should always resize as user content.
// `data-user-content` is the canonical opt-in — the rest are
// here so we don't have to chase legacy class names everywhere.
const USER_CONTENT_SELECTORS = [
  "[data-user-content]",

  // Scrapbook
  ".scrapbook-text-paragraph",
  ".scrapbook-text-body",
  ".scrapbook-caption",
  ".scrapbook-note",

  // Capsules
  ".capsule-message",
  ".capsule-text",
  ".capsule-body",

  // Couples corner / love language / spicy stats answers
  ".love-language-answer",
  ".spicy-answer",
  ".user-answer",
  ".answer-text",

  // Daily connection
  ".daily-answer-text",
  ".daily-prompt-answer",

  // Whispers / pulses / love messages
  ".whisper-text",
  ".pulse-message",
  ".love-message-text",
  ".lyov-message",

  // Two Truths One Lie statements
  ".ttol-waiting-statement",
  ".ttol-guess-option",
  ".ttol-result-statement",

  // AI chat — only the user-typed bubble, never the assistant copy
  ".ai-msg-bubble.user",
  ".ai-msg.user",
  ".ai-msg-user",

  // Children of any [data-user-content] node (e.g. animated per-char
  // spans in Ghost Whisper). Safe because we only put the attribute
  // on text-only wrappers — never on nodes that contain controls.
  "[data-user-content] *",

  // Date plans
  ".date-notes",
  ".date-description",

  // Profile bio
  ".profile-bio",
  ".user-bio",
];

const STYLE_TAG_ID = "tether-font-size-style";

export function getSavedSize(): number {
  try {
    const raw = localStorage.getItem(FONT_SIZE_KEY);
    if (!raw) return DEFAULT_SIZE;
    const n = parseInt(raw, 10);
    if (!Number.isFinite(n)) return DEFAULT_SIZE;
    return Math.min(MAX_SIZE, Math.max(MIN_SIZE, n));
  } catch {
    return DEFAULT_SIZE;
  }
}

/**
 * Apply `size` (in px) globally. When `save` is true, persist to
 * localStorage so the setting survives reloads.
 */
export function applyFontSize(size: number, save = false): void {
  const clamped = Math.min(MAX_SIZE, Math.max(MIN_SIZE, Math.round(size)));
  document.documentElement.style.setProperty(
    "--user-content-size",
    `${clamped}px`,
  );
  if (save) {
    try {
      localStorage.setItem(FONT_SIZE_KEY, String(clamped));
    } catch {
      /* localStorage can throw in privacy mode — non-fatal */
    }
  }
}

/**
 * Inject the global stylesheet (once) and apply the saved size.
 * Safe to call multiple times — re-entry is a no-op for the
 * style tag.
 */
export function initFontSize(): void {
  if (typeof document === "undefined") return;

  if (!document.getElementById(STYLE_TAG_ID)) {
    const style = document.createElement("style");
    style.id = STYLE_TAG_ID;
    // !important so this always wins over per-component inline
    // font sizes (e.g. styled headings inside scrapbook spreads).
    style.textContent = `
      ${USER_CONTENT_SELECTORS.join(",\n      ")} {
        font-size: var(--user-content-size, ${DEFAULT_SIZE}px) !important;
      }
    `;
    document.head.appendChild(style);
  }

  applyFontSize(getSavedSize(), false);
}
