// ═══════════════════════════════════════════════════════════
//  proximity.ts — Proximity Pulse helpers
//  ─────────────────────────────────────────────────────────────
//  Distance maths, poetic-tier mapping, localStorage flags,
//  Supabase CRUD for partner_locations, and a synthesised
//  harp melody played once when partners come together.
// ═══════════════════════════════════════════════════════════
import { supabase } from "./supabaseClient";
import { isAudioMuted } from "./audioManager";

// ── Tunables ────────────────────────────────────────────────
export const TETHERED_THRESHOLD_KM = 0.15;   // 150 m — same area
export const UPDATE_INTERVAL_MS    = 30_000; // 30 s upload cadence
export const STALE_AFTER_MINUTES   = 5;      // ignore older partner fixes

// ── localStorage keys ──────────────────────────────────────
export const PROXIMITY_ENABLED_KEY = "tether_proximity_enabled";
export const LOCATION_PERM_KEY     = "tether_proximity_permission";
export const FIRST_PROMPT_KEY      = "tether_proximity_first_prompt_seen";

// ── State emitted by useProximity ──────────────────────────
export type ProximityState = "tethered" | "apart" | "hidden";

export interface DistanceTier {
  maxKm: number;
  label: string;
  state: "tethered" | "apart";
}

export const DISTANCE_TIERS: DistanceTier[] = [
  { maxKm: TETHERED_THRESHOLD_KM, label: "Tethered",         state: "tethered" },
  { maxKm: 2,                     label: "Close by",         state: "apart"    },
  { maxKm: 20,                    label: "Across the city",  state: "apart"    },
  { maxKm: 100,                   label: "A little away",    state: "apart"    },
  { maxKm: 1000,                  label: "Far away",         state: "apart"    },
  { maxKm: Infinity,              label: "Worlds apart",     state: "apart"    },
];

export function getDistanceTier(km: number): DistanceTier {
  return DISTANCE_TIERS.find((t) => km <= t.maxKm) ?? DISTANCE_TIERS[DISTANCE_TIERS.length - 1];
}

/** Haversine distance in kilometres. */
export function getDistanceKm(
  lat1: number, lon1: number,
  lat2: number, lon2: number,
): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// ── localStorage flags (shared by Home + Settings) ────────
export function isProximityEnabled(): boolean {
  return localStorage.getItem(PROXIMITY_ENABLED_KEY) === "true";
}

export function setProximityEnabled(enabled: boolean): void {
  localStorage.setItem(PROXIMITY_ENABLED_KEY, enabled ? "true" : "false");
  // Notify same-tab listeners (storage event only fires across tabs).
  window.dispatchEvent(new CustomEvent("tether-proximity-toggle", {
    detail: { enabled },
  }));
}

export function getStoredPermission(): "granted" | "denied" | null {
  const v = localStorage.getItem(LOCATION_PERM_KEY);
  return v === "granted" || v === "denied" ? v : null;
}

export function setStoredPermission(v: "granted" | "denied"): void {
  localStorage.setItem(LOCATION_PERM_KEY, v);
}

// ── Geolocation wrapper ────────────────────────────────────
export interface Coords { lat: number; lng: number; }

export function getCurrentPosition(): Promise<Coords> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocation not supported"));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      (err) => reject(err),
      { enableHighAccuracy: false, timeout: 10_000, maximumAge: 60_000 },
    );
  });
}

// ── Supabase CRUD ──────────────────────────────────────────
export interface PartnerLocationRow {
  id: string;
  tether_id: string;
  user_id: string;
  latitude: number;
  longitude: number;
  sharing_enabled: boolean;
  updated_at: string;
}

export async function upsertMyLocation(args: {
  tetherId: string;
  userId: string;
  lat: number;
  lng: number;
  sharingEnabled: boolean;
}): Promise<void> {
  const { error } = await supabase
    .from("partner_locations")
    .upsert(
      {
        tether_id: args.tetherId,
        user_id: args.userId,
        latitude: args.lat,
        longitude: args.lng,
        sharing_enabled: args.sharingEnabled,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "tether_id,user_id" },
    );
  if (error) console.warn("[proximity] upsertMyLocation", error.message);
}

export async function setSharingEnabledOnly(args: {
  tetherId: string;
  userId: string;
  sharingEnabled: boolean;
}): Promise<void> {
  // Only flip the flag — don't overwrite coords. If no row exists yet,
  // we'll silently no-op (coords get created on the next upload cycle).
  const { error } = await supabase
    .from("partner_locations")
    .update({ sharing_enabled: args.sharingEnabled, updated_at: new Date().toISOString() })
    .eq("tether_id", args.tetherId)
    .eq("user_id", args.userId);
  if (error) console.warn("[proximity] setSharingEnabledOnly", error.message);
}

export async function fetchPartnerLocation(args: {
  tetherId: string;
  partnerId: string;
}): Promise<PartnerLocationRow | null> {
  const { data, error } = await supabase
    .from("partner_locations")
    .select("*")
    .eq("tether_id", args.tetherId)
    .eq("user_id", args.partnerId)
    .maybeSingle();
  if (error) {
    console.warn("[proximity] fetchPartnerLocation", error.message);
    return null;
  }
  return (data as PartnerLocationRow | null) ?? null;
}

// ════════════════════════════════════════════════════════════
//  Harp melody — synthesised once when entering "tethered".
//  Honours the global Sounds toggle via audioManager.isAudioMuted().
// ════════════════════════════════════════════════════════════
export function playTetheredHarp(): void {
  if (isAudioMuted()) return;

  const Ctx = window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return;

  let ac: AudioContext;
  try { ac = new Ctx(); } catch { return; }
  const now = ac.currentTime;

  // A major pentatonic cascade — soft and warm.
  const notes: { freq: number; time: number; dur: number; gain: number }[] = [
    { freq:  440.00, time: 0.00, dur: 2.0, gain: 0.18 },
    { freq:  554.37, time: 0.18, dur: 1.8, gain: 0.15 },
    { freq:  659.25, time: 0.36, dur: 1.6, gain: 0.14 },
    { freq:  880.00, time: 0.54, dur: 1.5, gain: 0.12 },
    { freq: 1108.73, time: 0.72, dur: 1.3, gain: 0.10 },
    { freq: 1318.51, time: 0.90, dur: 1.2, gain: 0.08 },
    { freq:  880.00, time: 1.10, dur: 1.4, gain: 0.09 },
    { freq:  659.25, time: 1.30, dur: 1.8, gain: 0.10 },
  ];

  // Soft reverb tail.
  const reverbLength = ac.sampleRate * 3;
  const reverbBuffer = ac.createBuffer(2, reverbLength, ac.sampleRate);
  for (let c = 0; c < 2; c++) {
    const ch = reverbBuffer.getChannelData(c);
    for (let i = 0; i < reverbLength; i++) {
      ch[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / reverbLength, 2.8);
    }
  }
  const convolver = ac.createConvolver();
  convolver.buffer = reverbBuffer;
  convolver.connect(ac.destination);

  for (const note of notes) {
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(note.freq, now + note.time);
    osc.frequency.setTargetAtTime(note.freq * 0.999, now + note.time + 0.1, 0.3);
    gain.gain.setValueAtTime(0, now + note.time);
    gain.gain.linearRampToValueAtTime(note.gain, now + note.time + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, now + note.time + note.dur);
    osc.connect(gain);
    gain.connect(convolver);
    osc.start(now + note.time);
    osc.stop(now + note.time + note.dur + 0.1);
  }

  setTimeout(() => { ac.close().catch(() => {}); }, 4500);
}
