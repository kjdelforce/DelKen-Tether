const VAPID_PUBLIC_KEY = (import.meta.env.VITE_VAPID_PUBLIC_KEY as string) ?? '';

function getApiUrl(): string {
  // The API server artifact is proxied at /api on the same domain.
  // Since all fetch calls already include /api/ in their paths, we just
  // need the origin — no extra path suffix.
  return window.location.origin;
}

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  return Uint8Array.from([...rawData].map((c) => c.charCodeAt(0)));
}

export async function registerServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (!('serviceWorker' in navigator)) return null;
  try {
    const base = import.meta.env.BASE_URL || '/';
    const swUrl = `${base}sw.js`;
    await navigator.serviceWorker.register(swUrl, { scope: base });
    // Wait for the SW to be fully active — critical after re-adding the PWA
    // to the home screen, where the new context starts with no active SW.
    // navigator.serviceWorker.ready resolves only once a SW is controlling the page.
    const reg = await navigator.serviceWorker.ready;
    return reg;
  } catch (e) {
    console.warn('[Tether] Service worker registration failed:', e);
    return null;
  }
}

// ── User-facing toggle helpers ──────────────────────────────────────
// Distinct from `setupPushNotifications` (which auto-runs on login).
// These power the Settings page toggle and persist the user's
// explicit preference so we don't re-prompt them after they opt out.
const NOTIF_PREF_KEY = "tether_notif_pref";

export function isPushSupported(): boolean {
  return (
    typeof window !== "undefined" &&
    "serviceWorker" in navigator &&
    "PushManager" in window &&
    "Notification" in window &&
    Boolean(VAPID_PUBLIC_KEY)
  );
}

/**
 * True only when the OS, the browser permission, and an active SW
 * subscription all agree that pushes can land — AND the user hasn't
 * explicitly toggled the preference off in Settings.
 */
export async function isPushEnabled(): Promise<boolean> {
  if (!isPushSupported()) return false;
  try {
    if (localStorage.getItem(NOTIF_PREF_KEY) === "off") return false;
  } catch {
    /* ignore */
  }
  if (Notification.permission !== "granted") return false;
  try {
    const reg = await navigator.serviceWorker.getRegistration();
    if (!reg) return false;
    const sub = await reg.pushManager.getSubscription();
    return !!sub;
  } catch {
    return false;
  }
}

/**
 * Subscribe (re-using the canonical setup flow) and clear any opt-out
 * preference. Returns true if push is now genuinely active.
 */
export async function enablePush(
  userId: string,
  tetherId: string,
): Promise<boolean> {
  if (!isPushSupported()) return false;
  try {
    localStorage.removeItem(NOTIF_PREF_KEY);
  } catch {
    /* ignore */
  }
  const reg =
    (await navigator.serviceWorker.getRegistration()) ??
    (await registerServiceWorker());
  if (!reg) return false;
  await setupPushNotifications(reg, userId, tetherId);
  return isPushEnabled();
}

/**
 * Unsubscribe the local browser subscription and remember the opt-out.
 * The server side cleans up dead subscriptions automatically when the
 * next push attempt returns 410 (see api-server/src/routes/push.ts).
 */
export async function disablePush(): Promise<void> {
  try {
    localStorage.setItem(NOTIF_PREF_KEY, "off");
  } catch {
    /* ignore */
  }
  if (!("serviceWorker" in navigator)) return;
  try {
    const reg = await navigator.serviceWorker.getRegistration();
    const sub = await reg?.pushManager.getSubscription();
    if (sub) await sub.unsubscribe();
  } catch (e) {
    console.warn("[Tether] disablePush failed:", e);
  }
}

export async function setupPushNotifications(
  registration: ServiceWorkerRegistration,
  userId: string,
  tetherId: string,
): Promise<void> {
  if (!('PushManager' in window) || !VAPID_PUBLIC_KEY) return;

  // Honour the user's saved Notifications preference. If they explicitly
  // toggled OFF in Settings, never auto-resubscribe on next page load —
  // only re-enabling from Settings (which calls enablePush() and clears
  // the pref) should bring them back. Without this guard, the auto-setup
  // on login would silently re-create a subscription on every reload.
  // (We only check the opt-out flag here — we can't use isPushEnabled()
  // because that requires an existing subscription which is exactly what
  // this function is meant to create on first run.)
  try {
    if (localStorage.getItem(NOTIF_PREF_KEY) === "off") return;
  } catch {
    /* ignore */
  }

  const permission = Notification.permission === 'granted'
    ? 'granted'
    : await Notification.requestPermission();
  if (permission !== 'granted') return;

  try {
    let subscription = await registration.pushManager.getSubscription();
    if (!subscription) {
      subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY).buffer as ArrayBuffer,
      });
    }

    const apiUrl = getApiUrl();
    const resp = await fetch(`${apiUrl}/api/push/subscribe`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, tetherId, subscription }),
    });

    if (!resp.ok) {
      const text = await resp.text().catch(() => '');
      console.error('[Tether] Push registration failed:', resp.status, text);
    }
  } catch (e) {
    console.warn('[Tether] Push subscription failed:', e);
  }
}

async function sendPushEvent(
  endpoint: string,
  tetherId: string,
  senderId: string,
  senderName?: string,
): Promise<void> {
  try {
    const apiUrl = getApiUrl();
    const body: Record<string, string> = { tetherId, senderId };
    if (senderName) body.senderName = senderName;
    await fetch(`${apiUrl}${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
  } catch (e) {
    console.warn(`[Tether] Push (${endpoint}) failed:`, e);
  }
}

export async function sendLoveYouNotification(
  tetherId: string,
  senderId: string,
  senderName: string,
): Promise<void> {
  return sendPushEvent('/api/push/love', tetherId, senderId, senderName);
}

export async function sendWhisperNotification(
  tetherId: string,
  senderId: string,
  senderName?: string,
): Promise<void> {
  return sendPushEvent('/api/push/whisper', tetherId, senderId, senderName);
}

export async function sendTriviaNotification(
  tetherId: string,
  senderId: string,
  senderName?: string,
): Promise<void> {
  return sendPushEvent('/api/push/trivia', tetherId, senderId, senderName);
}

export async function sendDailyConnectionNotification(
  tetherId: string,
  senderId: string,
  senderName?: string,
): Promise<void> {
  return sendPushEvent('/api/push/daily-connection', tetherId, senderId, senderName);
}

export async function sendLoveNoteNotification(
  tetherId: string,
  senderId: string,
  senderName?: string,
): Promise<void> {
  return sendPushEvent('/api/push/love-note', tetherId, senderId, senderName);
}

// ── Two Truths One Lie ──────────────────────────────────────────────
// Three distinct event types share the same lock-screen tag on the
// server side so a fresh notification supersedes the previous one
// instead of stacking up.
export async function sendTwoTruthsNewRoundNotification(
  tetherId: string,
  senderId: string,
  senderName?: string,
): Promise<void> {
  return sendPushEvent('/api/push/two-truths-new-round', tetherId, senderId, senderName);
}

export async function sendTwoTruthsYourTurnNotification(
  tetherId: string,
  senderId: string,
  senderName?: string,
): Promise<void> {
  return sendPushEvent('/api/push/two-truths-your-turn', tetherId, senderId, senderName);
}

// Result notification carries an extra `correct` flag so the writer's
// notification body says either "spotted your lie" or "fell for it".
// Inlined fetch (rather than reusing sendPushEvent) because the
// shared helper only knows how to send {tetherId, senderId, senderName}.
export async function sendTwoTruthsGuessNotification(
  tetherId: string,
  senderId: string,
  senderName: string | undefined,
  correct: boolean,
): Promise<void> {
  try {
    const apiUrl = getApiUrl();
    const body: Record<string, unknown> = { tetherId, senderId, correct };
    if (senderName) body.senderName = senderName;
    await fetch(`${apiUrl}/api/push/two-truths-guess`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
  } catch (e) {
    console.warn('[Tether] Push (/api/push/two-truths-guess) failed:', e);
  }
}
