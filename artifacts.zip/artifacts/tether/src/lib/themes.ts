// Tether theme system.
//
// The unique mechanic: each partner *gifts* a theme to the OTHER one.
// Kyle picks → it applies on Nathan's app. Nathan picks → applies on Kyle's.
// The chosen theme syncs via Supabase (`profiles.app_theme`) so it
// persists across devices and re-installs.
//
// SCOPE NOTE
// ──────────
// This module owns the *infrastructure*: the theme catalogue, applying
// the 9 `--theme-*` CSS custom properties to `:root`, the gifting flow,
// and the realtime subscription that picks up partner gifts. It does
// NOT rewrite the rest of the app's hardcoded colour values — Tether's
// Liquid Glass aesthetic is hand-tuned across hundreds of inline
// styles and CSS files. Surfaces that already use `var(--theme-*)`
// (the Tether Wrapped overlay, future surfaces) will recolour
// instantly when the theme changes; legacy surfaces won't visibly
// change until they're migrated. See replit.md → "Tether — Themes"
// for the migration guide.

export type ThemeKey =
  | "midnight"
  | "rosewood"
  | "arctic"
  | "ember"
  | "celestial"
  | "beach"
  | "onepiece"
  | "christmas"
  | "bloodfire"
  | "birthday"
  | "neon"
  | "autumn"
  | "camping"
  | "stpatricks"
  | "easter"
  // ── Theme Engine v2 — extended presets that also drive the
  // mesh gradient, liquid-glass opacity/blur, and per-theme
  // typography. See the corresponding rules near the bottom of
  // src/index.css ("THEME ENGINE — extended preset overrides").
  | "midnightsilk"
  | "goldenhour"
  | "nordic"
  | "retroanalog"
  | "cyberluxe";

/**
 * Themes that mount extra decorations via the React-based
 * <ThemeDecorations /> component. Christmas now uses the seasonal
 * animation builder (snowflakes via DOM containers) instead, so it's
 * been removed from this set to avoid double-rendering snowfall.
 * Birthday still uses the React component for its balloons + confetti.
 */
export const DECORATED_THEMES: ReadonlySet<ThemeKey> = new Set([
  "birthday",
] as const);

/**
 * Custom event fired on `window` whenever applyTheme runs. React
 * components (LivingSkyHeader's Santa, ThemeDecorations, etc.) use
 * this to swap their conditional rendering when a theme arrives via
 * partner gift without needing a full re-render of the auth tree.
 */
export const THEME_CHANGE_EVENT = "tether:themechange";

export interface Theme {
  name:        string;
  description: string;
  preview:     [string, string, string]; // bg, mid, accent (used as swatches)
  vars:        Record<string, string>;
  /** Optional list of named animation layers to mount via applyThemeAnimations. */
  animations?: string[];
}

export const TETHER_THEMES: Record<ThemeKey, Theme> = {
  midnight: {
    name:        "Midnight",
    description: "Deep navy and pure white — the original Tether",
    preview:     ["#05080f", "#0d1a2e", "#b48cff"],
    vars: {
      "--theme-bg-primary":     "#0a0a0f",
      "--theme-bg-secondary":   "#0d1a2e",
      "--theme-accent":         "rgba(180, 140, 255, 0.8)",
      "--theme-accent-glow":    "rgba(120, 80, 200, 0.4)",
      "--theme-glass":          "rgba(255, 255, 255, 0.07)",
      "--theme-glass-border":   "rgba(255, 255, 255, 0.12)",
      "--theme-text-primary":   "rgba(255, 255, 255, 0.92)",
      "--theme-text-secondary": "rgba(255, 255, 255, 0.5)",
      "--theme-particle":       "rgba(255, 255, 255, 0.15)",
      // Tint overlay (body::before in themes.css). Midnight = no tint
      // so the existing Liquid Glass look is unchanged.
      "--theme-tint":           "transparent",
      "--theme-tint-opacity":   "0",
    },
  },
  rosewood: {
    name:        "Rosewood",
    description: "Warm rose and deep burgundy — romantic and intimate",
    preview:     ["#0f0608", "#2e0d14", "#f4a0b0"],
    vars: {
      "--theme-bg-primary":     "#0f0608",
      "--theme-bg-secondary":   "#1a080d",
      "--theme-accent":         "rgba(244, 160, 176, 0.85)",
      "--theme-accent-glow":    "rgba(180, 60, 90, 0.4)",
      "--theme-glass":          "rgba(244, 160, 176, 0.06)",
      "--theme-glass-border":   "rgba(244, 160, 176, 0.14)",
      "--theme-text-primary":   "rgba(255, 240, 242, 0.92)",
      "--theme-text-secondary": "rgba(255, 200, 210, 0.5)",
      "--theme-particle":       "rgba(244, 160, 176, 0.18)",
      "--theme-tint":           "#c8466a",
      "--theme-tint-opacity":   "0.35",
    },
  },
  arctic: {
    name:        "Arctic",
    description: "Ice blue and silver — cool, crisp, and ethereal",
    preview:     ["#040a0f", "#0a1a28", "#a0d8f4"],
    vars: {
      "--theme-bg-primary":     "#040a0f",
      "--theme-bg-secondary":   "#0a1828",
      "--theme-accent":         "rgba(160, 216, 244, 0.85)",
      "--theme-accent-glow":    "rgba(60, 140, 200, 0.4)",
      "--theme-glass":          "rgba(160, 216, 244, 0.06)",
      "--theme-glass-border":   "rgba(160, 216, 244, 0.14)",
      "--theme-text-primary":   "rgba(240, 248, 255, 0.92)",
      "--theme-text-secondary": "rgba(180, 220, 244, 0.5)",
      "--theme-particle":       "rgba(160, 216, 244, 0.18)",
      "--theme-tint":           "#4a90c8",
      "--theme-tint-opacity":   "0.32",
    },
  },
  ember: {
    name:        "Ember",
    description: "Amber and deep charcoal — warm, grounded, alive",
    preview:     ["#0a0700", "#1a1000", "#f4b860"],
    vars: {
      "--theme-bg-primary":     "#0a0700",
      "--theme-bg-secondary":   "#180f00",
      "--theme-accent":         "rgba(244, 184, 96, 0.85)",
      "--theme-accent-glow":    "rgba(200, 120, 20, 0.4)",
      "--theme-glass":          "rgba(244, 184, 96, 0.06)",
      "--theme-glass-border":   "rgba(244, 184, 96, 0.14)",
      "--theme-text-primary":   "rgba(255, 248, 235, 0.92)",
      "--theme-text-secondary": "rgba(244, 210, 150, 0.5)",
      "--theme-particle":       "rgba(244, 184, 96, 0.18)",
      "--theme-tint":           "#d88a2c",
      "--theme-tint-opacity":   "0.30",
    },
  },
  celestial: {
    name:        "Celestial",
    description: "Deep purple and cosmic gold — otherworldly and vast",
    preview:     ["#060410", "#120820", "#c8a0f0"],
    vars: {
      "--theme-bg-primary":     "#060410",
      "--theme-bg-secondary":   "#100820",
      "--theme-accent":         "rgba(200, 160, 240, 0.85)",
      "--theme-accent-glow":    "rgba(140, 60, 220, 0.45)",
      "--theme-glass":          "rgba(200, 160, 240, 0.06)",
      "--theme-glass-border":   "rgba(200, 160, 240, 0.15)",
      "--theme-text-primary":   "rgba(245, 238, 255, 0.92)",
      "--theme-text-secondary": "rgba(200, 170, 240, 0.5)",
      "--theme-particle":       "rgba(200, 160, 240, 0.18)",
      "--theme-tint":           "#7a3cd8",
      "--theme-tint-opacity":   "0.36",
    },
  },
  beach: {
    name:        "Beach",
    description: "Warm whites, golden sun and ocean blue — coastal and alive",
    preview:     ["#f5f0e8", "#4ab8d4", "#f4d03f"],
    vars: {
      "--theme-bg-primary":     "#e8f4f8",
      "--theme-bg-secondary":   "#d4ecf5",
      "--theme-accent":         "rgba(30, 160, 200, 0.85)",
      "--theme-accent-glow":    "rgba(74, 184, 212, 0.45)",
      "--theme-glass":          "rgba(255, 252, 245, 0.15)",
      "--theme-glass-border":   "rgba(255, 255, 255, 0.55)",
      "--theme-text-primary":   "rgba(20, 60, 80, 0.92)",
      "--theme-text-secondary": "rgba(30, 80, 100, 0.55)",
      "--theme-particle":       "rgba(74, 184, 212, 0.3)",
      "--theme-tint":           "transparent",
      "--theme-tint-opacity":   "0",
    },
    animations: ["beach-ripple", "beach-sky"],
  },
  onepiece: {
    name:        "One Piece",
    description: "Pirate gold and ocean red — set sail for the Grand Line",
    preview:     ["#040818", "#0a2848", "#f4c828"],
    vars: {
      "--theme-bg-primary":     "#040818",
      "--theme-bg-secondary":   "#0a2040",
      "--theme-accent":         "rgba(244, 200, 40, 0.92)",
      "--theme-accent-glow":    "rgba(232, 90, 48, 0.45)",
      "--theme-glass":          "rgba(244, 200, 40, 0.07)",
      "--theme-glass-border":   "rgba(244, 200, 40, 0.18)",
      "--theme-text-primary":   "rgba(255, 250, 230, 0.95)",
      "--theme-text-secondary": "rgba(244, 220, 150, 0.55)",
      "--theme-particle":       "rgba(244, 200, 40, 0.20)",
      "--theme-tint":           "#e85a30",
      "--theme-tint-opacity":   "0.32",
    },
  },
  christmas: {
    name:        "Christmas",
    description: "Snowy white, festive lights and holiday magic",
    preview:     ["#f8faff", "#c41e3a", "#ffd700"],
    vars: {
      "--theme-bg-primary":     "#f0f4ff",
      "--theme-bg-secondary":   "#e8eeff",
      "--theme-accent":         "rgba(196, 30, 58, 0.85)",
      "--theme-accent-glow":    "rgba(255, 215, 0, 0.4)",
      "--theme-glass":          "rgba(255, 255, 255, 0.25)",
      "--theme-glass-border":   "rgba(255, 255, 255, 0.6)",
      "--theme-text-primary":   "rgba(20, 30, 60, 0.92)",
      "--theme-text-secondary": "rgba(40, 50, 80, 0.55)",
      "--theme-particle":       "rgba(255, 255, 255, 0.9)",
      "--theme-tint":           "transparent",
      "--theme-tint-opacity":   "0",
    },
    animations: ["christmas-snow", "christmas-lights", "christmas-wreath"],
  },
  bloodfire: {
    name:        "Blood & Fire",
    description: "Crimson, ember and ash — for the dramatic at heart",
    preview:     ["#0a0204", "#1f0408", "#ff2a2a"],
    vars: {
      "--theme-bg-primary":     "#0a0204",
      "--theme-bg-secondary":   "#1f0408",
      "--theme-accent":         "rgba(255, 60, 40, 0.95)",
      "--theme-accent-glow":    "rgba(255, 120, 30, 0.55)",
      "--theme-glass":          "rgba(255, 80, 60, 0.08)",
      "--theme-glass-border":   "rgba(255, 100, 60, 0.22)",
      "--theme-text-primary":   "rgba(255, 240, 235, 0.95)",
      "--theme-text-secondary": "rgba(255, 180, 160, 0.6)",
      "--theme-particle":       "rgba(255, 120, 40, 0.22)",
      "--theme-tint":           "#d80818",
      "--theme-tint-opacity":   "0.42",
    },
  },
  birthday: {
    name:        "Birthday",
    description: "Hot pink, cake yellow and confetti everywhere",
    preview:     ["#100618", "#280830", "#ff64b4"],
    vars: {
      "--theme-bg-primary":     "#100618",
      "--theme-bg-secondary":   "#1f0a28",
      "--theme-accent":         "rgba(255, 100, 180, 0.92)",
      "--theme-accent-glow":    "rgba(244, 200, 80, 0.5)",
      "--theme-glass":          "rgba(255, 200, 220, 0.07)",
      "--theme-glass-border":   "rgba(255, 150, 200, 0.20)",
      "--theme-text-primary":   "rgba(255, 245, 250, 0.95)",
      "--theme-text-secondary": "rgba(255, 200, 220, 0.6)",
      "--theme-particle":       "rgba(255, 150, 200, 0.22)",
      "--theme-tint":           "#f04898",
      "--theme-tint-opacity":   "0.30",
    },
  },
  neon: {
    name:        "Neon",
    description: "Pure black, electric blue and neon red — the two of you in lights",
    preview:     ["#000000", "#050015", "#00e0ff"],
    vars: {
      "--theme-bg-primary":     "#000000",
      "--theme-bg-secondary":   "#050015",
      "--theme-accent":         "rgba(0, 220, 255, 0.95)",
      "--theme-accent-glow":    "rgba(255, 50, 90, 0.6)",
      "--theme-glass":          "rgba(0, 200, 255, 0.04)",
      "--theme-glass-border":   "rgba(0, 220, 255, 0.32)",
      "--theme-text-primary":   "rgba(255, 255, 255, 0.96)",
      "--theme-text-secondary": "rgba(180, 220, 255, 0.65)",
      "--theme-particle":       "rgba(0, 220, 255, 0.30)",
      // No body::before wash — the neon character comes from
      // pulsing borders + text glows defined in themes.css.
      "--theme-tint":           "transparent",
      "--theme-tint-opacity":   "0",
    },
  },
  autumn: {
    name:        "Autumn",
    description: "Burnt orange, deep amber and falling leaves",
    preview:     ["#1a0a00", "#c0510a", "#e8a020"],
    vars: {
      "--theme-bg-primary":     "#0e0600",
      "--theme-bg-secondary":   "#1a0c00",
      "--theme-accent":         "rgba(192, 81, 10, 0.88)",
      "--theme-accent-glow":    "rgba(232, 160, 32, 0.45)",
      "--theme-glass":          "rgba(192, 81, 10, 0.08)",
      "--theme-glass-border":   "rgba(232, 160, 32, 0.2)",
      "--theme-text-primary":   "rgba(255, 240, 220, 0.92)",
      "--theme-text-secondary": "rgba(232, 180, 120, 0.55)",
      "--theme-particle":       "rgba(192, 81, 10, 0.5)",
      "--theme-tint":           "#c0510a",
      "--theme-tint-opacity":   "0.28",
    },
    animations: ["autumn-leaves"],
  },
  camping: {
    name:        "Camping",
    description: "Toasted marshmallow, warm wood and ember glow",
    preview:     ["#1c0e06", "#8b4513", "#ff8c00"],
    vars: {
      "--theme-bg-primary":     "#120a04",
      "--theme-bg-secondary":   "#1c1008",
      "--theme-accent":         "rgba(255, 120, 20, 0.88)",
      "--theme-accent-glow":    "rgba(255, 160, 40, 0.5)",
      "--theme-glass":          "rgba(139, 69, 19, 0.12)",
      "--theme-glass-border":   "rgba(255, 140, 40, 0.22)",
      "--theme-text-primary":   "rgba(255, 245, 220, 0.92)",
      "--theme-text-secondary": "rgba(210, 170, 110, 0.6)",
      "--theme-particle":       "rgba(255, 120, 20, 0.55)",
      // Disable the body::before tint overlay for this theme so the
      // warm wood/ember palette comes through unfiltered. Setting these
      // explicitly (instead of omitting them) prevents whichever tint
      // was applied by the previous theme from bleeding through after
      // a swap, since applyTheme only writes the vars it sees.
      "--theme-tint":           "transparent",
      "--theme-tint-opacity":   "0",
    },
    animations: ["camping-fire"],
  },
  stpatricks: {
    name:        "St Patrick's Day",
    description: "Emerald green, gold and a touch of Irish magic",
    preview:     ["#011a06", "#006620", "#ffd700"],
    vars: {
      "--theme-bg-primary":     "#010e03",
      "--theme-bg-secondary":   "#011a06",
      "--theme-accent":         "rgba(0, 180, 60, 0.88)",
      "--theme-accent-glow":    "rgba(255, 215, 0, 0.4)",
      "--theme-glass":          "rgba(0, 120, 40, 0.1)",
      "--theme-glass-border":   "rgba(0, 180, 60, 0.22)",
      "--theme-text-primary":   "rgba(220, 255, 230, 0.92)",
      "--theme-text-secondary": "rgba(120, 220, 140, 0.55)",
      "--theme-particle":       "rgba(0, 180, 60, 0.5)",
      "--theme-tint":           "#006620",
      "--theme-tint-opacity":   "0.30",
    },
    animations: ["stpatricks-shamrocks", "stpatricks-rainbow"],
  },
  // ════════════════════════════════════════════════════════════
  //  THEME ENGINE v2 — extended presets
  //  ────────────────────────────────────────────────────────────
  //  Each one ships extra `--theme-*` vars (font, blur, texture)
  //  on top of the original 9 colour vars. The matching CSS in
  //  index.css ("THEME ENGINE — extended preset overrides") wires
  //  those vars into body font-family, backdrop-filter blur, and
  //  the body::after texture overlay (grain / grid).
  // ════════════════════════════════════════════════════════════

  midnightsilk: {
    name:        "Midnight Silk",
    description: "Pure OLED black, deep violet glass and ultra-thin white type",
    preview:     ["#000000", "#1a0a2e", "#8a4fff"],
    vars: {
      "--theme-bg-primary":     "#000000",
      "--theme-bg-secondary":   "#0a0418",
      "--theme-accent":         "rgba(138, 79, 255, 0.85)",
      "--theme-accent-glow":    "rgba(98, 38, 220, 0.45)",
      "--theme-glass":          "rgba(138, 79, 255, 0.05)",
      "--theme-glass-border":   "rgba(180, 140, 255, 0.16)",
      "--theme-text-primary":   "rgba(255, 255, 255, 0.96)",
      "--theme-text-secondary": "rgba(220, 210, 255, 0.50)",
      "--theme-particle":       "rgba(180, 140, 255, 0.20)",
      "--theme-tint":           "transparent",
      "--theme-tint-opacity":   "0",
      // Engine-v2 vars
      "--theme-font-sans":      "'Inter Variable', 'Inter', system-ui, sans-serif",
      "--theme-font-weight":    "300",       // ultra-thin baseline
      "--theme-letter-spacing": "0.005em",   // a hair of openness
      "--theme-glass-blur":     "22px",
      "--theme-glass-saturate": "150%",
      "--theme-texture":        "none",
      "--theme-texture-opacity":"0",
    },
  },

  goldenhour: {
    name:        "Golden Hour",
    description: "Warm ambers, soft pinks and burnt-orange light through gold-tinted glass",
    preview:     ["#1a0e08", "#c8682a", "#ffd28a"],
    vars: {
      "--theme-bg-primary":     "#1a0e08",
      "--theme-bg-secondary":   "#3a1a10",
      "--theme-accent":         "rgba(255, 180, 110, 0.92)",
      "--theme-accent-glow":    "rgba(255, 140, 80, 0.55)",
      "--theme-glass":          "rgba(255, 180, 110, 0.10)",       // gold-tinted glass
      "--theme-glass-border":   "rgba(255, 200, 140, 0.32)",
      "--theme-text-primary":   "rgba(255, 245, 230, 0.95)",
      "--theme-text-secondary": "rgba(255, 210, 170, 0.60)",
      "--theme-particle":       "rgba(255, 180, 110, 0.28)",
      "--theme-tint":           "#ff9a4d",
      "--theme-tint-opacity":   "0.20",
      "--theme-font-sans":      "'Inter Variable', 'Inter', system-ui, sans-serif",
      "--theme-font-weight":    "420",
      "--theme-letter-spacing": "0",
      "--theme-glass-blur":     "26px",
      "--theme-glass-saturate": "200%",      // higher refraction
      "--theme-texture":        "none",
      "--theme-texture-opacity":"0",
    },
  },

  nordic: {
    name:        "Nordic Minimalist",
    description: "Stark whites and pale greys with maximum-blur frosted glass",
    preview:     ["#f6f7f9", "#e4e7ec", "#9ca3af"],
    vars: {
      "--theme-bg-primary":     "#f6f7f9",
      "--theme-bg-secondary":   "#e8eaef",
      "--theme-accent":         "rgba(60, 70, 90, 0.65)",
      "--theme-accent-glow":    "rgba(180, 190, 210, 0.40)",
      "--theme-glass":          "rgba(255, 255, 255, 0.30)",
      "--theme-glass-border":   "rgba(255, 255, 255, 0.70)",
      "--theme-text-primary":   "rgba(20, 24, 32, 0.92)",
      "--theme-text-secondary": "rgba(60, 70, 90, 0.60)",
      "--theme-particle":       "rgba(180, 190, 210, 0.30)",
      "--theme-tint":           "transparent",
      "--theme-tint-opacity":   "0",
      "--theme-font-sans":      "'Inter Variable', 'Inter', system-ui, sans-serif",
      "--theme-font-weight":    "380",       // high-key, clean
      "--theme-letter-spacing": "-0.005em",
      "--theme-glass-blur":     "32px",      // 30px+ per spec
      "--theme-glass-saturate": "120%",
      "--theme-texture":        "none",
      "--theme-texture-opacity":"0",
    },
  },

  retroanalog: {
    name:        "Retro Analog",
    description: "Muted creams and forest greens with a film-grain overlay and typewriter headers",
    preview:     ["#f0e8d4", "#5a7a4a", "#8a6a3a"],
    vars: {
      "--theme-bg-primary":     "#1f1d16",
      "--theme-bg-secondary":   "#2a2f22",
      "--theme-accent":         "rgba(170, 200, 140, 0.85)",
      "--theme-accent-glow":    "rgba(120, 160, 90, 0.45)",
      "--theme-glass":          "rgba(240, 232, 212, 0.06)",
      "--theme-glass-border":   "rgba(240, 232, 212, 0.20)",
      "--theme-text-primary":   "rgba(240, 232, 212, 0.92)",
      "--theme-text-secondary": "rgba(200, 195, 170, 0.55)",
      "--theme-particle":       "rgba(170, 200, 140, 0.25)",
      "--theme-tint":           "#5a7a4a",
      "--theme-tint-opacity":   "0.18",
      "--theme-font-sans":      "'Inter Variable', 'Inter', system-ui, sans-serif",
      "--theme-font-weight":    "440",
      "--theme-letter-spacing": "0",
      "--theme-glass-blur":     "24px",
      "--theme-glass-saturate": "130%",
      // Film-grain via SVG turbulence — inline data URI so no
      // network fetch and no asset to ship.
      "--theme-texture":
        "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='220' height='220'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 0.95  0 0 0 0 0.92  0 0 0 0 0.82  0 0 0 0.6 0'/></filter><rect width='100%25' height='100%25' filter='url(%23n)' opacity='0.55'/></svg>\")",
      "--theme-texture-opacity":"0.28",
    },
  },

  cyberluxe: {
    name:        "Cyber Luxe",
    description: "Dark charcoal base with thin neon cyan + magenta borders over a faint grid mesh",
    preview:     ["#0e1014", "#00f0ff", "#ff2bd6"],
    vars: {
      "--theme-bg-primary":     "#0e1014",
      "--theme-bg-secondary":   "#16181f",
      "--theme-accent":         "rgba(0, 240, 255, 0.95)",
      "--theme-accent-glow":    "rgba(255, 43, 214, 0.55)",
      "--theme-glass":          "rgba(0, 240, 255, 0.04)",
      "--theme-glass-border":   "rgba(0, 240, 255, 0.55)",         // thin neon edge
      "--theme-text-primary":   "rgba(240, 248, 255, 0.96)",
      "--theme-text-secondary": "rgba(180, 220, 240, 0.65)",
      "--theme-particle":       "rgba(255, 43, 214, 0.30)",
      "--theme-tint":           "transparent",
      "--theme-tint-opacity":   "0",
      "--theme-font-sans":      "'Inter Variable', 'Inter', system-ui, sans-serif",
      "--theme-font-weight":    "420",
      "--theme-letter-spacing": "0.01em",
      "--theme-glass-blur":     "20px",
      "--theme-glass-saturate": "180%",
      // Faint grid mesh — repeating linear-gradient lines on both axes.
      "--theme-texture":
        "linear-gradient(rgba(0,240,255,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(255,43,214,0.05) 1px, transparent 1px)",
      "--theme-texture-opacity":"0.55",
      "--theme-texture-size":   "44px 44px",
    },
  },

  easter: {
    name:        "Easter",
    description: "Soft pastels, floating eggs and springtime joy",
    preview:     ["#f5eeff", "#e8d5f5", "#b8f0d8"],
    vars: {
      "--theme-bg-primary":     "#f0eaff",
      "--theme-bg-secondary":   "#e8ddf8",
      "--theme-accent":         "rgba(160, 100, 220, 0.8)",
      "--theme-accent-glow":    "rgba(200, 160, 255, 0.4)",
      "--theme-glass":          "rgba(255, 255, 255, 0.2)",
      "--theme-glass-border":   "rgba(255, 255, 255, 0.55)",
      "--theme-text-primary":   "rgba(60, 30, 80, 0.88)",
      "--theme-text-secondary": "rgba(120, 80, 150, 0.55)",
      "--theme-particle":       "rgba(200, 160, 255, 0.5)",
      "--theme-tint":           "transparent",
      "--theme-tint-opacity":   "0",
    },
    animations: ["easter-eggs"],
  },
};

export const DEFAULT_THEME: ThemeKey = "midnight";

export function isThemeKey(v: unknown): v is ThemeKey {
  return typeof v === "string" && v in TETHER_THEMES;
}

const LOCAL_STORAGE_KEY = "tether_my_theme";

/**
 * Apply a theme by setting the 9 CSS custom properties on `:root`.
 * Also persists the choice locally so the next page-load can apply it
 * before the network round-trip to Supabase finishes.
 */
export function applyTheme(themeKey: ThemeKey | string): void {
  const key: ThemeKey = isThemeKey(themeKey) ? themeKey : DEFAULT_THEME;
  const theme = TETHER_THEMES[key];
  const root = document.documentElement;
  for (const [k, v] of Object.entries(theme.vars)) {
    root.style.setProperty(k, v);
  }
  // Tag the body for css-only animations / transitions if needed.
  document.body.dataset.tetherTheme = key;
  try { localStorage.setItem(LOCAL_STORAGE_KEY, key); } catch { /* ignore */ }
  // Mount/swap any seasonal animation containers (snow, leaves,
  // shamrocks, eggs, campfire scene) and toggle the body.theme-{key}
  // class that the seasonal CSS rules in themes.css key off of.
  applyThemeAnimations(key);
  // Notify React listeners so theme-aware decorations (snowflakes,
  // Santa, balloons) swap immediately even when the change came in
  // via Supabase realtime rather than a local action.
  try {
    window.dispatchEvent(new CustomEvent(THEME_CHANGE_EVENT, { detail: key }));
  } catch { /* ignore — non-browser env */ }
}

// ──────────────────────────────────────────────────────────────────────
// Seasonal theme animation layers
// ──────────────────────────────────────────────────────────────────────
// applyThemeAnimations is invoked by applyTheme() above. It manages a
// `theme-{key}` body class so seasonal CSS in themes.css can scope
// safely, then tears down any existing seasonal DOM nodes and (re)builds
// them for the new theme. All builders are idempotent — they create
// fresh nodes each time the theme changes.
const SEASONAL_CONTAINER_SELECTORS: readonly string[] = [
  ".christmas-snow-container",
  ".autumn-leaves-container",
  ".stpatricks-container",
  ".easter-container",
  ".camping-scene",
];

export function applyThemeAnimations(themeKey: ThemeKey | string): void {
  if (typeof document === "undefined") return;
  const key: ThemeKey = isThemeKey(themeKey) ? themeKey : DEFAULT_THEME;

  // Diagnostic — confirms this entry point fires on every theme switch.
  // Useful for tracking down silent injection failures (e.g. camping
  // scene mounting before the home page is in the DOM).
  // eslint-disable-next-line no-console
  console.log("CAMPING: applyThemeAnimations called with:", key);

  // Cancel any in-flight Camping retry loop. If the user switches themes
  // mid-retry, stale injection attempts could otherwise mutate host
  // element styles (position, overflow) and inject the scene into a
  // non-Camping theme. Clearing here makes every theme switch a clean
  // teardown point.
  clearCampingRetry();

  // 1. Body classes — strip EVERY existing `theme-*` class (generic, so
  // future-added or stale legacy classes can't linger and collide with
  // the new theme), then add the active one.
  const body = document.body;
  const stale: string[] = [];
  body.classList.forEach((cls) => {
    if (cls.startsWith("theme-")) stale.push(cls);
  });
  for (const cls of stale) body.classList.remove(cls);
  body.classList.add(`theme-${key}`);

  // 2. Tear down any previously-built seasonal containers, plus any
  // hanging Christmas decorations (which live INSIDE glass cards).
  for (const sel of SEASONAL_CONTAINER_SELECTORS) {
    document.querySelectorAll(sel).forEach((el) => el.remove());
  }
  document.querySelectorAll(".christmas-decoration").forEach((el) => el.remove());

  // 3. Mount the new theme's seasonal layer.
  switch (key) {
    case "christmas":  buildChristmasAnimations(); break;
    case "autumn":     buildAutumnAnimations();    break;
    case "camping":    buildCampingScene();        break;
    case "stpatricks": buildStPatricksAnimations(); break;
    case "easter":     buildEasterAnimations();    break;
    default: /* themes without a seasonal layer */ break;
  }
}

// ── Christmas: floating snowflakes + hanging ornaments on glass cards ─
function buildChristmasAnimations(): void {
  const container = document.createElement("div");
  container.className = "christmas-snow-container";

  const flakes = ["❄", "❅", "❆", "✦", "·"];
  for (let i = 0; i < 35; i++) {
    const flake = document.createElement("div");
    flake.className = "christmas-snowflake";
    flake.textContent = flakes[Math.floor(Math.random() * flakes.length)];
    flake.style.cssText = `
      left: ${Math.random() * 100}%;
      font-size: ${Math.random() * 10 + 8}px;
      animation-duration: ${Math.random() * 6 + 5}s;
      animation-delay: ${Math.random() * 8}s;
      opacity: 0;
    `;
    container.appendChild(flake);
  }
  document.body.appendChild(container);

  // Hanging decorations on each glass card.
  const cards = document.querySelectorAll<HTMLElement>(
    '.tsp-card, .ai-widget-card, [class*="glass-card"]',
  );
  const ornaments = ["🎄", "🔴", "⭐", "🎁", "🔔"];
  cards.forEach((card, i) => {
    if (card.querySelector(".christmas-decoration")) return;
    const dec = document.createElement("div");
    dec.className = "christmas-decoration";
    dec.textContent = ornaments[i % ornaments.length];
    dec.style.cssText = `
      left: ${15 + (i % 4) * 20}%;
      animation-delay: ${i * 0.3}s;
      animation-duration: ${2.5 + (i % 3) * 0.5}s;
    `;
    card.appendChild(dec);
  });
}

// ── Autumn: drifting leaves ───────────────────────────────────────────
function buildAutumnAnimations(): void {
  const container = document.createElement("div");
  container.className = "autumn-leaves-container";

  const leaves = ["🍂", "🍁", "🍃", "🌿"];
  for (let i = 0; i < 25; i++) {
    const leaf = document.createElement("div");
    leaf.className = "autumn-leaf";
    leaf.textContent = leaves[Math.floor(Math.random() * leaves.length)];
    leaf.style.cssText = `
      left: ${Math.random() * 100}%;
      font-size: ${Math.random() * 10 + 12}px;
      animation-duration: ${Math.random() * 6 + 6}s;
      animation-delay: ${Math.random() * 8}s;
    `;
    container.appendChild(leaf);
  }
  document.body.appendChild(container);
}

// Module-level handle for the Camping retry loop. We track this so that
// applyThemeAnimations() can cancel any in-flight retries before
// switching to a different theme — otherwise stale retries would keep
// mutating host element styles (and could even inject the scene)
// after the user has moved on from Camping.
let campingRetryHandle: number | null = null;

function clearCampingRetry(): void {
  if (campingRetryHandle !== null && typeof window !== "undefined") {
    window.clearInterval(campingRetryHandle);
  }
  campingRetryHandle = null;
}

// ── Camping: tent + animated campfire inside the weather card ─────────
// Robust injection — searches across many candidate selectors, falls
// back to the first card-like element on the home page, and retries up
// to 16 times at 300ms intervals because the home page may not be in
// the DOM yet when the theme is applied at app startup. All scene
// children use inline styles so the visuals don't depend on any
// particular CSS class being present.
function buildCampingScene(): void {
  // Remove any existing scene first so re-applying the theme is idempotent.
  document.querySelectorAll(".camping-scene").forEach((el) => el.remove());

  const candidates: readonly string[] = [
    '[class*="weather"]',
    '[class*="living-sky"]',
    '[class*="sky-bg"]',
    '[class*="sky-card"]',
    '[class*="sky-wrap"]',
    '[class*="weather-card"]',
    '[class*="weather-widget"]',
    '[class*="weather-wrap"]',
    '[class*="dynamic-bg"]',
    '[class*="home-weather"]',
    '[class*="presence-card"]',
    '[class*="hub-weather"]',
    // Tether-specific: the LivingSkyHeader's gradient background layer
    // and any parallax wrappers that share the `parallax-bg` class.
    '[class*="parallax-bg"]',
  ];

  candidates.forEach((sel) => {
    const el = document.querySelector(sel);
    if (el) {
      // eslint-disable-next-line no-console
      console.log("CAMPING: Found candidate:", sel, el);
    }
  });

  function injectScene(): boolean {
    let target: HTMLElement | null = null;
    for (const sel of candidates) {
      const el = document.querySelector<HTMLElement>(sel);
      if (el) { target = el; break; }
    }

    // Fallback: the first card-like child of the home page wrapper.
    if (!target) {
      const homePage =
        document.querySelector<HTMLElement>('[data-page="home"]') ||
        document.getElementById("home-page") ||
        document.getElementById("tether-home-screen");
      if (homePage) {
        const children = Array.from(homePage.querySelectorAll<HTMLElement>("*"));
        target = children.find((el) => {
          const rect = el.getBoundingClientRect();
          return rect.height > 80 && rect.width > 200;
        }) ?? null;
      }
    }

    if (!target) {
      // eslint-disable-next-line no-console
      console.log("CAMPING: No target found yet — retrying...");
      return false;
    }

    // eslint-disable-next-line no-console
    console.log("CAMPING: Injecting scene into:", target);

    // Make sure target can host absolutely-positioned children.
    const computed = getComputedStyle(target);
    if (computed.position === "static") {
      target.style.position = "relative";
    }
    target.style.overflow = "hidden";

    const scene = document.createElement("div");
    scene.className = "camping-scene";
    scene.style.cssText = `
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 140px;
      height: 90px;
      pointer-events: none;
      z-index: 10;
    `;

    scene.innerHTML = `
      <!-- Stars layer -->
      <div class="camping-stars-layer" style="
        position:absolute;
        inset:0;
        background-image:
          radial-gradient(1px 1px at 10% 15%, rgba(255,255,255,0.9) 0%, transparent 100%),
          radial-gradient(1px 1px at 30% 8%,  rgba(255,255,255,0.7) 0%, transparent 100%),
          radial-gradient(1px 1px at 55% 20%, rgba(255,255,255,0.8) 0%, transparent 100%),
          radial-gradient(1px 1px at 78% 12%, rgba(255,255,255,0.6) 0%, transparent 100%),
          radial-gradient(1px 1px at 92% 25%, rgba(255,255,255,0.7) 0%, transparent 100%),
          radial-gradient(1px 1px at 20% 35%, rgba(255,255,255,0.5) 0%, transparent 100%),
          radial-gradient(1px 1px at 68% 5%,  rgba(255,255,255,0.8) 0%, transparent 100%),
          radial-gradient(1px 1px at 85% 30%, rgba(255,255,255,0.6) 0%, transparent 100%),
          radial-gradient(1px 1px at 45% 40%, rgba(255,255,255,0.4) 0%, transparent 100%),
          radial-gradient(1px 1px at 5%  40%, rgba(255,255,255,0.5) 0%, transparent 100%);
        animation: campingStarTwinkle 4s ease-in-out infinite;
        pointer-events: none;
      "></div>

      <!-- Tent -->
      <div class="camping-tent" style="
        position:absolute;
        bottom:0;
        left:8px;
        width:50px;
        height:42px;
      ">
        <div style="
          position:absolute;
          bottom:0;
          left:0;
          width:50px;
          height:42px;
          background:linear-gradient(160deg, #3d2b1a 0%, #2a1c0e 100%);
          clip-path: polygon(50% 0%, 100% 100%, 0% 100%);
          filter: drop-shadow(0 0 8px rgba(0,0,0,0.5));
        "></div>
        <div style="
          position:absolute;
          bottom:0;
          left:17px;
          width:16px;
          height:18px;
          background:linear-gradient(180deg, rgba(255,140,0,0.35) 0%, rgba(255,80,0,0.2) 100%);
          border-radius:8px 8px 0 0;
        "></div>
        <div class="camping-tent-glow" style="
          position:absolute;
          bottom:2px;
          left:18px;
          width:14px;
          height:14px;
          background:radial-gradient(ellipse, rgba(255,160,40,0.4) 0%, transparent 70%);
          border-radius:50%;
          animation:tentGlowPulse 2s ease-in-out infinite;
        "></div>
      </div>

      <!-- Campfire -->
      <div class="camping-fire-wrap" style="
        position:absolute;
        bottom:6px;
        right:12px;
        width:36px;
        display:flex;
        flex-direction:column;
        align-items:center;
      ">
        <!-- Smoke wisps above flames -->
        <div class="camping-smoke-wrap" style="
          position:absolute;
          bottom:38px;
          left:50%;
          transform:translateX(-50%);
          width:24px;
          height:50px;
          pointer-events:none;
        ">
          <div class="camping-smoke-particle" style="
            position:absolute;bottom:0;left:50%;
            width:8px;height:8px;
            background:rgba(200,180,160,0.3);
            border-radius:50%;
            transform:translateX(-50%);
            animation:campSmokeRise 2.5s linear infinite;
          "></div>
          <div class="camping-smoke-particle" style="
            position:absolute;bottom:0;left:50%;
            width:6px;height:6px;
            background:rgba(180,160,140,0.25);
            border-radius:50%;
            transform:translateX(-50%);
            animation:campSmokeRise 3s linear infinite 0.9s;
          "></div>
          <div class="camping-smoke-particle" style="
            position:absolute;bottom:0;left:50%;
            width:10px;height:10px;
            background:rgba(190,170,150,0.2);
            border-radius:50%;
            transform:translateX(-50%);
            animation:campSmokeRise 2.8s linear infinite 1.7s;
          "></div>
        </div>

        <!-- Flames -->
        <div class="camping-flames" style="
          position:relative;
          width:30px;
          height:34px;
          margin-bottom:-2px;
        ">
          <div style="
            position:absolute;bottom:0;left:0;
            width:12px;height:20px;
            background:linear-gradient(to top, #e85c00, #ff8c00);
            border-radius:50% 50% 20% 20%;
            transform-origin:bottom center;
            animation:campFlameFlicker 0.7s ease-in-out infinite 0.15s;
            opacity:0.75;
          "></div>
          <div style="
            position:absolute;bottom:0;left:5px;
            width:20px;height:32px;
            background:linear-gradient(to top, #cc3300, #ff6600, #ff9900, #ffcc00);
            border-radius:50% 50% 20% 20%;
            transform-origin:bottom center;
            animation:campFlameFlicker 0.55s ease-in-out infinite;
            opacity:0.95;
          "></div>
          <div style="
            position:absolute;bottom:0;left:9px;
            width:12px;height:22px;
            background:linear-gradient(to top, #ff4400, #ff8800, #ffdd00, #fffaaa);
            border-radius:50% 50% 20% 20%;
            transform-origin:bottom center;
            animation:campFlameFlicker 0.4s ease-in-out infinite 0.08s;
            opacity:0.9;
          "></div>
          <div style="
            position:absolute;bottom:2px;left:12px;
            width:6px;height:10px;
            background:linear-gradient(to top, #ffffff, #fffde0);
            border-radius:50% 50% 20% 20%;
            transform-origin:bottom center;
            animation:campFlameFlicker 0.35s ease-in-out infinite 0.05s;
            opacity:0.85;
          "></div>
          <div style="
            position:absolute;bottom:0;right:0;
            width:12px;height:18px;
            background:linear-gradient(to top, #e85c00, #ff8c00);
            border-radius:50% 50% 20% 20%;
            transform-origin:bottom center;
            animation:campFlameFlicker 0.65s ease-in-out infinite 0.2s;
            opacity:0.7;
          "></div>
        </div>

        <!-- Logs -->
        <div style="position:relative;width:32px;height:10px;">
          <div style="
            position:absolute;bottom:0;left:0;
            width:32px;height:5px;
            background:linear-gradient(90deg, #3d1c08, #5c2d0e, #3d1c08);
            border-radius:3px;
            transform:rotate(-12deg);
            transform-origin:center;
          "></div>
          <div style="
            position:absolute;bottom:0;left:0;
            width:32px;height:5px;
            background:linear-gradient(90deg, #2e1506, #4a2209, #2e1506);
            border-radius:3px;
            transform:rotate(12deg);
            transform-origin:center;
          "></div>
        </div>

        <!-- Ground glow -->
        <div style="
          width:40px;height:10px;
          background:radial-gradient(ellipse, rgba(255,100,0,0.55) 0%, transparent 70%);
          border-radius:50%;
          margin-top:-3px;
          animation:fireGroundGlow 0.55s ease-in-out infinite;
        "></div>
      </div>
    `;

    target.appendChild(scene);
    // eslint-disable-next-line no-console
    console.log("CAMPING: Scene injected successfully ✓");
    return true;
  }

  if (injectScene()) return;

  let retryCount = 0;
  campingRetryHandle = window.setInterval(() => {
    // Bail out immediately if the user has switched away from Camping
    // since the loop started. (applyThemeAnimations also clears the
    // handle proactively, but this is a defensive second line so we
    // never mutate host element styles after leaving Camping.)
    if (!document.body.classList.contains("theme-camping")) {
      // eslint-disable-next-line no-console
      console.log("CAMPING: Theme changed — aborting retry loop");
      clearCampingRetry();
      return;
    }
    retryCount++;
    // eslint-disable-next-line no-console
    console.log(`CAMPING: Retry attempt ${retryCount}`);
    if (injectScene() || retryCount >= 16) {
      clearCampingRetry();
      if (retryCount >= 16) {
        // eslint-disable-next-line no-console
        console.log("CAMPING: Max retries reached — element not found");
      }
    }
  }, 300);
}

// ── St Patrick's Day: drifting shamrocks ──────────────────────────────
function buildStPatricksAnimations(): void {
  const container = document.createElement("div");
  container.className = "stpatricks-container";

  for (let i = 0; i < 22; i++) {
    const s = document.createElement("div");
    s.className = "stpatricks-shamrock";
    s.textContent = "☘️";
    s.style.cssText = `
      left: ${Math.random() * 100}%;
      font-size: ${Math.random() * 8 + 10}px;
      animation-duration: ${Math.random() * 5 + 5}s;
      animation-delay: ${Math.random() * 7}s;
    `;
    container.appendChild(s);
  }
  document.body.appendChild(container);
}

// ── Easter: floating pastel eggs / spring symbols ─────────────────────
function buildEasterAnimations(): void {
  const container = document.createElement("div");
  container.className = "easter-container";

  const eggs = ["🥚", "🐣", "🐰", "🌸", "🌷", "🌼"];
  for (let i = 0; i < 20; i++) {
    const egg = document.createElement("div");
    egg.className = "easter-egg";
    egg.textContent = eggs[Math.floor(Math.random() * eggs.length)];
    egg.style.cssText = `
      left: ${Math.random() * 100}%;
      font-size: ${Math.random() * 10 + 12}px;
      animation-duration: ${Math.random() * 5 + 6}s;
      animation-delay: ${Math.random() * 8}s;
    `;
    container.appendChild(egg);
  }
  document.body.appendChild(container);
}

/**
 * Read whichever theme is currently applied to <body> (set by
 * applyTheme). Falls back to the local-storage cache, then default.
 * Safe to call before ThemeProvider runs.
 */
export function readActiveThemeKey(): ThemeKey {
  if (typeof document !== "undefined") {
    const k = document.body?.dataset?.tetherTheme;
    if (isThemeKey(k)) return k;
  }
  return readLocalTheme();
}

export function readLocalTheme(): ThemeKey {
  try {
    const v = localStorage.getItem(LOCAL_STORAGE_KEY);
    return isThemeKey(v) ? v : DEFAULT_THEME;
  } catch {
    return DEFAULT_THEME;
  }
}
