// ──────────────────────────────────────────────────────────────────
// Shared AI engine for Tether's three Claude-powered surfaces:
//   • Home memory widget + bottom-sheet conversation
//   • Scrapbook AI caption writer
//   • Us-page Argument Diffuser
//
// The original spec assumed Firestore + a browser-direct call to
// api.anthropic.com. Tether actually uses Supabase, and Anthropic
// blocks browser-origin requests, so this module:
//   1. Loads relationship context from Supabase (posts, date_plans,
//      time_capsules) — NOT from a non-existent Firestore.
//   2. Sends every chat through our /api/ai/chat proxy (the API
//      key never leaves the api-server).
// Voice in/out remains pure Web Speech (no proxy needed).
// ──────────────────────────────────────────────────────────────────

import { supabase } from "./supabaseClient";

// ── API URL ────────────────────────────────────────────────────────
// Mirrors the pattern used by lib/notifications.ts so the chat call
// goes through the same dev-domain → api-server proxy.
const apiUrl = (import.meta.env.VITE_API_URL as string) || "";

// ── Context types ──────────────────────────────────────────────────
export interface AIMessage {
  role: "user" | "assistant";
  content: string;
}

interface ContextMemory {
  date: string;
  caption: string;
  type: string;
  by: string;
}
interface ContextDate {
  title: string;
  date: string;
  status: string;
  notes: string;
}
interface ContextCapsule {
  title: string;
  message: string;
  openOn: string;
}
export interface RelationshipContext {
  memories: ContextMemory[];
  dates: ContextDate[];
  capsules: ContextCapsule[];
  partnerNames: { me: string; partner: string };
}

// Module-level cache. We keep it scoped to the current tether so
// switching tethers (rare, but possible during testing) invalidates.
let cachedContext: RelationshipContext | null = null;
let cachedTetherId: string | null = null;
let inflight: Promise<RelationshipContext | null> | null = null;

// ── Context loader ─────────────────────────────────────────────────
// `myName` and `partnerName` map post.author_id → "me" / "partner"
// in the formatted prompt without leaking ids to Claude. We pull
// the most recent 30 scrapbook entries, 20 dates, and 10 capsules —
// enough surface area for warm, specific responses without blowing
// the context window.
export async function loadRelationshipContext(
  tetherId: string,
  myId: string,
  myName: string,
  partnerName: string,
  force = false,
): Promise<RelationshipContext | null> {
  if (!force && cachedContext && cachedTetherId === tetherId) {
    return cachedContext;
  }
  if (inflight) return inflight;

  inflight = (async (): Promise<RelationshipContext | null> => {
    try {
      const [postsRes, datesRes, capsulesRes] = await Promise.all([
        supabase
          .from("posts")
          .select("post_type, content, image_url, author_id, created_at")
          .eq("tether_id", tetherId)
          .order("created_at", { ascending: false })
          .limit(30),
        supabase
          .from("date_plans")
          .select("title, description, plan_type, planned_date, is_completed")
          .eq("tether_id", tetherId)
          .order("planned_date", { ascending: false, nullsFirst: false })
          .limit(20),
        supabase
          .from("time_capsules")
          .select("title, message, unlock_at, unlocked")
          .eq("tether_id", tetherId)
          .order("unlock_at", { ascending: false })
          .limit(10),
      ]);

      const memories: ContextMemory[] = (postsRes.data ?? []).map((p) => ({
        date: p.created_at
          ? new Date(p.created_at).toLocaleDateString()
          : "Unknown date",
        caption: (p.content as string) || (p.image_url ? "[photo]" : ""),
        type: (p.post_type as string) || "post",
        by: p.author_id === myId ? myName : partnerName,
      }));

      const dates: ContextDate[] = (datesRes.data ?? []).map((d) => ({
        title: (d.title as string) || "",
        date: (d.planned_date as string) || "",
        status: d.is_completed
          ? "completed"
          : (d.plan_type as string) || "planned",
        notes: (d.description as string) || "",
      }));

      const capsules: ContextCapsule[] = (capsulesRes.data ?? []).map((c) => ({
        title: (c.title as string) || "",
        message: (c.message as string) || "",
        openOn: (c.unlock_at as string) || "",
      }));

      cachedContext = {
        memories,
        dates,
        capsules,
        partnerNames: { me: myName, partner: partnerName },
      };
      cachedTetherId = tetherId;
      return cachedContext;
    } catch (e) {
      console.error("[tetherAi] context load failed", e);
      return null;
    } finally {
      inflight = null;
    }
  })();

  return inflight;
}

export function getContextPrompt(): string {
  if (!cachedContext) return "";
  const { memories, dates, capsules, partnerNames } = cachedContext;
  const empty = "(none yet)";
  return `
RELATIONSHIP CONTEXT — ${partnerNames.me} & ${partnerNames.partner}:

SCRAPBOOK MEMORIES (most recent first):
${
  memories.length
    ? memories
        .map(
          (m) =>
            `- ${m.date} (posted by ${m.by}, ${m.type}): "${m.caption.slice(0, 200)}"`,
        )
        .join("\n")
    : empty
}

DATES & OUTINGS:
${
  dates.length
    ? dates
        .map(
          (d) =>
            `- ${d.title}${d.date ? ` on ${d.date}` : ""} (${d.status})${d.notes ? `: ${d.notes.slice(0, 200)}` : ""}`,
        )
        .join("\n")
    : empty
}

TIME CAPSULES:
${
  capsules.length
    ? capsules
        .map(
          (c) =>
            `- "${c.title}" — opens ${c.openOn || "TBD"}: ${c.message.slice(0, 200)}`,
        )
        .join("\n")
    : empty
}
  `.trim();
}

// ── Core chat call ─────────────────────────────────────────────────
// Universal prefix prepended to every system prompt sent through
// this module. Keeps Tether's voice consistent across the AI memory
// widget, scrapbook caption writer, and argument diffuser, and —
// critically — stops the model from ever addressing either partner
// by name. We refer to them as "you" and "your partner" only.
const NAME_NEUTRAL_RULE =
  `Never refer to either person by name. Always use "you", "your partner", ` +
  `"the two of you", "they", or "them". Speak warmly and personally without ` +
  `using proper names, even if names appear in the relationship context.\n\n`;

export async function ask(
  systemPrompt: string,
  messages: AIMessage[],
): Promise<string> {
  if (!apiUrl) {
    return "AI is not configured (missing API URL).";
  }
  try {
    const res = await fetch(`${apiUrl}/api/ai/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemPrompt: `${NAME_NEUTRAL_RULE}${systemPrompt}`,
        messages,
      }),
    });
    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      console.warn("[tetherAi] /ai/chat failed", res.status, j);
      return "Something went wrong — please try again in a moment.";
    }
    const data = (await res.json()) as { reply?: string };
    return data.reply?.trim() || "";
  } catch (e) {
    console.error("[tetherAi] ask threw", e);
    return "Couldn't reach the AI right now — try again shortly.";
  }
}

// ── Voice input (Web Speech API) ───────────────────────────────────
// We expose plain functions (no React state) so any component can
// drive voice. The component owns its own listening boolean.
//
// iOS Safari ships the `webkitSpeechRecognition` prefix; we feature-
// detect both. If neither exists (e.g. Firefox desktop) the helpers
// no-op and onEnd is called immediately so the UI can recover.
// Web Speech API isn't in the default DOM lib in this TS config,
// so we ship our own minimal structural types covering only the
// shape we actually use.
interface SRResult {
  0?: { transcript?: string };
  isFinal?: boolean;
}
interface SREvent {
  results: ArrayLike<SRResult>;
}
type SR = {
  start: () => void;
  stop: () => void;
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((e: SREvent) => void) | null;
  onend: (() => void) | null;
  onerror: ((e: unknown) => void) | null;
};

let recognition: SR | null = null;

export function isVoiceInputSupported(): boolean {
  const w = window as unknown as {
    SpeechRecognition?: unknown;
    webkitSpeechRecognition?: unknown;
  };
  return Boolean(w.SpeechRecognition || w.webkitSpeechRecognition);
}

export function startVoiceInput(
  onResult: (transcript: string, isFinal: boolean) => void,
  onEnd?: (errorMsg?: string) => void,
): boolean {
  const w = window as unknown as {
    SpeechRecognition?: new () => SR;
    webkitSpeechRecognition?: new () => SR;
  };
  const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
  if (!Ctor) {
    onEnd?.("Voice input isn't supported in this browser.");
    return false;
  }
  // Cancel any existing recogniser before starting a new one.
  try {
    recognition?.stop();
  } catch {
    /* ignore */
  }
  recognition = new Ctor();
  recognition.continuous = false;
  recognition.interimResults = true;
  recognition.lang = "en-AU";
  recognition.onresult = (e: SREvent) => {
    const results = Array.from(e.results) as SRResult[];
    const transcript = results
      .map((r) => r[0]?.transcript ?? "")
      .join("");
    const last = results[results.length - 1];
    onResult(transcript, last?.isFinal ?? false);
  };
  recognition.onend = () => onEnd?.();
  recognition.onerror = (e) => {
    console.warn("[tetherAi] voice error", e);
    onEnd?.("Voice input error.");
  };
  try {
    recognition.start();
    return true;
  } catch (e) {
    console.error("[tetherAi] voice start failed", e);
    onEnd?.("Couldn't start voice input.");
    return false;
  }
}

export function stopVoiceInput() {
  try {
    recognition?.stop();
  } catch {
    /* ignore */
  }
}

// ── Voice output (Web Speech Synthesis) ────────────────────────────
export function speak(text: string) {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = "en-AU";
  u.rate = 0.95;
  u.pitch = 1.0;
  // Preferred voices — Samantha (iOS), Karen (AU), Daniel (UK), or
  // any en-AU voice as a fallback. If none match the browser picks
  // its default.
  const voices = window.speechSynthesis.getVoices();
  const preferred = voices.find(
    (v) =>
      v.name.includes("Samantha") ||
      v.name.includes("Karen") ||
      v.name.includes("Daniel") ||
      v.lang === "en-AU",
  );
  if (preferred) u.voice = preferred;
  window.speechSynthesis.speak(u);
}

export function stopSpeaking() {
  if ("speechSynthesis" in window) window.speechSynthesis.cancel();
}
