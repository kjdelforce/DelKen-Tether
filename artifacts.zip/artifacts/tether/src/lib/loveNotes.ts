// ═══════════════════════════════════════════════════════════
//  loveNotes.ts — Sealed handwritten note CRUD
//  ─────────────────────────────────────────────────────────────
//  Backs the Love Note Drop feature: a partner writes a note,
//  it floats sealed on the recipient's Home screen until they
//  tap to unfold it. Read notes are archived forever in the
//  Keepsake Drawer on the Profile Hub.
// ═══════════════════════════════════════════════════════════
import { supabase } from "./supabaseClient";

export interface LoveNote {
  id: string;
  tether_id: string;
  sender_id: string;
  recipient_id: string;
  note_text: string;
  is_read: boolean;
  read_at: string | null;
  created_at: string;
}

export const LOVE_NOTE_MAX_LENGTH = 400;

/** Newest unread note for a recipient, or null if none. */
export async function getUnreadNoteForUser(
  recipientId: string,
): Promise<LoveNote | null> {
  const { data, error } = await supabase
    .from("love_notes")
    .select("*")
    .eq("recipient_id", recipientId)
    .eq("is_read", false)
    .order("created_at", { ascending: false })
    .limit(1);
  if (error) {
    console.warn("[loveNotes] getUnreadNoteForUser failed", error.message);
    return null;
  }
  return (data?.[0] as LoveNote) ?? null;
}

/** Every read note ever sent to this recipient, newest first. */
export async function getReadNotesForUser(
  recipientId: string,
): Promise<LoveNote[]> {
  const { data, error } = await supabase
    .from("love_notes")
    .select("*")
    .eq("recipient_id", recipientId)
    .eq("is_read", true)
    .order("created_at", { ascending: false });
  if (error) {
    console.warn("[loveNotes] getReadNotesForUser failed", error.message);
    return [];
  }
  return (data ?? []) as LoveNote[];
}

/** Insert a new sealed note. Returns the inserted row or an error message. */
export async function sendLoveNote(args: {
  tetherId: string;
  senderId: string;
  recipientId: string;
  noteText: string;
}): Promise<{ data: LoveNote | null; error: string | null }> {
  const text = args.noteText.trim();
  if (!text) return { data: null, error: "Note is empty" };
  if (text.length > LOVE_NOTE_MAX_LENGTH) {
    return { data: null, error: `Notes must be ${LOVE_NOTE_MAX_LENGTH} characters or fewer` };
  }
  const { data, error } = await supabase
    .from("love_notes")
    .insert({
      tether_id: args.tetherId,
      sender_id: args.senderId,
      recipient_id: args.recipientId,
      note_text: text,
    })
    .select()
    .single();
  if (error) {
    console.error("[loveNotes] sendLoveNote", error);
    return { data: null, error: error.message };
  }
  return { data: data as LoveNote, error: null };
}

/** Mark a note as read (only the recipient may do this — enforced by RLS). */
export async function markNoteRead(noteId: string): Promise<void> {
  const { error } = await supabase
    .from("love_notes")
    .update({ is_read: true, read_at: new Date().toISOString() })
    .eq("id", noteId);
  if (error) {
    console.warn("[loveNotes] markNoteRead failed", error.message);
  }
}
