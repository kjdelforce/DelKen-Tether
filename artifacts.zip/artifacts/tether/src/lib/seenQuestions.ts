// ═══════════════════════════════════════════════════════════
//  seenQuestions.ts — Per-couple "no repeat" question tracker
//  ─────────────────────────────────────────────────────────────
//  Used by every game that picks from a fixed question pool
//  (Trivia, Daily Connection, Daily Naughty, Couples Corner).
//
//  Two-tier persistence:
//    1. localStorage  — instant reads, survives reloads.
//    2. Supabase      — sync across devices and partners. The
//                       seen_questions table is keyed by
//                       (tether_id, game_key, question_id) so
//                       both partners share the same seen set.
//
//  When the entire pool has been seen, the tracker resets the
//  seen set (per game per couple) so the cycle starts fresh.
//
//  The "id" of a question can be anything stable for the pool:
//  for arrays of strings we use the integer index as a string.
// ═══════════════════════════════════════════════════════════
import { supabase } from "./supabaseClient";

export type GameKey =
  | "trivia"
  | "daily_connection"
  | "daily_naughty"
  | "couples_corner";

const LS_PREFIX = "tether:seen:";

function lsKey(coupleId: string, gameKey: GameKey): string {
  return `${LS_PREFIX}${coupleId}:${gameKey}`;
}

function readLocal(coupleId: string, gameKey: GameKey): Set<string> {
  try {
    const raw = localStorage.getItem(lsKey(coupleId, gameKey));
    if (!raw) return new Set();
    const arr = JSON.parse(raw) as string[];
    return new Set(arr);
  } catch {
    return new Set();
  }
}

function writeLocal(coupleId: string, gameKey: GameKey, set: Set<string>): void {
  try {
    localStorage.setItem(lsKey(coupleId, gameKey), JSON.stringify([...set]));
  } catch {
    /* quota / disabled — non-fatal */
  }
}

// ── Public API ────────────────────────────────────────────────
/**
 * Hydrate the local cache from Supabase. Call once on mount in
 * any component that uses the tracker — both partners stay in
 * sync because Supabase is the source of truth.
 */
export async function hydrateSeenQuestions(
  coupleId: string,
  gameKey: GameKey,
): Promise<Set<string>> {
  const local = readLocal(coupleId, gameKey);
  try {
    const { data, error } = await supabase
      .from("seen_questions")
      .select("question_id")
      .eq("tether_id", coupleId)
      .eq("game_key", gameKey);
    if (error) {
      console.warn("[seenQuestions] hydrate failed", error.message);
      return local;
    }
    const merged = new Set<string>(local);
    for (const row of data ?? []) {
      merged.add(String((row as { question_id: string }).question_id));
    }
    writeLocal(coupleId, gameKey, merged);
    return merged;
  } catch (e) {
    console.warn("[seenQuestions] hydrate threw", e);
    return local;
  }
}

/** Synchronous read of the local cache. Always available. */
export function getSeenIds(coupleId: string, gameKey: GameKey): Set<string> {
  return readLocal(coupleId, gameKey);
}

/**
 * Mark a question seen for this couple. Writes locally first
 * (instant) then upserts to Supabase. Idempotent — duplicate
 * inserts are ignored at the DB level via the unique constraint.
 */
export async function markSeen(
  coupleId: string,
  gameKey: GameKey,
  questionId: string,
): Promise<void> {
  const set = readLocal(coupleId, gameKey);
  if (set.has(questionId)) return;
  set.add(questionId);
  writeLocal(coupleId, gameKey, set);
  try {
    await supabase
      .from("seen_questions")
      .upsert(
        {
          tether_id: coupleId,
          game_key: gameKey,
          question_id: questionId,
        },
        { onConflict: "tether_id,game_key,question_id", ignoreDuplicates: true },
      );
  } catch (e) {
    console.warn("[seenQuestions] mark sync failed", e);
  }
}

/**
 * Reset the seen set for this game/couple. Called automatically
 * when the entire pool has been exhausted so questions cycle.
 */
export async function resetSeen(
  coupleId: string,
  gameKey: GameKey,
): Promise<void> {
  writeLocal(coupleId, gameKey, new Set());
  try {
    await supabase
      .from("seen_questions")
      .delete()
      .eq("tether_id", coupleId)
      .eq("game_key", gameKey);
  } catch (e) {
    console.warn("[seenQuestions] reset failed", e);
  }
}

/**
 * Filter an array of question IDs to only those NOT yet seen.
 * If everything has been seen, returns the full pool (and
 * triggers a background reset).
 */
export function filterUnseen(
  ids: string[],
  coupleId: string,
  gameKey: GameKey,
): string[] {
  const seen = readLocal(coupleId, gameKey);
  const unseen = ids.filter((id) => !seen.has(id));
  if (unseen.length === 0) {
    void resetSeen(coupleId, gameKey);
    return ids;
  }
  return unseen;
}

/**
 * Pick a random question ID from a pool, biased to unseen ones.
 * Returns the chosen id (caller decides when / whether to mark
 * it seen — usually right after rendering).
 */
export function pickUnseenId(
  ids: string[],
  coupleId: string,
  gameKey: GameKey,
): string {
  const pool = filterUnseen(ids, coupleId, gameKey);
  return pool[Math.floor(Math.random() * pool.length)];
}

/**
 * Pick a deterministic-but-unseen index from a pool given a
 * numeric seed (so two clients with the same seed + same seen
 * set converge on the same pick — used by date-based games).
 */
export function pickUnseenIndexSeeded(
  poolSize: number,
  seed: number,
  coupleId: string,
  gameKey: GameKey,
  excludeIndices: ReadonlySet<number> = new Set<number>(),
): number {
  const seen = readLocal(coupleId, gameKey);
  const candidates: number[] = [];
  for (let i = 0; i < poolSize; i++) {
    if (excludeIndices.has(i)) continue;
    if (!seen.has(String(i))) candidates.push(i);
  }
  let pool = candidates;
  if (pool.length === 0) {
    // Everyone seen — recycle. Don't trigger a remote reset here
    // (the date-based caller may run multiple picks per render);
    // a single resetSeen() call later, or natural growth, suffices.
    pool = [];
    for (let i = 0; i < poolSize; i++) {
      if (!excludeIndices.has(i)) pool.push(i);
    }
    if (pool.length === 0) pool = [0];
  }
  // Deterministic pick from the unseen pool using the supplied seed.
  let s = (seed >>> 0) || 1;
  s = (s * 16807) % 2147483647;
  return pool[s % pool.length];
}

/**
 * Convenience: given a string-array pool, returns one random
 * unseen string. Marks it seen automatically before returning.
 */
export async function getRandomUnseenQuestion(
  pool: readonly string[],
  coupleId: string,
  gameKey: GameKey,
): Promise<string> {
  const ids = pool.map((_, i) => String(i));
  const pick = pickUnseenId(ids, coupleId, gameKey);
  await markSeen(coupleId, gameKey, pick);
  return pool[Number(pick)] ?? pool[0];
}
