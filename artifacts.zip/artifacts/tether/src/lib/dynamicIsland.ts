// Tether — Dynamic Island show API.
//
// A tiny pub/sub the rest of the app can call without importing React.
// `<DynamicIsland/>` is mounted once at App root and subscribes to this
// channel. Calling `showIsland({...})` triggers the pill banner.
//
// Kept framework-free so background/event handlers (Supabase realtime,
// service-worker shims, etc.) can fire it without React context.

export interface IslandPayload {
  icon:      string;          // emoji shown in the left circle
  title:     string;          // primary line
  sub:       string;          // secondary line
  duration?: number;          // ms before auto-collapse, default 3200
}

type Listener = (payload: IslandPayload) => void;

const listeners = new Set<Listener>();

export function showIsland(payload: IslandPayload): void {
  for (const fn of listeners) fn(payload);
}

export function subscribeIsland(fn: Listener): () => void {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}

// Convenience helpers — match the spec's named functions so callers
// don't have to remember the icon/title conventions.
export function showPulseIsland(senderName?: string): void {
  showIsland({
    icon:     "💓",
    title:    `${senderName?.trim() || "Your person"} pulsed you`,
    sub:      "Thinking of you right now",
    duration: 3500,
  });
}

export function showNewMemoryIsland(posterName?: string): void {
  showIsland({
    icon:     "📸",
    title:    "New memory added",
    sub:      `${posterName?.trim() || "Your partner"} added to your Scrapbook`,
    duration: 3200,
  });
}
