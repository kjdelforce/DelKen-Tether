import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { supabase, Profile, Tether } from "./supabaseClient";

/* ──────────────────────────────────────────────────────────────────
   AuthContext — DUAL auth support
   ──────────────────────────────────────────────────────────────────
   Two paths into the app:

   (A) LEGACY invite-code login
       • `loginWithInviteCode(name, code)` — kept verbatim from v1 so
         Kyle & Nathan never lose access to their existing data.
       • Stores `tether_profile_id` in localStorage.
       • profile.auth_user_id stays NULL.

   (B) NEW Supabase email/password
       • `signUpWithEmail` → creates auth user, returns id; the
         OnboardingWizard then creates/joins a tether and a profile
         row linked via `auth_user_id`.
       • `signInWithEmail` → resolves the linked profile and hydrates
         the same context shape (profile + partner + tether).

   Either path leaves the context exposing the same fields, so the
   rest of the app doesn't care which one signed you in.
   ────────────────────────────────────────────────────────────────── */

type SignUpResult =
  | { error: string; userId?: undefined }
  | { error: null; userId: string };

type AuthContextType = {
  profile: Profile | null;
  partnerProfile: Profile | null;
  tether: Tether | null;
  loading: boolean;

  // Legacy path (kept for backwards compatibility — Kyle & Nathan).
  login: (fullName: string, inviteCode: string) => Promise<{ error: string | null }>;
  loginWithInviteCode: (fullName: string, inviteCode: string) => Promise<{ error: string | null }>;

  // New email/password path (multi-tenant onboarding).
  signUpWithEmail: (email: string, password: string) => Promise<SignUpResult>;
  signInWithEmail:  (email: string, password: string) => Promise<{ error: string | null }>;

  // Onboarding helpers — used by the wizard after sign-up.
  createCoupleAndProfile: (args: {
    authUserId: string;
    email: string;
    firstName: string;
  }) => Promise<{ error: string | null; tetherId?: string; inviteCode?: string }>;
  joinCoupleByCode: (args: {
    authUserId: string;
    email: string;
    firstName: string;
    inviteCode: string;
  }) => Promise<{ error: string | null }>;
  saveRelationshipDetails: (args: {
    startDate: string;
    myBirthday: string;
    partnerBirthday?: string;
  }) => Promise<{ error: string | null }>;

  /** Edit any subset of relationship dates from Settings → Edit Info.
   *  Pass `null` to clear a value, omit the key to leave it unchanged.
   *  All inputs are ISO date strings (`YYYY-MM-DD`). */
  updateRelationshipInfo: (args: {
    anniversaryDate?: string | null;
    myBirthday?: string | null;
    partnerBirthday?: string | null;
  }) => Promise<{ error: string | null }>;

  logout: () => void;
  reload: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

/* Generate a 6-char alphanumeric invite code (uppercase). */
function generateInviteCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < 6; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [partnerProfile, setPartnerProfile] = useState<Profile | null>(null);
  const [tether, setTether] = useState<Tether | null>(null);
  const [loading, setLoading] = useState(true);

  /* On mount: prefer Supabase Auth session, then fall back to
     the legacy localStorage profile id. */
  useEffect(() => {
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user?.id) {
        const ok = await loadProfileByAuthUser(session.user.id);
        if (ok) { setLoading(false); return; }
      }
      const storedId = localStorage.getItem("tether_profile_id");
      if (storedId) await loadSession(storedId);
      else setLoading(false);
    })();
  }, []);

  async function loadSession(profileId: string) {
    const { data: prof, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", profileId)
      .single();

    if (error || !prof) {
      localStorage.removeItem("tether_profile_id");
      setLoading(false);
      return;
    }

    setProfile(prof);
    if (prof.tether_id) await loadTetherAndPartner(prof);
    setLoading(false);
  }

  async function loadProfileByAuthUser(authUserId: string): Promise<boolean> {
    const { data: prof } = await supabase
      .from("profiles")
      .select("*")
      .eq("auth_user_id", authUserId)
      .maybeSingle();
    if (!prof) return false;
    setProfile(prof);
    localStorage.setItem("tether_profile_id", prof.id);
    if (prof.tether_id) await loadTetherAndPartner(prof);
    return true;
  }

  async function loadTetherAndPartner(prof: Profile) {
    if (!prof.tether_id) return;

    const { data: tet } = await supabase
      .from("tethers")
      .select("*")
      .eq("id", prof.tether_id)
      .single();

    if (tet) setTether(tet);

    const { data: partners } = await supabase
      .from("profiles")
      .select("*")
      .eq("tether_id", prof.tether_id)
      .neq("id", prof.id);

    if (partners && partners.length > 0) {
      setPartnerProfile(partners[0]);
    }
  }

  /* ── LEGACY: invite-code login (Kyle & Nathan) ─────────────── */
  async function loginWithInviteCode(fullName: string, inviteCode: string): Promise<{ error: string | null }> {
    const trimmedName = fullName.trim();
    const trimmedCode = inviteCode.trim().toUpperCase();

    if (!trimmedName || trimmedCode.length !== 6) {
      return { error: "Please enter your name and a 6-digit Tether Code." };
    }

    let currentTether: Tether | null = null;
    const { data: existingTether } = await supabase
      .from("tethers")
      .select("*")
      .eq("invite_code", trimmedCode)
      .single();

    if (existingTether) {
      currentTether = existingTether;
    } else {
      const { data: newTether, error: tetherError } = await supabase
        .from("tethers")
        .insert({ id: crypto.randomUUID(), invite_code: trimmedCode })
        .select()
        .single();
      if (tetherError || !newTether) return { error: tetherError?.message || "Failed to create tether." };
      currentTether = newTether;
    }

    const { data: tetherProfiles } = await supabase
      .from("profiles")
      .select("*")
      .eq("tether_id", currentTether!.id);

    const existing = tetherProfiles ?? [];

    const matchedProfile = existing.find(
      (p) => p.full_name.trim().toLowerCase() === trimmedName.toLowerCase()
    );
    if (matchedProfile) {
      setProfile(matchedProfile);
      setTether(currentTether);
      localStorage.setItem("tether_profile_id", matchedProfile.id);
      await loadTetherAndPartner(matchedProfile);
      return { error: null };
    }

    if (existing.length >= 2) {
      const names = existing.map((p) => p.full_name).join(" or ");
      return { error: `This Tether Code is already connected to ${names}. Check your name spelling and try again.` };
    }

    const firstName = trimmedName.split(" ")[0];
    const { data: newProfile, error: profileError } = await supabase
      .from("profiles")
      .insert({
        id: crypto.randomUUID(),
        full_name: trimmedName,
        first_name: firstName,
        tether_id: currentTether!.id,
        role: existing.length === 0 ? "primary" : "member",
      })
      .select()
      .single();

    if (profileError || !newProfile) return { error: profileError?.message || "Failed to create profile." };

    setProfile(newProfile);
    setTether(currentTether);
    localStorage.setItem("tether_profile_id", newProfile.id);
    await loadTetherAndPartner(newProfile);

    return { error: null };
  }

  /* ── NEW: email/password sign up + sign in ─────────────────── */
  async function signUpWithEmail(email: string, password: string): Promise<SignUpResult> {
    const { data, error } = await supabase.auth.signUp({ email: email.trim(), password });
    if (error) return { error: error.message };
    if (!data.user?.id) return { error: "Sign up failed — no user id returned." };
    return { error: null, userId: data.user.id };
  }

  async function signInWithEmail(email: string, password: string): Promise<{ error: string | null }> {
    const { data, error } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    if (error) return { error: error.message };
    if (!data.user?.id) return { error: "Sign in failed." };

    const ok = await loadProfileByAuthUser(data.user.id);
    if (!ok) return { error: "No Tether profile linked to this account yet. Please complete onboarding." };
    return { error: null };
  }

  /* ── Onboarding helpers ───────────────────────────────────── */
  async function createCoupleAndProfile(args: {
    authUserId: string;
    email: string;
    firstName: string;
  }): Promise<{ error: string | null; tetherId?: string; inviteCode?: string }> {
    // Try up to 5 times to insert a tether with a unique invite code.
    // The invite_code column has a UNIQUE constraint after the
    // onboarding_v1_part2_security migration, so collisions surface
    // as Postgres error 23505. Re-generate and retry on conflict.
    const tetherId = crypto.randomUUID();
    let inviteCode = generateInviteCode();
    let lastErr: string | null = null;
    for (let attempt = 0; attempt < 5; attempt++) {
      const { error: tetherError } = await supabase
        .from("tethers")
        .insert({ id: tetherId, invite_code: inviteCode });
      if (!tetherError) { lastErr = null; break; }
      lastErr = tetherError.message;
      if (tetherError.code === "23505") {
        inviteCode = generateInviteCode();
        continue;
      }
      return { error: tetherError.message };
    }
    if (lastErr) return { error: lastErr };

    const profileId = crypto.randomUUID();
    const { data: prof, error: profileError } = await supabase
      .from("profiles")
      .insert({
        id: profileId,
        full_name: args.firstName,
        first_name: args.firstName,
        email: args.email,
        auth_user_id: args.authUserId,
        tether_id: tetherId,
        role: "primary",
      })
      .select()
      .single();

    // Pseudo-rollback: if the profile insert fails, delete the orphan
    // tether so a retry produces clean state instead of accumulating
    // empty couples. Best-effort — failure here is non-fatal.
    if (profileError || !prof) {
      await supabase.from("tethers").delete().eq("id", tetherId);
      return { error: profileError?.message || "Failed to create profile." };
    }

    setProfile(prof);
    localStorage.setItem("tether_profile_id", prof.id);
    await loadTetherAndPartner(prof);

    return { error: null, tetherId, inviteCode };
  }

  async function joinCoupleByCode(args: {
    authUserId: string;
    email: string;
    firstName: string;
    inviteCode: string;
  }): Promise<{ error: string | null }> {
    const code = args.inviteCode.trim().toUpperCase();
    if (code.length !== 6) return { error: "Invite code must be 6 characters." };

    const { data: tet } = await supabase
      .from("tethers")
      .select("*")
      .eq("invite_code", code)
      .maybeSingle();
    if (!tet) return { error: "No Tether found with that code. Check with your partner." };

    const { data: existing } = await supabase
      .from("profiles")
      .select("*")
      .eq("tether_id", tet.id);

    if ((existing?.length ?? 0) >= 2) {
      return { error: "This Tether already has two members." };
    }

    const profileId = crypto.randomUUID();
    const { data: prof, error: profileError } = await supabase
      .from("profiles")
      .insert({
        id: profileId,
        full_name: args.firstName,
        first_name: args.firstName,
        email: args.email,
        auth_user_id: args.authUserId,
        tether_id: tet.id,
        role: "member",
      })
      .select()
      .single();
    if (profileError || !prof) return { error: profileError?.message || "Failed to create profile." };

    setProfile(prof);
    localStorage.setItem("tether_profile_id", prof.id);
    await loadTetherAndPartner(prof);

    return { error: null };
  }

  async function saveRelationshipDetails(args: {
    startDate: string;
    myBirthday: string;
    partnerBirthday?: string;
  }): Promise<{ error: string | null }> {
    if (!profile?.id || !profile.tether_id) {
      return { error: "Not signed in." };
    }

    // 1. Update couple's start_date.
    const { error: tetherErr } = await supabase
      .from("tethers")
      .update({ start_date: args.startDate, anniversary_date: args.startDate })
      .eq("id", profile.tether_id);
    if (tetherErr) return { error: tetherErr.message };

    // 2. Update self birthday.
    const { error: meErr } = await supabase
      .from("profiles")
      .update({ birthday: args.myBirthday })
      .eq("id", profile.id);
    if (meErr) return { error: meErr.message };

    // 3. If partner exists and partnerBirthday provided, update them.
    if (args.partnerBirthday && partnerProfile?.id) {
      await supabase
        .from("profiles")
        .update({ birthday: args.partnerBirthday })
        .eq("id", partnerProfile.id);
    }

    await reload();
    return { error: null };
  }

  async function updateRelationshipInfo(args: {
    anniversaryDate?: string | null;
    myBirthday?: string | null;
    partnerBirthday?: string | null;
  }): Promise<{ error: string | null }> {
    if (!profile?.id || !profile.tether_id) {
      return { error: "Not signed in." };
    }

    // 1. Update tether anniversary (mirrored to start_date so both
    //    columns stay in sync — they represent the same UX concept).
    if (args.anniversaryDate !== undefined) {
      const { error: tetherErr } = await supabase
        .from("tethers")
        .update({
          anniversary_date: args.anniversaryDate,
          start_date:       args.anniversaryDate,
        })
        .eq("id", profile.tether_id);
      if (tetherErr) return { error: tetherErr.message };
    }

    // 2. Update self birthday.
    if (args.myBirthday !== undefined) {
      const { error: meErr } = await supabase
        .from("profiles")
        .update({ birthday: args.myBirthday })
        .eq("id", profile.id);
      if (meErr) return { error: meErr.message };
    }

    // 3. Update partner birthday (if partner profile exists).
    if (args.partnerBirthday !== undefined && partnerProfile?.id) {
      const { error: pErr } = await supabase
        .from("profiles")
        .update({ birthday: args.partnerBirthday })
        .eq("id", partnerProfile.id);
      if (pErr) return { error: pErr.message };
    }

    await reload();
    return { error: null };
  }

  function logout() {
    localStorage.removeItem("tether_profile_id");
    supabase.auth.signOut().catch(() => { /* swallow — legacy users aren't signed in */ });
    setProfile(null);
    setPartnerProfile(null);
    setTether(null);
  }

  async function reload() {
    const storedId = localStorage.getItem("tether_profile_id");
    if (storedId) await loadSession(storedId);
  }

  return (
    <AuthContext.Provider value={{
      profile,
      partnerProfile,
      tether,
      loading,
      login: loginWithInviteCode,         // backwards-compat alias
      loginWithInviteCode,
      signUpWithEmail,
      signInWithEmail,
      createCoupleAndProfile,
      joinCoupleByCode,
      saveRelationshipDetails,
      updateRelationshipInfo,
      logout,
      reload,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
