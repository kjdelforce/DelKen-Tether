import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error("Missing Supabase environment variables.");
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Tether = {
  id: string;
  invite_code: string;
  created_at: string;
  trivia_points: number | null;
  trivia_last_points_week: string | null;
  /** Onboarding-v1 fields. Null on legacy rows that haven't run setup. */
  start_date: string | null;
  anniversary_date: string | null;
  display_name: string | null;
};

export type TriviaAnswer = {
  id: string;
  tether_id: string;
  week_key: string;
  user_id: string;
  answer: string;
  submitted_at: string;
};

export type Profile = {
  id: string;
  full_name: string;
  avatar_url: string | null;
  tether_id: string | null;
  current_vibe: string | null;
  /** Onboarding-v1 fields. Null on legacy rows. */
  first_name: string | null;
  birthday: string | null;
  email: string | null;
  auth_user_id: string | null;
  role: "primary" | "member" | null;
  /** Set to true once the user has confirmed they are 17+ on the age gate. */
  age_verified: boolean | null;
};

export type Post = {
  id: string;
  tether_id: string;
  author_id: string;
  post_type: "nudge" | "note" | "image";
  content: string | null;
  image_url: string | null;
  created_at: string;
};

export type TetherLike = {
  id: string;
  tether_id: string;
  target_type: "post" | "plan";
  target_id: string;
  user_id: string;
  created_at: string;
};

export type TetherComment = {
  id: string;
  tether_id: string;
  target_type: "post" | "plan";
  target_id: string;
  author_id: string;
  content: string;
  created_at: string;
};

export type DatePlan = {
  id: string;
  tether_id: string;
  title: string;
  description: string | null;
  is_completed: boolean;
  // Extended fields — requires DB migration (see README)
  plan_type: "confirmed" | "bucket" | null;
  planned_date: string | null;
  image_url: string | null;
};
