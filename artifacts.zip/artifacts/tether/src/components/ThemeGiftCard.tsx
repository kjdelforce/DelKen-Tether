import { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import { haptic } from "@/lib/haptics";
import {
  TETHER_THEMES,
  applyTheme,
  isThemeKey,
  DEFAULT_THEME,
  type ThemeKey,
} from "@/lib/themes";

/**
 * Settings card: pick a theme and apply it to **yourself**, your
 * **partner**, or **both** of you.
 *
 * Replaces the old gift-only mechanic. Component name + file path
 * preserved so the existing SettingsPage import keeps working.
 *
 * On apply:
 *   - "me"      → updates my profiles.app_theme + applies locally now
 *   - "partner" → updates partner.app_theme (their realtime subscription
 *                 will recolour their app)
 *   - "both"    → both of the above
 */
type ApplyTarget = "me" | "partner" | "both";

export function ThemeGiftCard() {
  const { profile, partnerProfile } = useAuth();
  const partnerName = partnerProfile?.full_name?.split(" ")[0] ?? "Partner";

  const [myTheme,         setMyTheme]      = useState<ThemeKey>(DEFAULT_THEME);
  const [sheetOpen,       setSheetOpen]    = useState(false);
  const [selectedKey,     setSelectedKey]  = useState<ThemeKey | null>(null);
  const [target,          setTarget]       = useState<ApplyTarget>("me");
  const [busy,            setBusy]         = useState(false);
  const [appliedToast,    setAppliedToast] = useState(false);

  // Initial load — read my current theme.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!profile?.id) return;
      const { data: me } = await supabase
        .from("profiles").select("app_theme").eq("id", profile.id).single();
      if (cancelled) return;
      const v = (me as { app_theme?: string } | null)?.app_theme;
      if (isThemeKey(v)) setMyTheme(v);
    })();
    return () => { cancelled = true; };
  }, [profile?.id]);

  const themeEntries = useMemo(
    () => Object.entries(TETHER_THEMES) as [ThemeKey, typeof TETHER_THEMES[ThemeKey]][],
    [],
  );

  function openSheet() {
    haptic("light");
    setSelectedKey(myTheme); // Pre-select current theme
    setTarget("me");
    setSheetOpen(true);
  }

  function pickTheme(key: ThemeKey) {
    haptic("light");
    setSelectedKey(key);
  }

  function pickTarget(t: ApplyTarget) {
    haptic("light");
    setTarget(t);
  }

  async function handleApply() {
    if (!selectedKey || !profile?.id || busy) return;
    setBusy(true);
    haptic("medium");

    try {
      // Apply to me
      if (target === "me" || target === "both") {
        applyTheme(selectedKey);
        await supabase
          .from("profiles")
          .update({ app_theme: selectedKey })
          .eq("id", profile.id);
        setMyTheme(selectedKey);
      }
      // Apply to partner
      if ((target === "partner" || target === "both") && partnerProfile?.id) {
        await supabase
          .from("profiles")
          .update({ app_theme: selectedKey })
          .eq("id", partnerProfile.id);
      }

      setAppliedToast(true);
      setTimeout(() => setAppliedToast(false), 1800);
      setTimeout(() => setSheetOpen(false), 600);
    } finally {
      setBusy(false);
    }
  }

  const myThemeName = TETHER_THEMES[myTheme]?.name ?? "Midnight";

  // Apply button label
  const targetText =
    target === "me"      ? "yourself"
    : target === "partner" ? partnerName
    : "both of you";
  const applyLabel = selectedKey
    ? `Apply ${TETHER_THEMES[selectedKey]?.name} to ${targetText} ✦`
    : "Pick a theme to apply";

  return (
    <>
      {/* Settings card row — opens the sheet */}
      <motion.button
        whileTap={{ scale: 0.98 }}
        onClick={openSheet}
        style={{
          width: "100%",
          display: "flex", alignItems: "center", gap: 14,
          padding: "16px 18px",
          borderRadius: 18,
          background: "rgba(255,255,255,0.05)",
          border: "1px solid rgba(255,255,255,0.10)",
          backdropFilter: "blur(20px) saturate(160%)",
          WebkitBackdropFilter: "blur(20px) saturate(160%)",
          color: "white",
          textAlign: "left",
          cursor: "pointer",
          fontFamily: "'Quicksand', sans-serif",
        }}
      >
        <span style={{ fontSize: "1.6rem" }}>🎨</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ margin: 0, fontSize: "0.95rem", fontWeight: 700, color: "rgba(255,255,255,0.95)" }}>
            App Themes
          </p>
          <p style={{ margin: "2px 0 0", fontSize: "0.78rem", color: "rgba(255,255,255,0.50)" }}>
            Your theme: {myThemeName}
          </p>
        </div>
        <span style={{ fontSize: "1.4rem", color: "rgba(255,255,255,0.30)" }}>›</span>
      </motion.button>

      {/* Sheet — rendered via portal so position:fixed is relative to the
          true viewport, not the Framer Motion page-transition wrapper which
          applies scale/filter and creates a new containing block. */}
      {createPortal(
        <AnimatePresence>
        {sheetOpen && (
          <motion.div
            key="theme-sheet"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
            style={{
              position: "fixed",
              inset: 0,
              zIndex: 9100,
              display: "flex",
              alignItems: "flex-end",
            }}
          >
            {/* Backdrop */}
            <motion.div
              onClick={() => setSheetOpen(false)}
              style={{
                position: "absolute",
                inset: 0,
                background: "rgba(0,0,0,0.55)",
                backdropFilter: "blur(4px)",
                WebkitBackdropFilter: "blur(4px)",
              }}
            />

            {/* Sheet card — column flex so we can pin the footer
                (apply-to + apply button) outside the scroll area
                so it always clears the floating dock. */}
            <motion.div
              initial={{ y: 60 }}
              animate={{ y: 0 }}
              exit={{ y: 60 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              style={{
                position: "relative",
                zIndex: 1,
                width: "100%",
                maxHeight: "92vh",
                borderRadius: "28px 28px 0 0",
                background: "rgba(20,15,25,0.92)",
                backdropFilter: "blur(48px) saturate(1.8)",
                WebkitBackdropFilter: "blur(48px) saturate(1.8)",
                border: "1px solid rgba(255,255,255,0.14)",
                borderBottom: "none",
                boxShadow: "0 -4px 40px rgba(0,0,0,0.5)",
                display: "flex",
                flexDirection: "column",
                overflow: "hidden",
              }}
            >
              {/* Handle */}
              <div style={{
                width: 36, height: 4,
                borderRadius: 2,
                background: "rgba(255,255,255,0.20)",
                margin: "14px auto 0",
                flexShrink: 0,
              }} />

              {/* Pinned header — stays visible while theme grid scrolls */}
              <div style={{ flexShrink: 0, borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
                <div style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  padding: "16px 20px 12px",
                }}>
                  <h2 style={{
                    fontFamily: "'Georgia', serif",
                    fontSize: 20,
                    fontWeight: 400,
                    color: "rgba(255,255,255,0.92)",
                    margin: 0,
                  }}>
                    App Themes
                  </h2>
                  <button
                    onClick={() => setSheetOpen(false)}
                    style={{
                      background: "rgba(255,255,255,0.06)",
                      border: "1px solid rgba(255,255,255,0.10)",
                      borderRadius: 12,
                      color: "rgba(255,255,255,0.75)",
                      padding: "6px 14px",
                      fontSize: "0.82rem",
                      fontWeight: 500,
                      cursor: "pointer",
                      letterSpacing: "0.01em",
                    }}
                    aria-label="Back to Settings"
                  >
                    ← Back
                  </button>
                </div>
                <p style={{
                  fontSize: 13,
                  color: "rgba(255,255,255,0.40)",
                  padding: "0 20px 12px",
                  margin: 0,
                  fontFamily: "'Quicksand', sans-serif",
                }}>
                  Choose a theme then select who it applies to.
                </p>
              </div>

              {/* Scrollable middle: theme grid only */}
              <div style={{ flex: 1, overflowY: "auto", minHeight: 0 }}>
                {/* Theme grid */}
                <div className="tsp-theme-grid" style={{ paddingTop: 12 }}>
                  {themeEntries.map(([key, theme]) => {
                    const isSelected = selectedKey === key;
                    return (
                      <button
                        key={key}
                        onClick={() => pickTheme(key)}
                        className={`tsp-theme-option${isSelected ? " selected" : ""}`}
                        style={isSelected ? {
                          borderColor: theme.preview[2] + "55",
                        } : undefined}
                      >
                        <div className="tsp-theme-swatches">
                          {theme.preview.map((c, i) => (
                            <div key={i} className="tsp-theme-swatch" style={{ background: c }} />
                          ))}
                        </div>
                        <p className="tsp-theme-name">{theme.name}</p>
                        <p className="tsp-theme-desc">{theme.description}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Pinned footer — apply-to + apply button.
                  paddingBottom clears the floating glass dock
                  (~80px tall + iOS home-indicator inset).
                  A subtle gradient fade at the top hints there's
                  more theme content above. */}
              <div
                style={{
                  flexShrink: 0,
                  padding: "10px 20px calc(env(safe-area-inset-bottom, 0px) + 110px)",
                  background:
                    "linear-gradient(180deg, rgba(20,15,25,0) 0%, rgba(20,15,25,0.92) 22%)",
                  borderTop: "1px solid rgba(255,255,255,0.06)",
                }}
              >
                {/* Apply-to picker */}
                <div className="tsp-theme-apply-row">
                  <p className="tsp-theme-apply-label">Apply to</p>
                  <div className="tsp-theme-apply-pills">
                    <button
                      className={`tsp-apply-pill${target === "me" ? " active" : ""}`}
                      onClick={() => pickTarget("me")}
                    >
                      Me
                    </button>
                    <button
                      className={`tsp-apply-pill${target === "partner" ? " active" : ""}`}
                      onClick={() => pickTarget("partner")}
                      disabled={!partnerProfile?.id}
                      style={!partnerProfile?.id ? { opacity: 0.3, cursor: "not-allowed" } : undefined}
                    >
                      {partnerName}
                    </button>
                    <button
                      className={`tsp-apply-pill${target === "both" ? " active" : ""}`}
                      onClick={() => pickTarget("both")}
                      disabled={!partnerProfile?.id}
                      style={!partnerProfile?.id ? { opacity: 0.3, cursor: "not-allowed" } : undefined}
                    >
                      Both
                    </button>
                  </div>
                </div>

                {/* Apply button */}
                <button
                  className="tsp-theme-apply-btn"
                  onClick={handleApply}
                  disabled={!selectedKey || busy || appliedToast}
                >
                  {appliedToast ? "✓ Applied" : busy ? "Applying…" : applyLabel}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
        </AnimatePresence>,
        document.body,
      )}
    </>
  );
}
