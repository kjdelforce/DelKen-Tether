import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { createPortal } from "react-dom";
import {
  ask,
  getContextPrompt,
  isVoiceInputSupported,
  loadRelationshipContext,
  speak,
  startVoiceInput,
  stopSpeaking,
  stopVoiceInput,
  type AIMessage,
} from "@/lib/tetherAi";
import { playTap, playModalOpen } from "@/lib/sounds";
import { haptic } from "@/lib/haptics";

// ──────────────────────────────────────────────────────────────────
// Two surfaces, one component:
//   • A glass widget on the home stack showing a once-a-day insight
//     about Kyle & Nathan, with a speaker button to read it aloud.
//   • A bottom sheet (rendered via portal so it escapes the home
//     scroll container) where they can chat with the same memory.
//
// The insight is cached in localStorage with a per-day key so we
// only burn one Claude call per couple per day for the widget.
// The conversation history is component-local — it resets each
// time the sheet is reopened so we never leak yesterday's chat
// into today.
// ──────────────────────────────────────────────────────────────────

interface Props {
  tetherId: string;
  myId: string;
  myName: string;
  partnerName: string;
}

const MEMORY_SYSTEM = (myName: string, partnerName: string) =>
  `You are the Tether relationship memory for ${myName} and ${partnerName}.
You know their full relationship history from the app data below.
Answer warmly and personally, referencing real details when relevant.
Keep responses to 3 sentences or less unless they explicitly ask for more.
Speak directly to them — never about them in the third person.
${getContextPrompt()}`;

const INSIGHT_SYSTEM = (myName: string, partnerName: string) =>
  `You are the Tether relationship memory for ${myName} and ${partnerName}.
Generate ONE warm, personal observation about their relationship — like
something a close friend who knows their whole story might notice.
Maximum two sentences. No greeting, no preamble, no quotation marks.
${getContextPrompt()}`;

export function AIMemoryWidget({
  tetherId,
  myId,
  myName,
  partnerName,
}: Props) {
  const [insight, setInsight] = useState<string>("");
  const [insightLoading, setInsightLoading] = useState(true);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [messages, setMessages] = useState<AIMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [thinking, setThinking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // ── Daily insight: cache by tether + local date ────────────────
  useEffect(() => {
    let cancelled = false;
    const key = `tether_insight_${tetherId}_${new Date().toDateString()}`;
    const cached = localStorage.getItem(key);
    if (cached) {
      setInsight(cached);
      setInsightLoading(false);
      return;
    }
    (async () => {
      const ctx = await loadRelationshipContext(
        tetherId,
        myId,
        myName,
        partnerName,
      );
      // If there's literally zero context (brand-new tether) we
      // skip the AI call and show a gentle starter prompt.
      if (
        !ctx ||
        (ctx.memories.length === 0 &&
          ctx.dates.length === 0 &&
          ctx.capsules.length === 0)
      ) {
        if (!cancelled) {
          setInsight(
            `Your story is just beginning. Add a memory or plan a date and I'll start noticing patterns.`,
          );
          setInsightLoading(false);
        }
        return;
      }
      const reply = await ask(INSIGHT_SYSTEM(myName, partnerName), [
        {
          role: "user",
          content: `Give me today's insight about ${myName} and ${partnerName}.`,
        },
      ]);
      if (cancelled) return;
      if (reply) {
        setInsight(reply);
        localStorage.setItem(key, reply);
      } else {
        setInsight(`Today is a fresh page. What do you want to remember?`);
      }
      setInsightLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [tetherId, myId, myName, partnerName]);

  // ── Sheet open/close ───────────────────────────────────────────
  const openSheet = useCallback(() => {
    playModalOpen();
    haptic("light");
    setSheetOpen(true);
    if (messages.length === 0) {
      setMessages([
        {
          role: "assistant",
          content: `Hey ${myName} — ask me anything about you and ${partnerName}. Memories, patterns, favourite moments, anything.`,
        },
      ]);
    }
  }, [messages.length, myName, partnerName]);

  const closeSheet = useCallback(() => {
    haptic("tap");
    setSheetOpen(false);
    stopVoiceInput();
    stopSpeaking();
    setIsListening(false);
    setIsSpeaking(false);
  }, []);

  // ── Send a message ─────────────────────────────────────────────
  const sendMessage = useCallback(
    async (textArg?: string) => {
      const text = (textArg ?? draft).trim();
      if (!text || thinking) return;
      playTap();
      haptic("tap");
      setDraft("");
      const next: AIMessage[] = [
        ...messages,
        { role: "user", content: text },
      ];
      setMessages(next);
      setThinking(true);
      // Make sure context is loaded before asking — first message
      // could fire before the daily insight effect resolves.
      await loadRelationshipContext(tetherId, myId, myName, partnerName);
      const reply = await ask(MEMORY_SYSTEM(myName, partnerName), next);
      setThinking(false);
      if (reply) {
        setMessages((m) => [...m, { role: "assistant", content: reply }]);
      }
    },
    [draft, thinking, messages, tetherId, myId, myName, partnerName],
  );

  // Auto-scroll on new messages.
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, thinking]);

  // ── Voice input toggle ─────────────────────────────────────────
  const toggleVoice = useCallback(() => {
    if (isListening) {
      stopVoiceInput();
      setIsListening(false);
      return;
    }
    if (!isVoiceInputSupported()) {
      setMessages((m) => [
        ...m,
        {
          role: "assistant",
          content: "Voice input isn't available in this browser.",
        },
      ]);
      return;
    }
    haptic("light");
    const ok = startVoiceInput(
      (transcript, isFinal) => {
        setDraft(transcript);
        if (isFinal && transcript.trim()) {
          setIsListening(false);
          // tiny delay so the input visibly shows the final text
          setTimeout(() => sendMessage(transcript.trim()), 80);
        }
      },
      () => setIsListening(false),
    );
    if (ok) setIsListening(true);
  }, [isListening, sendMessage]);

  // ── Speak insight aloud ────────────────────────────────────────
  const toggleSpeakInsight = useCallback(() => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }
    if (!insight) return;
    haptic("tap");
    speak(insight);
    setIsSpeaking(true);
    // Web Speech doesn't reliably fire onend across browsers; we
    // estimate finish time from text length (~14 chars/sec) so the
    // button visual returns to its idle state.
    const est = Math.max(2500, insight.length * 70);
    setTimeout(() => setIsSpeaking(false), est);
  }, [isSpeaking, insight]);

  // ── Render ─────────────────────────────────────────────────────
  return (
    <>
      <motion.div
        className="ai-widget-card"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      >
        <div className="ai-widget-header">
          <span className="ai-widget-icon">✦</span>
          <span className="ai-widget-title">
            {myName} &amp; {partnerName}
          </span>
          <button
            className={`ai-widget-speak-btn${isSpeaking ? " speaking" : ""}`}
            onClick={toggleSpeakInsight}
            aria-label={isSpeaking ? "Stop reading" : "Read aloud"}
            type="button"
          >
            {isSpeaking ? "■" : "🔊"}
          </button>
        </div>

        <div className="ai-widget-insight">
          {insightLoading ? (
            <div className="ai-widget-loading" aria-label="Loading insight">
              <span /> <span /> <span />
            </div>
          ) : (
            insight
          )}
        </div>

        <button
          className="ai-widget-expand-btn"
          onClick={openSheet}
          type="button"
        >
          Ask anything about us ↗
        </button>
      </motion.div>

      {/* Bottom sheet rendered via portal so it escapes the home
        * scroll container and overlays the whole viewport. */}
      {createPortal(
        <AnimatePresence>
          {sheetOpen && (
            <>
              <motion.div
                className="ai-sheet-backdrop visible"
                onClick={closeSheet}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.25 }}
              />
              <motion.div
                className="ai-sheet open"
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{
                  type: "spring",
                  damping: 32,
                  stiffness: 280,
                }}
                role="dialog"
                aria-label="Relationship memory chat"
              >
                <div className="ai-sheet-handle" />
                <div className="ai-sheet-header">
                  <span className="ai-sheet-title">
                    ✦ Relationship Memory
                  </span>
                  <button
                    className="ai-sheet-close"
                    onClick={closeSheet}
                    aria-label="Close"
                    type="button"
                  >
                    ✕
                  </button>
                </div>

                <div className="ai-sheet-messages">
                  {messages.map((m, i) => (
                    <div
                      key={i}
                      className={`ai-msg-bubble ${m.role}`}
                    >
                      {m.content}
                    </div>
                  ))}
                  {thinking && (
                    <div className="ai-msg-bubble thinking">
                      <span className="ai-widget-loading">
                        <span /> <span /> <span />
                      </span>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                <form
                  className="ai-sheet-input-row"
                  onSubmit={(e) => {
                    e.preventDefault();
                    sendMessage();
                  }}
                >
                  <button
                    type="button"
                    className={`ai-voice-btn${isListening ? " listening" : ""}`}
                    onClick={toggleVoice}
                    aria-label={
                      isListening ? "Stop listening" : "Voice input"
                    }
                  >
                    🎤
                  </button>
                  <input
                    className="ai-sheet-input"
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    placeholder="Ask anything about us..."
                    type="text"
                    autoComplete="off"
                  />
                  <button
                    type="submit"
                    className="ai-sheet-send"
                    aria-label="Send"
                    disabled={thinking || !draft.trim()}
                  >
                    ↑
                  </button>
                </form>
              </motion.div>
            </>
          )}
        </AnimatePresence>,
        document.body,
      )}
    </>
  );
}
