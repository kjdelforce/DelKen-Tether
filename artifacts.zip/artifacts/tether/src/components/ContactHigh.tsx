// ════════════════════════════════════════════════════════════
//  ContactHigh.tsx — Synchronised "two phones meeting" moment.
//  ─────────────────────────────────────────────────────────────
//  When you and your partner physically tap your phones together,
//  ContactHigh fires a synchronised three-second sequence on
//  both screens simultaneously:
//
//    1. A glowing Liquid-Glass SPARK emerges from the inner edge
//       (the side closest to the partner's device), swirls
//       through a curved arc, and explodes against the screen.
//    2. The MESH GRADIENT vortexes — every blob pulls toward
//       the contact point, then rebounds.
//    3. A soft white BORDER FLASH halos the screen, fading back
//       through the active theme's accent colour.
//    4. A heartbeat HAPTIC pattern (75ms on / 100ms off) pulses
//       through the build-up, ramping in intensity.
//
//  Sync model
//  ──────────
//  Web Bluetooth's signal-strength scan isn't usable on iOS at
//  all and is gesture-locked on Android, so we don't gate the
//  feature on it. Instead we rely on the Supabase Realtime
//  broadcast channel that already binds the two partners. When
//  EITHER partner triggers (manually, or — in the future — via
//  a NFC tap, a deliberate phone-bump using the
//  DeviceMotion accelerometer, or an opt-in Web Bluetooth scan
//  on supported devices) the broadcast fires `contact-high` to
//  both subscribers at the same instant, so the spark visually
//  jumps the bezel gap.
//
//  Trigger from anywhere via `triggerContactHigh({ side })`.
// ════════════════════════════════════════════════════════════
import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import { hapticLoop } from "@/lib/haptics";

export type ContactSide = "top" | "bottom" | "left" | "right";

interface ContactHighEvent {
  side: ContactSide;
  /** Server-assigned timestamp so both clients animate aligned. */
  at:   number;
}

/**
 * Imperative trigger — fires the local sequence AND broadcasts
 * the event to the partner's device via the Supabase channel.
 * Pass a `side` (which edge of the screen the partner is on);
 * defaults to "top" which is the most natural phone-to-phone
 * orientation.
 */
export function triggerContactHigh(opts: { side?: ContactSide } = {}): void {
  const detail: ContactHighEvent = {
    side: opts.side ?? "top",
    at:   Date.now(),
  };
  window.dispatchEvent(new CustomEvent("tether:contact-high", { detail }));
}

const LOCAL_EVENT      = "tether:contact-high";
const BROADCAST_EVENT  = "contact-high";
const SEQUENCE_MS      = 2800;   // total sequence length

export function ContactHigh() {
  const { profile, tether } = useAuth();
  const [active, setActive] = useState<ContactHighEvent | null>(null);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  // ── Subscribe to the partner's broadcasts ─────────────────
  useEffect(() => {
    if (!tether?.id || !profile?.id) return;
    const ch = supabase
      .channel(`contact-high-${tether.id}`, {
        config: { broadcast: { ack: false, self: false } },
      })
      .on("broadcast", { event: BROADCAST_EVENT }, ({ payload }) => {
        const evt = payload as ContactHighEvent | undefined;
        if (!evt) return;
        // Mirror the partner's side — if they sent "top", they're
        // above us, so on our screen the spark should emerge from
        // OUR top edge too (the inner edge facing them).
        play(evt);
      })
      .subscribe();
    channelRef.current = ch;
    return () => {
      supabase.removeChannel(ch);
      channelRef.current = null;
    };
  }, [tether?.id, profile?.id]);

  // ── Listen for local triggers ─────────────────────────────
  useEffect(() => {
    const onLocal = (e: Event) => {
      const evt = (e as CustomEvent<ContactHighEvent>).detail;
      if (!evt) return;
      // Broadcast to the partner so their sequence starts within
      // the same realtime tick. We don't gate the local play on
      // the broadcast succeeding — local feedback fires immediately.
      channelRef.current?.send({
        type: "broadcast",
        event: BROADCAST_EVENT,
        payload: evt,
      });
      play(evt);
    };
    window.addEventListener(LOCAL_EVENT, onLocal);
    return () => window.removeEventListener(LOCAL_EVENT, onLocal);
  }, []);

  /** Internal player — composes haptics, mesh class, and spark state. */
  function play(evt: ContactHighEvent): void {
    setActive(evt);

    // Vortex the mesh — CSS rule keys off this body class.
    document.body.classList.add("contact-high-active");
    document.body.dataset.contactSide = evt.side;

    // Heartbeat haptic loop, ~9 beats over the build-up.
    // hapticLoop returns a stop fn; we stop it on completion.
    const stopHaptic = hapticLoop("heartbeat", 280);

    window.setTimeout(() => {
      stopHaptic();
      document.body.classList.remove("contact-high-active");
      delete document.body.dataset.contactSide;
      setActive(null);
    }, SEQUENCE_MS);
  }

  return (
    <AnimatePresence>
      {active && <SparkLayer key={active.at} side={active.side} />}
    </AnimatePresence>
  );
}

// ────────────────────────────────────────────────────────────
// Spark visual — the swirling Liquid-Glass orb + connection flash
// ────────────────────────────────────────────────────────────
function SparkLayer({ side }: { side: ContactSide }) {
  // Map the side to start coords (off-screen) and the apex of
  // the swirl arc. The spark always lands at the centre on
  // contact — that's the "connect" frame for the border flash.
  const path = pathForSide(side);

  return (
    <div className="contact-high-layer" aria-hidden="true">
      {/* The spark itself — refractive glass orb that swirls in. */}
      <motion.div
        className="contact-high-spark"
        initial={{ x: path.start.x, y: path.start.y, scale: 0.6, opacity: 0 }}
        animate={{
          x:       [path.start.x, path.apex.x, path.end.x],
          y:       [path.start.y, path.apex.y, path.end.y],
          scale:   [0.6, 1.2, 1.8],
          opacity: [0, 1, 1],
          rotate:  [0, 220, 360],
        }}
        transition={{
          duration: 1.6,
          times:    [0, 0.55, 1],
          ease:     [0.34, 1.2, 0.64, 1],
        }}
      />

      {/* Trailing glow streak — same path, lower opacity, lagged. */}
      <motion.div
        className="contact-high-trail"
        initial={{ x: path.start.x, y: path.start.y, opacity: 0 }}
        animate={{
          x:       [path.start.x, path.apex.x, path.end.x],
          y:       [path.start.y, path.apex.y, path.end.y],
          opacity: [0, 0.7, 0],
        }}
        transition={{ duration: 1.7, delay: 0.05, ease: "easeInOut" }}
      />

      {/* Connection flash — soft white border halo that lands on
       *  contact and fades back to the theme accent over ~1.1s. */}
      <motion.div
        className="contact-high-flash"
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 0, 1, 0] }}
        transition={{
          duration: 2.2,
          times:    [0, 0.55, 0.65, 1],
          ease:     "easeOut",
        }}
      />
    </div>
  );
}

// ────────────────────────────────────────────────────────────
// Path geometry — start off-screen on the chosen edge, arc to
// the centre. Coords are in CSS px relative to the viewport;
// the spark is positioned via translate so 0,0 is the centre.
// ────────────────────────────────────────────────────────────
function pathForSide(side: ContactSide) {
  const w = typeof window === "undefined" ? 400 : window.innerWidth;
  const h = typeof window === "undefined" ? 800 : window.innerHeight;
  const cx = 0, cy = 0;                         // centre is the destination
  const off = 60;                                // start this far off-screen
  switch (side) {
    case "top":
      return {
        start: { x:  w * 0.10, y: -h / 2 - off },
        apex:  { x: -w * 0.20, y: -h / 4       },
        end:   { x: cx,        y: cy           },
      };
    case "bottom":
      return {
        start: { x: -w * 0.10, y:  h / 2 + off },
        apex:  { x:  w * 0.20, y:  h / 4       },
        end:   { x: cx,        y: cy           },
      };
    case "left":
      return {
        start: { x: -w / 2 - off, y:  h * 0.10 },
        apex:  { x: -w / 4,       y: -h * 0.20 },
        end:   { x: cx,           y: cy        },
      };
    case "right":
      return {
        start: { x:  w / 2 + off, y: -h * 0.10 },
        apex:  { x:  w / 4,       y:  h * 0.20 },
        end:   { x: cx,           y: cy        },
      };
  }
}

export default ContactHigh;
