import { useEffect, useState } from "react";
import {
  DECORATED_THEMES,
  readActiveThemeKey,
  THEME_CHANGE_EVENT,
  type ThemeKey,
} from "@/lib/themes";

/**
 * Mounts the per-theme decoration overlay (snowflakes, Christmas
 * lights, balloons, confetti) when one of the decorated themes is
 * active. Sits as a fixed full-screen layer at z-index 9999 so it
 * paints ABOVE the body::before tint (z 9998) but BELOW the Dynamic
 * Island (z 99000) and modals. Pointer-events: none — every tap
 * passes through.
 *
 * Listens for THEME_CHANGE_EVENT so partner-gifted themes swap their
 * decorations without a page reload.
 */
export function ThemeDecorations() {
  const [key, setKey] = useState<ThemeKey>(() => readActiveThemeKey());

  useEffect(() => {
    const onChange = () => setKey(readActiveThemeKey());
    // Apply immediately in case applyTheme ran before this mounted.
    onChange();
    window.addEventListener(THEME_CHANGE_EVENT, onChange);
    return () => window.removeEventListener(THEME_CHANGE_EVENT, onChange);
  }, []);

  if (!DECORATED_THEMES.has(key)) return null;
  if (key === "christmas") return <ChristmasDecorations />;
  if (key === "birthday") return <BirthdayDecorations />;
  return null;
}

// ── Christmas: snowflakes + twinkly lights along the top edge ──
function ChristmasDecorations() {
  // 36 deterministic flakes — values are derived from the index so
  // we don't churn random positions on every re-render.
  const flakes = Array.from({ length: 36 }, (_, i) => ({
    id: i,
    left: ((i * 13.7) % 100).toFixed(2),
    delay: ((i * 0.43) % 12).toFixed(2),
    duration: 9 + (i % 7),
    size: 9 + (i % 5) * 3,
    opacity: 0.55 + (i % 4) * 0.12,
    char: i % 5 === 0 ? "❅" : "❄",
  }));

  // 28 bulbs across the top edge of the screen.
  const bulbs = Array.from({ length: 28 }, (_, i) => ({
    id: i,
    color: i % 4, // matches .xmas-bulb-{0..3} css
    delay: ((i * 0.17) % 2).toFixed(2),
  }));

  return (
    <div className="theme-deco-layer christmas-deco" aria-hidden="true">
      {flakes.map((f) => (
        <span
          key={f.id}
          className="snowflake"
          style={{
            left: `${f.left}%`,
            animationDelay: `${f.delay}s`,
            animationDuration: `${f.duration}s`,
            opacity: f.opacity,
            fontSize: `${f.size}px`,
          }}
        >
          {f.char}
        </span>
      ))}

      <div className="xmas-lights">
        {bulbs.map((b) => (
          <span
            key={b.id}
            className={`xmas-bulb xmas-bulb-${b.color}`}
            style={{ animationDelay: `${b.delay}s` }}
          />
        ))}
      </div>
    </div>
  );
}

// ── Birthday: balloons + confetti ─────────────────────────────
function BirthdayDecorations() {
  const balloons = Array.from({ length: 9 }, (_, i) => ({
    id: i,
    left: ((i * 13 + 4) % 92).toFixed(2),
    delay: ((i * 1.8) % 9).toFixed(2),
    duration: 14 + (i % 5) * 2,
    char: ["🎈", "🎈", "🎉", "🎁", "🎂"][i % 5],
    drift: i % 2 === 0 ? "balloon-drift-l" : "balloon-drift-r",
  }));

  const confetti = Array.from({ length: 48 }, (_, i) => ({
    id: i,
    left: ((i * 7.3) % 100).toFixed(2),
    delay: ((i * 0.27) % 7).toFixed(2),
    duration: 5 + (i % 6),
    color: i % 6, // matches .confetti-{0..5} css
    rotate: (i * 23) % 360,
  }));

  return (
    <div className="theme-deco-layer birthday-deco" aria-hidden="true">
      {balloons.map((b) => (
        <span
          key={`b${b.id}`}
          className={`balloon ${b.drift}`}
          style={{
            left: `${b.left}%`,
            animationDelay: `${b.delay}s`,
            animationDuration: `${b.duration}s`,
          }}
        >
          {b.char}
        </span>
      ))}

      {confetti.map((c) => (
        <span
          key={`c${c.id}`}
          className={`confetti confetti-${c.color}`}
          style={{
            left: `${c.left}%`,
            animationDelay: `${c.delay}s`,
            animationDuration: `${c.duration}s`,
            transform: `rotate(${c.rotate}deg)`,
          }}
        />
      ))}
    </div>
  );
}
