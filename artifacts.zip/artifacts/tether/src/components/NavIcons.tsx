// ═══════════════════════════════════════════════════════════
//  NavIcons.tsx — Morphing SVG glyphs for the bottom nav.
//  ─────────────────────────────────────────────────────────────
//  Each icon takes a single `active` boolean. The active state
//  morphs the SVG via framer-motion: stroke fades, fill blooms,
//  and the whole glyph scales + tilts on a soft spring for a
//  premium "lift into place" feel.
//
//  Used as `renderIcon` on the four primary tabs (Home,
//  Scrapbook, Games, Us). Inactive tabs render an outlined
//  glyph; active tabs render a filled / glowing glyph.
// ═══════════════════════════════════════════════════════════
import { motion, type Transition } from "framer-motion";

// Soft, slightly bouncy spring — premium feel without overshoot wobble.
const SPRING: Transition = { type: "spring", stiffness: 360, damping: 22, mass: 0.7 };

// Linear tween used for stroke ⇄ fill cross-fade. Avoids the
// "flicker" you get if you spring colour transitions.
const COLOUR_TWEEN: Transition = { duration: 0.28, ease: [0.22, 1, 0.36, 1] };

interface IconProps { active: boolean; }

// ── Shared wrapper ────────────────────────────────────────────
function MorphSvg({ active, children }: { active: boolean; children: React.ReactNode }) {
  return (
    <motion.svg
      viewBox="0 0 24 24"
      width={22}
      height={22}
      // Spring-driven scale + tilt: the icon "blooms" into the
      // active tab's glass bubble instead of just colour-swapping.
      animate={{ scale: active ? 1.08 : 1, rotate: active ? -2 : 0 }}
      transition={SPRING}
      style={{ display: "block", overflow: "visible" }}
    >
      {children}
    </motion.svg>
  );
}

// ── Home — house ─────────────────────────────────────────────
// Outlined ↔ filled morph. The path stays identical so framer-motion
// only animates fill / stroke, never re-renders geometry.
export function HomeNavIcon({ active }: IconProps) {
  // Roof + body as a single closed path so the fill renders cleanly.
  const HOUSE = "M4 11.2 L12 4.5 L20 11.2 L20 19.5 Q20 20.5 19 20.5 L14 20.5 L14 14.5 L10 14.5 L10 20.5 L5 20.5 Q4 20.5 4 19.5 Z";
  return (
    <MorphSvg active={active}>
      <motion.path
        d={HOUSE}
        initial={false}
        animate={{
          fill:        active ? "rgba(255,255,255,0.95)" : "rgba(255,255,255,0)",
          stroke:      active ? "rgba(255,255,255,0.95)" : "currentColor",
          strokeWidth: active ? 0.6 : 1.6,
        }}
        strokeLinejoin="round"
        strokeLinecap="round"
        transition={COLOUR_TWEEN}
      />
    </MorphSvg>
  );
}

// ── Scrapbook — open book ────────────────────────────────────
export function ScrapbookNavIcon({ active }: IconProps) {
  const BOOK_LEFT  = "M3.5 5.5 Q3.5 5 4 5 L11 5 Q11.5 5 11.5 5.5 L11.5 19 Q11.5 19.5 11 19.5 L4 19.5 Q3.5 19.5 3.5 19 Z";
  const BOOK_RIGHT = "M12.5 5.5 Q12.5 5 13 5 L20 5 Q20.5 5 20.5 5.5 L20.5 19 Q20.5 19.5 20 19.5 L13 19.5 Q12.5 19.5 12.5 19 Z";
  return (
    <MorphSvg active={active}>
      <motion.path
        d={BOOK_LEFT}
        initial={false}
        animate={{
          fill:        active ? "rgba(255,255,255,0.92)" : "rgba(255,255,255,0)",
          stroke:      active ? "rgba(255,255,255,0.95)" : "currentColor",
          strokeWidth: active ? 0.6 : 1.6,
        }}
        strokeLinejoin="round"
        transition={COLOUR_TWEEN}
      />
      <motion.path
        d={BOOK_RIGHT}
        initial={false}
        animate={{
          fill:        active ? "rgba(255,255,255,0.92)" : "rgba(255,255,255,0)",
          stroke:      active ? "rgba(255,255,255,0.95)" : "currentColor",
          strokeWidth: active ? 0.6 : 1.6,
        }}
        strokeLinejoin="round"
        transition={COLOUR_TWEEN}
      />
      {/* Spine — hairline accent that brightens when active. */}
      <motion.line
        x1="12" y1="5.4" x2="12" y2="19.1"
        initial={false}
        animate={{
          stroke:        active ? "rgba(180,140,255,0.85)" : "rgba(255,255,255,0.35)",
          strokeOpacity: active ? 1 : 0.55,
        }}
        strokeWidth={1.2}
        strokeLinecap="round"
        transition={COLOUR_TWEEN}
      />
    </MorphSvg>
  );
}

// ── Games — controller ───────────────────────────────────────
export function GamesNavIcon({ active }: IconProps) {
  // Lozenge-shaped controller body; two thumb-buttons on the right,
  // a small d-pad cross on the left.
  const BODY = "M6.5 8 L17.5 8 Q21 8 21 12 Q21 16 17.5 16 L15 16 L13.5 14.5 L10.5 14.5 L9 16 L6.5 16 Q3 16 3 12 Q3 8 6.5 8 Z";
  return (
    <MorphSvg active={active}>
      <motion.path
        d={BODY}
        initial={false}
        animate={{
          fill:        active ? "rgba(255,255,255,0.92)" : "rgba(255,255,255,0)",
          stroke:      active ? "rgba(255,255,255,0.95)" : "currentColor",
          strokeWidth: active ? 0.6 : 1.6,
        }}
        strokeLinejoin="round"
        transition={COLOUR_TWEEN}
      />
      {/* D-pad — horizontal + vertical bars */}
      <motion.line
        x1="6" y1="11.8" x2="9" y2="11.8"
        initial={false}
        animate={{ stroke: active ? "rgba(120,80,180,0.95)" : "currentColor" }}
        strokeWidth={1.4} strokeLinecap="round"
        transition={COLOUR_TWEEN}
      />
      <motion.line
        x1="7.5" y1="10.3" x2="7.5" y2="13.3"
        initial={false}
        animate={{ stroke: active ? "rgba(120,80,180,0.95)" : "currentColor" }}
        strokeWidth={1.4} strokeLinecap="round"
        transition={COLOUR_TWEEN}
      />
      {/* Two right-side buttons */}
      <motion.circle
        cx="15.4" cy="10.7" r="0.95"
        initial={false}
        animate={{
          fill:   active ? "rgba(180,80,140,0.95)" : "currentColor",
          stroke: active ? "rgba(180,80,140,0.95)" : "currentColor",
        }}
        transition={COLOUR_TWEEN}
      />
      <motion.circle
        cx="17.4" cy="12.7" r="0.95"
        initial={false}
        animate={{
          fill:   active ? "rgba(80,140,200,0.95)" : "currentColor",
          stroke: active ? "rgba(80,140,200,0.95)" : "currentColor",
        }}
        transition={COLOUR_TWEEN}
      />
    </MorphSvg>
  );
}

// ── Dates — folded map with route line ───────────────────────
export function DatesNavIcon({ active }: IconProps) {
  // Map sheet — angled like a folded paper map. Route line draws
  // diagonally across with a pin at the destination.
  const MAP = "M3.5 6 L8.5 4.5 L15.5 6.8 L20.5 5 L20.5 18 L15.5 19.5 L8.5 17.2 L3.5 19 Z";
  return (
    <MorphSvg active={active}>
      <motion.path
        d={MAP}
        initial={false}
        animate={{
          fill:        active ? "rgba(255,255,255,0.92)" : "rgba(255,255,255,0)",
          stroke:      active ? "rgba(255,255,255,0.95)" : "currentColor",
          strokeWidth: active ? 0.6 : 1.5,
        }}
        strokeLinejoin="round"
        transition={COLOUR_TWEEN}
      />
      {/* Vertical fold creases — hairlines that brighten when active. */}
      <motion.line
        x1="8.5" y1="4.5" x2="8.5" y2="17.2"
        initial={false}
        animate={{ stroke: active ? "rgba(180,140,255,0.65)" : "rgba(255,255,255,0.35)" }}
        strokeWidth={1} strokeLinecap="round"
        transition={COLOUR_TWEEN}
      />
      <motion.line
        x1="15.5" y1="6.8" x2="15.5" y2="19.5"
        initial={false}
        animate={{ stroke: active ? "rgba(180,140,255,0.65)" : "rgba(255,255,255,0.35)" }}
        strokeWidth={1} strokeLinecap="round"
        transition={COLOUR_TWEEN}
      />
      {/* Route line — squiggle from bottom-left to upper-right pin. */}
      <motion.path
        d="M6 15 Q9 11 12 12 Q15 13 16.5 9.5"
        initial={false}
        animate={{
          stroke:        active ? "rgba(255,90,120,0.95)" : "currentColor",
          strokeOpacity: active ? 1 : 0.7,
        }}
        fill="none"
        strokeWidth={1.3}
        strokeLinecap="round"
        strokeDasharray="2 1.5"
        transition={COLOUR_TWEEN}
      />
      {/* Destination pin — fills crimson when active. */}
      <motion.circle
        cx="16.5" cy="9.5" r="1.4"
        initial={false}
        animate={{
          fill:   active ? "rgba(255,90,120,0.95)" : "rgba(255,255,255,0)",
          stroke: active ? "rgba(255,255,255,0.95)" : "currentColor",
        }}
        strokeWidth={1.2}
        transition={COLOUR_TWEEN}
      />
    </MorphSvg>
  );
}

// ── Capsules — sealed time capsule with axes ─────────────────
// Glass orb sealed across two axes; inner core blooms when active.
export function CapsulesNavIcon({ active }: IconProps) {
  return (
    <MorphSvg active={active}>
      {/* Outer ring — glass shell. */}
      <motion.circle
        cx="12" cy="12" r="8"
        initial={false}
        animate={{
          fill:        active ? "rgba(180,140,255,0.18)" : "rgba(255,255,255,0)",
          stroke:      active ? "rgba(255,255,255,0.95)" : "currentColor",
          strokeWidth: active ? 0.8 : 1.6,
        }}
        transition={COLOUR_TWEEN}
      />
      {/* Inner core — small filled orb that blooms when active. */}
      <motion.circle
        cx="12" cy="12"
        initial={false}
        animate={{
          r:          active ? 4.5 : 3.5,
          fill:       active ? "rgba(180,140,255,0.95)" : "currentColor",
          fillOpacity: active ? 0.95 : 0.45,
        }}
        transition={SPRING}
      />
      {/* Cross axes — sealing lines. */}
      <motion.line
        x1="12" y1="3.6" x2="12" y2="20.4"
        initial={false}
        animate={{
          stroke:        active ? "rgba(255,255,255,0.7)" : "currentColor",
          strokeOpacity: active ? 0.9 : 0.4,
        }}
        strokeWidth={1}
        strokeLinecap="round"
        transition={COLOUR_TWEEN}
      />
      <motion.line
        x1="3.6" y1="12" x2="20.4" y2="12"
        initial={false}
        animate={{
          stroke:        active ? "rgba(255,255,255,0.7)" : "currentColor",
          strokeOpacity: active ? 0.9 : 0.4,
        }}
        strokeWidth={1}
        strokeLinecap="round"
        transition={COLOUR_TWEEN}
      />
    </MorphSvg>
  );
}

// ── Settings — gear ──────────────────────────────────────────
// Outline gear that fills + spins ~22° when active.
export function SettingsNavIcon({ active }: IconProps) {
  // 8-tooth gear path — symmetric bumps around a circle.
  const GEAR =
    "M12 3 L13.2 5 L15.5 4.4 L15.7 6.7 L17.8 7.7 L16.7 9.7 L18.4 11.3 L16.7 12.9 L17.8 14.9 L15.7 15.9 L15.5 18.2 L13.2 17.6 L12 19.6 L10.8 17.6 L8.5 18.2 L8.3 15.9 L6.2 14.9 L7.3 12.9 L5.6 11.3 L7.3 9.7 L6.2 7.7 L8.3 6.7 L8.5 4.4 L10.8 5 Z";
  return (
    <motion.svg
      viewBox="0 0 24 24"
      width={22}
      height={22}
      // Slight extra rotate on activate for a "click into place" feel.
      animate={{ scale: active ? 1.08 : 1, rotate: active ? 22 : 0 }}
      transition={SPRING}
      style={{ display: "block", overflow: "visible" }}
    >
      <motion.path
        d={GEAR}
        initial={false}
        animate={{
          fill:        active ? "rgba(255,255,255,0.92)" : "rgba(255,255,255,0)",
          stroke:      active ? "rgba(255,255,255,0.95)" : "currentColor",
          strokeWidth: active ? 0.6 : 1.5,
        }}
        strokeLinejoin="round"
        transition={COLOUR_TWEEN}
      />
      {/* Inner hole — punches through with a contrasting fill. */}
      <motion.circle
        cx="12" cy="11.3"
        initial={false}
        animate={{
          r:    active ? 2.2 : 2.6,
          fill: active ? "rgba(120,80,180,0.95)" : "rgba(255,255,255,0)",
          stroke: active ? "rgba(255,255,255,0.95)" : "currentColor",
          strokeWidth: active ? 0.6 : 1.4,
        }}
        transition={SPRING}
      />
    </motion.svg>
  );
}

// ── Us — two intertwined figures ─────────────────────────────
// Two heads + two shoulders, reading as a couple. Outline ↔ filled.
export function UsNavIcon({ active }: IconProps) {
  const LEFT_HEAD     = { cx: 8.5,  cy: 8,   r: 2.5 };
  const RIGHT_HEAD    = { cx: 15.5, cy: 8,   r: 2.5 };
  const LEFT_BODY     = "M3.5 19 Q3.5 13.5 8.5 13.5 Q12 13.5 12.8 17 L12.8 19 Z";
  const RIGHT_BODY    = "M20.5 19 Q20.5 13.5 15.5 13.5 Q12 13.5 11.2 17 L11.2 19 Z";
  return (
    <MorphSvg active={active}>
      {/* Bodies first so heads sit on top. */}
      <motion.path
        d={LEFT_BODY}
        initial={false}
        animate={{
          fill:        active ? "rgba(180,140,255,0.85)" : "rgba(255,255,255,0)",
          stroke:      active ? "rgba(255,255,255,0.95)" : "currentColor",
          strokeWidth: active ? 0.6 : 1.5,
        }}
        strokeLinejoin="round"
        transition={COLOUR_TWEEN}
      />
      <motion.path
        d={RIGHT_BODY}
        initial={false}
        animate={{
          fill:        active ? "rgba(255,140,180,0.85)" : "rgba(255,255,255,0)",
          stroke:      active ? "rgba(255,255,255,0.95)" : "currentColor",
          strokeWidth: active ? 0.6 : 1.5,
        }}
        strokeLinejoin="round"
        transition={COLOUR_TWEEN}
      />
      <motion.circle
        cx={LEFT_HEAD.cx} cy={LEFT_HEAD.cy} r={LEFT_HEAD.r}
        initial={false}
        animate={{
          fill:        active ? "rgba(180,140,255,0.95)" : "rgba(255,255,255,0)",
          stroke:      active ? "rgba(255,255,255,0.95)" : "currentColor",
          strokeWidth: active ? 0.6 : 1.5,
        }}
        transition={COLOUR_TWEEN}
      />
      <motion.circle
        cx={RIGHT_HEAD.cx} cy={RIGHT_HEAD.cy} r={RIGHT_HEAD.r}
        initial={false}
        animate={{
          fill:        active ? "rgba(255,140,180,0.95)" : "rgba(255,255,255,0)",
          stroke:      active ? "rgba(255,255,255,0.95)" : "currentColor",
          strokeWidth: active ? 0.6 : 1.5,
        }}
        transition={COLOUR_TWEEN}
      />
    </MorphSvg>
  );
}
