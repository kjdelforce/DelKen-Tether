// ═══════════════════════════════════════════════════════════
//  HeartbeatPulseBorder.tsx — Global "Pulse" border animation.
//  ─────────────────────────────────────────────────────────────
//  Mount once at the App root. Listens for the global
//  `tether-heartbeat-pulse` custom event and runs a single
//  thump-thump animation around the screen edge using a CSS
//  keyframe driving box-shadow (outer glow) and inset
//  box-shadow (inner ring), mimicking a physical heartbeat.
//
//  Triggered anywhere via:
//      import { triggerHeartbeatPulse } from "@/components/HeartbeatPulseBorder";
//      triggerHeartbeatPulse();          // default colour
//      triggerHeartbeatPulse("#ff6b9d"); // custom colour (optional)
//
//  The component is `pointer-events: none` and `inset: 0`, so it
//  never intercepts touches and never affects layout.
// ═══════════════════════════════════════════════════════════
import { useEffect, useRef, useState } from "react";

const EVENT_NAME = "tether-heartbeat-pulse";

interface HeartbeatDetail {
  /** CSS colour for the glow. Defaults to a warm rose-red. */
  color?: string;
}

/** Fire the global heartbeat pulse from anywhere. */
export function triggerHeartbeatPulse(color?: string): void {
  window.dispatchEvent(
    new CustomEvent<HeartbeatDetail>(EVENT_NAME, { detail: { color } }),
  );
}

export function HeartbeatPulseBorder() {
  const [pulsing, setPulsing] = useState(false);
  const [color, setColor] = useState<string>("rgba(255,90,120,0.85)");
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    function onPulse(e: Event) {
      const detail = (e as CustomEvent<HeartbeatDetail>).detail;
      if (detail?.color) setColor(detail.color);
      else setColor("rgba(255,90,120,0.85)");

      // Restart cleanly even if a previous pulse is mid-flight.
      setPulsing(false);
      // Force a frame so the class removal lands before re-adding.
      requestAnimationFrame(() => {
        requestAnimationFrame(() => setPulsing(true));
      });

      if (timerRef.current) window.clearTimeout(timerRef.current);
      // Animation total runtime is ~1.4 s (two thumps + decay).
      timerRef.current = window.setTimeout(() => setPulsing(false), 1500);
    }
    window.addEventListener(EVENT_NAME, onPulse);
    return () => {
      window.removeEventListener(EVENT_NAME, onPulse);
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, []);

  return (
    <div
      aria-hidden="true"
      className={`heartbeat-pulse-border ${pulsing ? "is-pulsing" : ""}`}
      style={{ ["--hb-color" as string]: color } as React.CSSProperties}
    />
  );
}
