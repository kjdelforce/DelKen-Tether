// ═══════════════════════════════════════════════════════════
//  LoveNotes.tsx — Love Note Drop UI
//  ─────────────────────────────────────────────────────────────
//  Three pieces, sharing the loveNotes lib:
//    • <LoveNoteFloater>   — sealed envelope + unfold modal,
//                            shown on Home when a note is waiting.
//    • <LoveNoteWriteButton> — small Home button + write sheet
//                              for composing & sealing a note.
//    • <KeepsakeDrawer>    — Profile Hub button + bottom sheet
//                            of every note the user has read.
//
//  Animations and styling all live in index.css under the
//  lnf-/lno-/lnw-/ksd- prefixes. We keep these as plain class
//  names rather than Framer Motion so they look identical to
//  the spec without invasive refactors.
// ═══════════════════════════════════════════════════════════
import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { supabase } from "@/lib/supabaseClient";
import { haptic } from "@/lib/haptics";
import {
  getUnreadNoteForUser,
  getReadNotesForUser,
  markNoteRead,
  sendLoveNote,
  LOVE_NOTE_MAX_LENGTH,
  type LoveNote,
} from "@/lib/loveNotes";
import { sendLoveNoteNotification } from "@/lib/notifications";

// ── Date helper ─────────────────────────────────────────────
function formatLongDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-AU", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

function formatShortDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-AU", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

// ════════════════════════════════════════════════════════════
//  Unfold overlay — shared by floater & keepsake re-read
// ════════════════════════════════════════════════════════════
function NoteOverlay({
  note,
  fromName,
  onClose,
}: {
  note: LoveNote | null;
  fromName: string;
  onClose: () => void;
}) {
  // Render even when note is null so the open/close transition has
  // something to animate against — but only after the first non-null
  // note. We freeze the last note while the overlay closes so the
  // text doesn't blank during the fade-out.
  const [last, setLast] = useState<LoveNote | null>(null);
  useEffect(() => { if (note) setLast(note); }, [note]);

  const display = note ?? last;
  const open = Boolean(note);

  if (!display) return null;
  return createPortal(
    <div className={`lno-overlay ${open ? "open" : ""}`} aria-hidden={!open}>
      <div className="lno-backdrop" onClick={onClose} />
      <div className="lno-paper" role="dialog" aria-label="Love note">
        <div className="lno-lines">
          {Array.from({ length: 8 }).map((_, i) => (
            <div className="lno-line" key={i} />
          ))}
        </div>
        <p className="lno-from">from {fromName}</p>
        <p className="lno-text" data-user-content>{display.note_text}</p>
        <p className="lno-date">{formatLongDate(display.created_at)}</p>
        <button className="lno-close-btn" onClick={onClose} type="button">
          Fold away ✦
        </button>
      </div>
    </div>,
    document.body,
  );
}

// ════════════════════════════════════════════════════════════
//  Floating envelope on Home + unfold modal
// ════════════════════════════════════════════════════════════
export function LoveNoteFloater({
  tetherId,
  recipientId,
  recipientName,
  partnerName,
}: {
  tetherId: string;
  recipientId: string;
  recipientName: string;
  partnerName: string;
}) {
  const [unread, setUnread] = useState<LoveNote | null>(null);
  const [openNote, setOpenNote] = useState<LoveNote | null>(null);

  const refresh = useCallback(async () => {
    const note = await getUnreadNoteForUser(recipientId);
    setUnread(note);
  }, [recipientId]);

  useEffect(() => { refresh(); }, [refresh]);

  // Realtime: any new note for me triggers a refresh.
  useEffect(() => {
    const ch = supabase
      .channel(`love-notes-incoming-${recipientId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "love_notes",
          filter: `recipient_id=eq.${recipientId}`,
        },
        () => { refresh(); },
      )
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [recipientId, refresh]);

  async function handleOpen() {
    if (!unread) return;
    haptic("envelope");
    setOpenNote(unread);
    await markNoteRead(unread.id);
    setUnread(null);
  }

  return (
    <>
      {unread && (
        <div
          className="lnf-layer visible"
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            width: 200,
            height: 200,
            transform: "translate(-50%, -50%)",
          }}
        >
          <div className="lnf-glow-ring lnf-glow-ring-1" />
          <div className="lnf-glow-ring lnf-glow-ring-2" />
          <div className="lnf-glow-ring lnf-glow-ring-3" />
          <div
            className="lnf-envelope"
            role="button"
            tabIndex={0}
            aria-label={`Open love note from ${partnerName}`}
            onClick={handleOpen}
            onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") handleOpen(); }}
          >
            <div className="lnf-flap-top" />
            <div className="lnf-flap-bottom" />
            <div className="lnf-flap-left" />
            <div className="lnf-flap-right" />
            <div className="lnf-seal">
              <div className="lnf-seal-inner">❤</div>
            </div>
            <p className="lnf-recipient-name">{recipientName}</p>
          </div>
        </div>
      )}
      <NoteOverlay
        note={openNote}
        fromName={partnerName}
        onClose={() => setOpenNote(null)}
      />
      {/* tetherId is part of insert RLS — referenced here so an unused-var
          lint never strips the prop. Realtime + read flow only need recipientId. */}
      <span hidden data-tether-id={tetherId} />
    </>
  );
}

// ════════════════════════════════════════════════════════════
//  Write sheet
// ════════════════════════════════════════════════════════════
export function LoveNoteWriteButton({
  tetherId,
  senderId,
  senderName,
  recipientId,
  partnerName,
  className,
}: {
  tetherId: string;
  senderId: string;
  senderName: string;
  recipientId: string;
  partnerName: string;
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 250);
  }, [open]);

  function close() {
    setOpen(false);
    // Reset slightly after the close transition so it doesn't visibly clear.
    setTimeout(() => { setText(""); setConfirmed(false); }, 350);
  }

  async function handleSend() {
    const trimmed = text.trim();
    if (!trimmed || sending) return;
    setSending(true);
    haptic("medium");
    const { error } = await sendLoveNote({
      tetherId,
      senderId,
      recipientId,
      noteText: trimmed,
    });
    setSending(false);
    if (error) {
      haptic("error");
      return;
    }
    setConfirmed(true);
    haptic("success");
    sendLoveNoteNotification(tetherId, senderId, senderName).catch(() => {});
    setTimeout(close, 1100);
  }

  const remaining = LOVE_NOTE_MAX_LENGTH - text.length;

  return (
    <>
      <button
        type="button"
        className={className ?? "lnw-leave-btn"}
        onClick={() => { haptic("light"); setOpen(true); }}
        aria-label={`Leave a note for ${partnerName}`}
      >
        <span className="lnw-leave-btn-icon">✉</span>
        <span>Leave a Note</span>
      </button>

      {createPortal(
        <div className={`lnw-sheet ${open ? "open" : ""}`} aria-hidden={!open}>
          <div className="lnw-backdrop" onClick={close} />
          <div className="lnw-card" role="dialog" aria-label="Leave a note">
            <div className="lnw-handle" />
            <div className="lnw-header">
              <h2 className="lnw-title">Leave a Note</h2>
              <button className="lnw-close" onClick={close} type="button" aria-label="Close">
                ✕
              </button>
            </div>
            <p className="lnw-sub">Write something for {partnerName} to find.</p>

            <div className="lnw-paper-preview">
              <div className="lnw-preview-lines">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div className="lno-line" key={i} />
                ))}
              </div>
              <textarea
                ref={inputRef}
                className="lnw-input"
                placeholder="Write your note here..."
                maxLength={LOVE_NOTE_MAX_LENGTH}
                value={text}
                data-user-content
                onChange={(e) => setText(e.target.value)}
              />
              <p className="lnw-char-count">{remaining} characters remaining</p>
            </div>

            <button
              className="lnw-send-btn"
              type="button"
              onClick={handleSend}
              disabled={sending || confirmed || text.trim().length === 0}
            >
              {confirmed ? "✓ Left for them" : sending ? "Sealing…" : "Seal & Leave ❤"}
            </button>
          </div>
        </div>,
        document.body,
      )}
    </>
  );
}

// ════════════════════════════════════════════════════════════
//  Keepsake Drawer
// ════════════════════════════════════════════════════════════
export function KeepsakeDrawer({
  recipientId,
  partnerName,
}: {
  recipientId: string;
  partnerName: string;
}) {
  const [open, setOpen] = useState(false);
  const [notes, setNotes] = useState<LoveNote[]>([]);
  const [loading, setLoading] = useState(false);
  const [reReading, setReReading] = useState<LoveNote | null>(null);

  const loadCount = useCallback(async () => {
    const data = await getReadNotesForUser(recipientId);
    setNotes(data);
  }, [recipientId]);

  // Initial count load — keeps the badge fresh without opening the drawer.
  useEffect(() => { loadCount(); }, [loadCount]);

  // Refresh anytime a note for me flips to read (e.g. via the floater).
  useEffect(() => {
    const ch = supabase
      .channel(`love-notes-keepsake-${recipientId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "love_notes",
          filter: `recipient_id=eq.${recipientId}`,
        },
        () => { loadCount(); },
      )
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [recipientId, loadCount]);

  async function openDrawer() {
    haptic("light");
    setOpen(true);
    setLoading(true);
    await loadCount();
    setLoading(false);
  }

  function closeDrawer() {
    setOpen(false);
  }

  return (
    <>
      <button
        type="button"
        className="ksd-profile-btn"
        onClick={openDrawer}
        aria-label="Open Keepsake Drawer"
      >
        <span className="ksd-profile-btn-icon">🗂</span>
        <div className="ksd-profile-btn-text">
          <p>Keepsake Drawer</p>
          <p>Notes left for you</p>
        </div>
        <span className="ksd-profile-btn-count">{notes.length}</span>
      </button>

      {createPortal(
        <div className={`ksd-overlay ${open ? "open" : ""}`} aria-hidden={!open}>
          <div className="ksd-backdrop" onClick={closeDrawer} />
          <div className="ksd-sheet" role="dialog" aria-label="Keepsake Drawer">
            <div className="ksd-handle" />
            <div className="ksd-header">
              <h2 className="ksd-title">Keepsake Drawer</h2>
              <button className="ksd-close" onClick={closeDrawer} type="button" aria-label="Close">
                ✕
              </button>
            </div>
            <p className="ksd-sub">Every note ever left for you</p>

            <div className="ksd-list">
              {loading && notes.length === 0 ? (
                <div className="ksd-empty">Opening the drawer…</div>
              ) : notes.length === 0 ? (
                <div className="ksd-empty">
                  Notes left for you will be<br />kept here forever.
                </div>
              ) : (
                notes.map((note) => (
                  <div
                    key={note.id}
                    className="ksd-note-card"
                    role="button"
                    tabIndex={0}
                    onClick={() => { haptic("light"); setReReading(note); }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === " ") setReReading(note);
                    }}
                  >
                    <p className="ksd-note-from">From {partnerName}</p>
                    <p className="ksd-note-preview" data-user-content>{note.note_text}</p>
                    <p className="ksd-note-date">{formatShortDate(note.created_at)}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>,
        document.body,
      )}

      <NoteOverlay
        note={reReading}
        fromName={partnerName}
        onClose={() => setReReading(null)}
      />
    </>
  );
}
