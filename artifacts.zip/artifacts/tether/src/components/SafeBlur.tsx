import * as React from "react";
import { useSafeView } from "@/lib/safeView";

interface SafeBlurProps {
  children: React.ReactNode;
  className?: string;
  /** Overlay label displayed when Safe View is active. Defaults to "Private". */
  label?: string;
  style?: React.CSSProperties;
}

/**
 * Visual privacy wrapper. When Safe View is OFF this is a transparent
 * pass-through (single non-breaking div). When ON it blurs the inner
 * content and overlays the supplied label so a glance can't read what's
 * underneath. CSS lives in styles/app-guide.css.
 */
export function SafeBlur({
  children,
  className = "",
  label = "Private",
  style,
}: SafeBlurProps) {
  const { enabled } = useSafeView();
  return (
    <div
      className={`safe-blur-wrap${enabled ? " is-safe" : ""}${className ? " " + className : ""}`}
      style={style}
    >
      <div className="safe-blur-content">{children}</div>
      {enabled && (
        <div className="safe-blur-label" aria-hidden="true">
          {label}
        </div>
      )}
    </div>
  );
}
