import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";

/**
 * Full-screen "Couple's Games" loading screen shown for ~2.2s
 * before the Games Hub grid reveals. Velvet+leather background
 * with floating particles, twin spinning rings, an animated
 * loading bar, and a private "Kyle & Nathan · Members Only"
 * stamp.
 *
 * The whole thing is purely presentational — `onComplete` fires
 * after the bar finishes filling so the parent can fade us out
 * and reveal the hub.
 */
export function GamesLoadingScreen({ onComplete }: { onComplete: () => void }) {
  const [barFull, setBarFull] = useState(false);

  // Pre-compute particle styles once so we don't reshuffle
  // every render frame.
  const particles = useMemo(() => {
    const colors = [
      "rgba(180,0,0,0.7)",
      "rgba(200,120,0,0.5)",
      "rgba(160,0,40,0.6)",
      "rgba(220,180,0,0.4)",
    ];
    return Array.from({ length: 20 }).map((_, i) => {
      const size  = Math.random() * 4 + 2;
      const color = colors[Math.floor(Math.random() * colors.length)];
      return {
        key:  i,
        size,
        left: Math.random() * 100,
        bg:   color,
        dur:  Math.random() * 3 + 2,
        del:  Math.random() * 2,
      };
    });
  }, []);

  useEffect(() => {
    // Fill the bar a frame later so the CSS transition fires.
    const startTimer = setTimeout(() => setBarFull(true), 50);
    // Hand control back to the parent after the full 2.2s.
    const doneTimer  = setTimeout(() => onComplete(), 2200);
    return () => {
      clearTimeout(startTimer);
      clearTimeout(doneTimer);
    };
  }, [onComplete]);

  return (
    <motion.div
      className="gls-screen"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
    >
      <div className="gls-bg" />

      <div className="gls-particles">
        {particles.map(p => (
          <span
            key={p.key}
            className="gls-particle"
            style={{
              width:  `${p.size}px`,
              height: `${p.size}px`,
              left:   `${p.left}%`,
              bottom: "-10px",
              background:        p.bg,
              boxShadow:         `0 0 ${p.size * 2}px ${p.bg}`,
              animationDuration: `${p.dur}s`,
              animationDelay:    `${p.del}s`,
            }}
          />
        ))}
      </div>

      <div className="gls-content">
        <div className="gls-logo-wrap">
          <div className="gls-logo-ring" />
          <div className="gls-logo-ring gls-logo-ring-2" />
          <div className="gls-logo-icon">♠</div>
        </div>
        <h1 className="gls-title">Couple's Games</h1>
        <p className="gls-sub">Private. Intimate. Just for two.</p>
        <div className="gls-loading-bar-wrap">
          <div className={`gls-loading-bar${barFull ? " full" : ""}`} />
        </div>
      </div>

      <div className="gls-bottom-text">Members Only</div>
    </motion.div>
  );
}
