import { useState } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";

/* ──────────────────────────────────────────────────────────────────
   LegalModal — Privacy Policy · Terms of Service · Security Statement
   ──────────────────────────────────────────────────────────────────
   Compliant with the Australian Privacy Act 1988 (Cth).
   Mounted by SettingsPage; opens as a full-height bottom sheet.
   ────────────────────────────────────────────────────────────────── */

interface Props {
  open: boolean;
  onClose: () => void;
  /** Tab to open first. Defaults to "privacy". */
  initialTab?: Tab;
}

type Tab = "privacy" | "terms" | "security";

const LOGO_SRC = (import.meta.env.BASE_URL ?? "/") + "delken-logo.jpeg";

const DELKEN_FOOTER = (
  <div style={{ textAlign: "center", marginTop: 36, paddingBottom: 8 }}>
    <p style={{ fontSize: 12, color: "rgba(255,255,255,0.30)", marginBottom: 12 }}>
      Tether is a DelKen Tech service · DelKen Tech Pty Ltd is a subsidiary of DelKen
    </p>
    <img
      src={LOGO_SRC}
      alt="DelKen"
      style={{ width: "100%", maxWidth: 180, borderRadius: 10, opacity: 0.80 }}
    />
  </div>
);

export default function LegalModal({ open, onClose, initialTab = "privacy" }: Props) {
  const [tab, setTab] = useState<Tab>(initialTab);

  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          style={{
            position: "fixed", inset: 0, zIndex: 9100,
            display: "flex", alignItems: "flex-end", justifyContent: "center",
          }}
        >
          <div
            onClick={onClose}
            style={{
              position: "absolute", inset: 0,
              background: "rgba(0,0,0,0.55)",
              backdropFilter: "blur(4px)",
              WebkitBackdropFilter: "blur(4px)",
            }}
          />

          <motion.div
            initial={{ y: 60 }}
            animate={{ y: 0 }}
            exit={{ y: 60 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            style={{
              position: "relative", zIndex: 1,
              width: "100%", maxHeight: "92vh",
              borderRadius: "28px 28px 0 0",
              background: "rgba(20,15,25,0.92)",
              backdropFilter: "blur(48px) saturate(1.8)",
              WebkitBackdropFilter: "blur(48px) saturate(1.8)",
              border: "1px solid rgba(255,255,255,0.14)",
              borderBottom: "none",
              boxShadow: "0 -4px 40px rgba(0,0,0,0.5)",
              display: "flex", flexDirection: "column", overflow: "hidden",
            }}
          >
            {/* Handle */}
            <div style={{
              width: 36, height: 4, borderRadius: 2,
              background: "rgba(255,255,255,0.20)",
              margin: "14px auto 0", flexShrink: 0,
            }} />

            {/* Header */}
            <div style={{
              display: "flex", alignItems: "center", justifyContent: "space-between",
              padding: "16px 20px 8px", flexShrink: 0,
            }}>
              <h2 style={{
                fontFamily: "'Georgia', serif", fontSize: 20, fontWeight: 400,
                color: "rgba(255,255,255,0.92)", margin: 0,
              }}>
                Legal
              </h2>
              <button
                onClick={onClose}
                aria-label="Back to Settings"
                style={{
                  background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.10)",
                  borderRadius: 12, color: "rgba(255,255,255,0.75)",
                  padding: "6px 14px", fontSize: "0.82rem", fontWeight: 500,
                  cursor: "pointer", letterSpacing: "0.01em",
                }}
              >← Back</button>
            </div>

            {/* Tabs — 3-column grid */}
            <div style={{
              display: "grid", gridTemplateColumns: "1fr 1fr 1fr",
              gap: 6, padding: "0 20px 12px", flexShrink: 0,
            }}>
              <TabButton active={tab === "privacy"}  onClick={() => setTab("privacy")}>Privacy</TabButton>
              <TabButton active={tab === "terms"}    onClick={() => setTab("terms")}>Terms</TabButton>
              <TabButton active={tab === "security"} onClick={() => setTab("security")}>Security</TabButton>
            </div>

            {/* Body */}
            <div style={{
              flex: 1, overflowY: "auto",
              padding: "8px 22px calc(env(safe-area-inset-bottom, 0px) + 110px)",
              fontFamily: "'Quicksand', sans-serif",
              color: "rgba(255,255,255,0.78)",
              fontSize: 14, lineHeight: 1.65,
            }}>
              {tab === "privacy"  && <PrivacyContent />}
              {tab === "terms"    && <TermsContent />}
              {tab === "security" && <SecurityContent />}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}

function TabButton({
  active, onClick, children,
}: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: "10px 0",
        borderRadius: 14,
        background: active ? "rgba(255,255,255,0.12)" : "rgba(255,255,255,0.04)",
        border: `1px solid ${active ? "rgba(255,255,255,0.20)" : "rgba(255,255,255,0.08)"}`,
        color: active ? "#fff" : "rgba(255,255,255,0.55)",
        fontSize: 12,
        fontWeight: 600,
        letterSpacing: "0.05em",
        textTransform: "uppercase",
        cursor: "pointer",
        transition: "background 0.2s, color 0.2s",
      }}
    >
      {children}
    </button>
  );
}

const h: React.CSSProperties = {
  fontFamily: "'Georgia', serif",
  fontSize: 16,
  fontWeight: 400,
  color: "rgba(255,255,255,0.95)",
  margin: "20px 0 8px",
};

const ul: React.CSSProperties = {
  paddingLeft: 18,
  margin: "6px 0 10px",
};

function PrivacyContent() {
  return (
    <div>
      <p style={{ fontSize: 11, color: "rgba(180,196,240,0.60)", marginBottom: 2 }}>
        Effective Date: 28/04/2026
      </p>
      <p style={{ fontSize: 11, color: "rgba(180,196,240,0.55)", marginBottom: 12 }}>
        App Name: Tether · Developer: DelKen Tech (a subsidiary of DelKen)
      </p>

      <h3 style={{ ...h, marginTop: 4 }}>❤️ Overview</h3>
      <p>
        Tether is a private app designed exclusively for couples. We are committed to
        protecting your personal information and ensuring your data remains secure and
        private.
      </p>

      <h3 style={h}>📊 Information We Collect</h3>
      <p>
        We collect only what's needed to run the app: email address, first names, dates of
        birth, anniversary date, photos and content shared within the app, messages, game
        responses, and basic technical/usage data.
      </p>
      <p>
        We do not collect unnecessary personal or sensitive information beyond what is
        required for the app to function.
      </p>

      <h3 style={h}>🎯 How We Use Your Information</h3>
      <ul style={ul}>
        <li>Create and manage your account</li>
        <li>Pair your account with your partner</li>
        <li>Provide relationship tracking features, milestones, and reminders</li>
        <li>Enable private sharing of content between partners</li>
        <li>Maintain app performance, security, and reliability</li>
      </ul>
      <p>We do not use your data for advertising or sell it to third parties.</p>

      <h3 style={h}>🔒 Data Storage &amp; Security</h3>
      <ul style={ul}>
        <li>Encrypted data transmission (HTTPS)</li>
        <li>Secure cloud infrastructure via Supabase and Vercel</li>
        <li>Access controls to restrict unauthorised access</li>
      </ul>

      <h3 style={h}>🔐 Private Content</h3>
      <p>
        Content is only visible to you and your partner. We do not publicly display, share,
        or manually review your private content.
      </p>

      <h3 style={h}>🚫 Data Sharing</h3>
      <p>
        We do not sell your personal information or share your data with third parties for
        marketing. We may only disclose information if required by law.
      </p>

      <h3 style={h}>🧼 Your Rights &amp; Choices</h3>
      <p>
        You can update or delete your content and request account deletion at any time.
        Contact us at{" "}
        <a href="mailto:delken.tech@outlook.com" style={{ color: "#93C5FD" }}>
          delken.tech@outlook.com
        </a>
      </p>

      <h3 style={h}>🔞 Age Requirements</h3>
      <p>
        Tether is intended for users aged 17 and over. We do not knowingly collect data from
        minors and implement an age verification step before onboarding.
      </p>

      <h3 style={h}>⚖️ Legal Compliance</h3>
      <p>
        We comply with the <em>Privacy Act 1988</em> and the Australian Privacy Principles
        (APPs).
      </p>

      <h3 style={h}>📩 Contact</h3>
      <p>
        <strong>DelKen Tech</strong>
        <br />
        <a href="mailto:delken.tech@outlook.com" style={{ color: "#93C5FD" }}>
          delken.tech@outlook.com
        </a>
      </p>

      {DELKEN_FOOTER}
    </div>
  );
}

function TermsContent() {
  return (
    <div>
      <p style={{ fontSize: 11, color: "rgba(180,196,240,0.60)", marginBottom: 2 }}>
        Effective Date: 28/04/2026
      </p>
      <p style={{ fontSize: 11, color: "rgba(180,196,240,0.55)", marginBottom: 12 }}>
        App Name: Tether · Developer: DelKen Tech (a subsidiary of DelKen)
      </p>

      <h3 style={{ ...h, marginTop: 4 }}>❤️ 1. Acceptance of Terms</h3>
      <p>
        By accessing or using Tether, you agree to be bound by these Terms of Service. If
        you do not agree, you must not use the app.
      </p>

      <h3 style={h}>🔞 2. Eligibility &amp; Age Requirement</h3>
      <p>Tether is intended for users aged 17 years and older. By using the app, you confirm that you are at least 17 years of age and have the legal capacity to enter into these Terms.</p>

      <h3 style={h}>👤 3. Accounts &amp; Registration</h3>
      <p>To use Tether you must create an account with a valid email address and your first name. You agree to provide accurate information, keep your login details secure, and be responsible for all activity under your account.</p>

      <h3 style={h}>🔗 4. Relationship Pairing</h3>
      <p>
        Tether is designed for use between two individuals in a relationship. By pairing your
        account you consent to share content with your selected partner and acknowledge that
        shared content becomes accessible to both parties.
      </p>

      <h3 style={h}>🔐 5. Privacy &amp; Data Use</h3>
      <p>
        Your use of Tether is governed by our Privacy Policy. We prioritise keeping your
        data private and secure in line with the <em>Privacy Act 1988</em>.
      </p>

      <h3 style={h}>📸 6. User Content</h3>
      <p>
        You retain ownership of any content you upload. By using Tether you grant us a
        limited licence to store, process, and display your content solely for the purpose of
        operating the app. We do not use your content for advertising.
      </p>

      <h3 style={h}>🚫 7. Prohibited Use</h3>
      <ul style={ul}>
        <li>Violate any laws or regulations</li>
        <li>Harass, abuse, or harm another person</li>
        <li>Attempt unauthorised access to accounts or systems</li>
        <li>Upload malicious code or disrupt the app</li>
        <li>Misrepresent your identity</li>
      </ul>

      <h3 style={h}>🛡️ 8. Security</h3>
      <p>
        We implement reasonable security measures. However no system is completely secure and
        you use the app at your own risk.
      </p>

      <h3 style={h}>🧼 9. Account Deletion</h3>
      <p>
        You may request deletion of your account at any time. Upon deletion your personal
        data will be removed from active systems. Some data may remain temporarily in backups
        before secure deletion.
      </p>

      <h3 style={h}>⚠️ 10. Service Availability</h3>
      <p>
        We aim to provide a reliable experience but do not guarantee continuous availability
        or error-free operation. We may modify, suspend, or discontinue features at any time.
      </p>

      <h3 style={h}>⚖️ 11. Limitation of Liability</h3>
      <p>
        Tether is provided "as is". We are not liable for any indirect, incidental, or
        consequential damages including loss of data, relationship disputes, or emotional
        distress arising from app use.
      </p>
      <p style={{ fontStyle: "italic", color: "rgba(180,196,240,0.55)", fontSize: "0.82rem" }}>
        (Yeah… had to say it. Couples apps can get messy 😅)
      </p>

      <h3 style={h}>🔄 12. Changes to Terms</h3>
      <p>
        We may update these Terms from time to time. Continued use of Tether after changes
        means you accept the updated Terms.
      </p>

      <h3 style={h}>🌍 13. Governing Law</h3>
      <p>These Terms are governed by the laws of Australia.</p>

      <h3 style={h}>📩 14. Contact</h3>
      <p>
        <strong>DelKen Tech</strong>
        <br />
        <a href="mailto:delken.tech@outlook.com" style={{ color: "#93C5FD" }}>
          delken.tech@outlook.com
        </a>
      </p>

      {DELKEN_FOOTER}
    </div>
  );
}

function SecurityContent() {
  return (
    <div>
      <h3 style={{ ...h, marginTop: 4 }}>Data Security &amp; Encryption</h3>
      <p>
        Tether uses industry-standard <strong>AES-256 encryption</strong> for all stored
        media. Connections between your device and our servers are protected with TLS 1.3.
      </p>

      <h3 style={h}>Couple Isolation</h3>
      <p>
        Your data is isolated via PostgreSQL <strong>Row Level Security (RLS)</strong>. Your
        private moments are mathematically inaccessible to anyone outside of your specific
        Tether connection — including the Tether team.
      </p>

      <h3 style={h}>Infrastructure</h3>
      <p>
        We use Supabase (PostgreSQL) for our database, authentication, and private storage
        buckets. Your password is never stored in plain text and we do not have the ability
        to view it.
      </p>

      <h3 style={h}>Account Safety</h3>
      <p>
        You can sign out of all devices, change your password, or delete your account at any
        time from Settings. We recommend using a unique password not reused on other sites.
      </p>

      <h3 style={h}>Security Incidents</h3>
      <p>
        If a data breach occurs, we will take immediate steps to secure our systems and
        notify affected users where required by law.
      </p>

      {DELKEN_FOOTER}
    </div>
  );
}
