import { useEffect, useRef, useState } from "react";
import { subscribeIsland, type IslandPayload } from "@/lib/dynamicIsland";

/**
 * DynamicIsland — pill-shaped notification that slides down from the
 * top of the screen, modeled after the iPhone Dynamic Island. Mounted
 * once at App root; receives payloads via `showIsland()` from the
 * `lib/dynamicIsland` channel.
 *
 * Two CSS classes drive the animation: `expanding` springs the pill
 * out from a tiny top-bar slot; `collapsing` shrinks it back. Class
 * juggling + a single timer mimic the spec's vanilla impl.
 */
export function DynamicIsland() {
  const [phase,   setPhase]   = useState<"hidden" | "expanding" | "collapsing">("hidden");
  const [payload, setPayload] = useState<IslandPayload | null>(null);
  const collapseTimer = useRef<number | null>(null);
  const removeTimer   = useRef<number | null>(null);

  useEffect(() => {
    return subscribeIsland((next) => {
      // Reset any in-flight collapse.
      if (collapseTimer.current) window.clearTimeout(collapseTimer.current);
      if (removeTimer.current)   window.clearTimeout(removeTimer.current);

      setPayload(next);
      // Force a microtask gap so a back-to-back collapse → expand
      // visibly re-animates (otherwise React batches and the class
      // stays the same).
      setPhase("hidden");
      window.requestAnimationFrame(() => {
        setPhase("expanding");
        const dur = next.duration ?? 3200;
        collapseTimer.current = window.setTimeout(() => {
          setPhase("collapsing");
          removeTimer.current = window.setTimeout(() => {
            setPhase("hidden");
            setPayload(null);
          }, 600);
        }, dur);
      });
    });
  }, []);

  useEffect(() => {
    return () => {
      if (collapseTimer.current) window.clearTimeout(collapseTimer.current);
      if (removeTimer.current)   window.clearTimeout(removeTimer.current);
    };
  }, []);

  // Render even when hidden so the element exists for the spring-from-
  // notch transform; just keep opacity 0 + scale collapsed.
  const className = `tether-island ${phase === "expanding" ? "expanding" : phase === "collapsing" ? "collapsing" : ""}`;

  return (
    <div id="tether-island" className={className} aria-live="polite" aria-atomic="true">
      <div className="island-pill">
        <div className="island-icon-wrap">
          <div className="island-icon-bg" />
          <span className="island-icon">{payload?.icon ?? "💓"}</span>
        </div>
        <div className="island-text">
          <span className="island-title">{payload?.title ?? ""}</span>
          <span className="island-sub">{payload?.sub ?? ""}</span>
        </div>
        <div className="island-wave" aria-hidden="true">
          <div className="island-wave-bar" />
          <div className="island-wave-bar" />
          <div className="island-wave-bar" />
          <div className="island-wave-bar" />
        </div>
      </div>
    </div>
  );
}
