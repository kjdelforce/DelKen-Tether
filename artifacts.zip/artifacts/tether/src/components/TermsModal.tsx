import { useEffect } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "framer-motion";
import { haptic } from "@/lib/haptics";

interface TermsModalProps {
  open: boolean;
  onClose: () => void;
}

const LOGO_SRC = (import.meta.env.BASE_URL ?? "/") + "delken-logo.jpeg";

export function TermsModal({ open, onClose }: TermsModalProps) {
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          className="tsp-modal"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          onClick={(e) => {
            if (e.target === e.currentTarget) { haptic("tap"); onClose(); }
          }}
        >
          <motion.div
            className="tsp-modal-card"
            initial={{ y: 40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 40, opacity: 0 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            role="dialog"
            aria-modal="true"
            aria-labelledby="tsp-terms-title"
          >
            <div className="tsp-modal-header">
              <h2 id="tsp-terms-title" className="tsp-modal-title">
                Terms of Service
              </h2>
              <button
                type="button"
                className="tsp-modal-close"
                aria-label="Back to Settings"
                onClick={() => { haptic("tap"); onClose(); }}
              >
                ← Back
              </button>
            </div>

            <div className="tsp-modal-body">
              <p className="tsp-privacy-updated">Effective Date: 28/04/2026</p>
              <p style={{ fontSize: "0.82rem", color: "rgba(180,196,240,0.65)", marginBottom: 4 }}>
                App Name: Tether · Developer: DelKen Tech (a subsidiary of DelKen)
              </p>

              <h3>❤️ 1. Acceptance of Terms</h3>
              <p>
                By accessing or using Tether, you agree to be bound by these Terms of
                Service. If you do not agree, you must not use the app.
              </p>

              <h3>🔞 2. Eligibility &amp; Age Requirement</h3>
              <p>Tether is intended for users aged 17 years and older.</p>
              <p>By using the app, you confirm that:</p>
              <ul>
                <li>You are at least 17 years of age</li>
                <li>You have the legal capacity to enter into these Terms</li>
              </ul>
              <p>
                Tether includes a mandatory age verification gate presented before onboarding.
                Users who do not meet the age requirement must not proceed or use the app. We
                do not knowingly allow access to users below the required age.
              </p>

              <h3>👤 3. Accounts &amp; Registration</h3>
              <p>To use Tether, you must create an account using:</p>
              <ul>
                <li>A valid email address</li>
                <li>Your first name</li>
              </ul>
              <p>You agree to:</p>
              <ul>
                <li>Provide accurate information</li>
                <li>Keep your login details secure</li>
                <li>Be responsible for all activity under your account</li>
              </ul>

              <h3>🔗 4. Relationship Pairing</h3>
              <p>Tether is designed for use between two individuals in a relationship.</p>
              <p>By pairing your account:</p>
              <ul>
                <li>You consent to share content and information with your selected partner</li>
                <li>You acknowledge that shared content becomes accessible to both parties</li>
              </ul>
              <p>You are responsible for who you choose to pair with.</p>

              <h3>🔐 5. Privacy &amp; Data Use</h3>
              <p>
                Your use of Tether is also governed by our Privacy Policy. We prioritise
                keeping your data private and secure, in line with the{" "}
                <em>Privacy Act 1988</em> and applicable laws.
              </p>

              <h3>📸 6. User Content</h3>
              <p>
                You retain ownership of any content you upload, including photos, messages,
                and responses within games or features. However, by using Tether, you grant
                us a limited licence to store, process, and display your content solely for
                the purpose of operating the app. We do not use your content for advertising
                or external purposes.
              </p>

              <h3>🚫 7. Prohibited Use</h3>
              <p>You agree not to use Tether to:</p>
              <ul>
                <li>Violate any laws or regulations</li>
                <li>Harass, abuse, or harm another person</li>
                <li>Attempt unauthorised access to accounts or systems</li>
                <li>Upload malicious code or disrupt the app</li>
                <li>Misrepresent your identity</li>
              </ul>
              <p>
                We reserve the right to suspend or terminate accounts that violate these
                terms.
              </p>

              <h3>🛡️ 8. Security</h3>
              <p>
                We implement reasonable security measures to protect your data. However, you
                acknowledge that no system is completely secure and you use the app at your
                own risk.
              </p>

              <h3>🧼 9. Account Deletion</h3>
              <p>You may request deletion of your account at any time.</p>
              <p>Upon deletion:</p>
              <ul>
                <li>Your personal data will be removed from active systems</li>
                <li>Some data may remain temporarily in backups before secure deletion</li>
              </ul>

              <h3>⚠️ 10. Service Availability</h3>
              <p>
                We aim to provide a reliable experience, but we do not guarantee continuous
                availability or error-free operation. We may modify, suspend, or discontinue
                features at any time.
              </p>

              <h3>⚖️ 11. Limitation of Liability</h3>
              <p>To the maximum extent permitted by law:</p>
              <ul>
                <li>Tether is provided "as is"</li>
                <li>
                  We are not liable for any indirect, incidental, or consequential damages
                </li>
                <li>
                  This includes loss of data, relationship disputes, or emotional distress
                  arising from app use
                </li>
              </ul>
              <p style={{ fontStyle: "italic", color: "rgba(180,196,240,0.60)", fontSize: "0.82rem" }}>
                (Yeah… had to say it. Couples apps can get messy 😅)
              </p>

              <h3>🔄 12. Changes to Terms</h3>
              <p>
                We may update these Terms from time to time. Continued use of Tether after
                changes means you accept the updated Terms.
              </p>

              <h3>🌍 13. Governing Law</h3>
              <p>These Terms are governed by the laws of Australia.</p>

              <h3>📩 14. Contact</h3>
              <p>For questions about these Terms:</p>
              <p>
                <strong>DelKen Tech</strong>
                <br />
                <a href="mailto:delken.tech@outlook.com" style={{ color: "#93C5FD" }}>
                  delken.tech@outlook.com
                </a>
              </p>

              <div className="tsp-privacy-footer">
                <p>Tether is a DelKen Tech service.</p>
                <p>DelKen Tech Pty Ltd is a subsidiary of DelKen.</p>
                <img
                  src={LOGO_SRC}
                  alt="DelKen"
                  style={{
                    width: "100%", maxWidth: 200,
                    borderRadius: 12, marginTop: 16,
                    opacity: 0.88,
                  }}
                />
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
