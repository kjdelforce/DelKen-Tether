import { useEffect, useRef, useState } from "react";
import {
  applyFontSize,
  DEFAULT_SIZE,
  getSavedSize,
  MAX_SIZE,
  MIN_SIZE,
  PRESET_LABELS,
  SIZE_PRESETS,
} from "@/lib/fontSize";
import { haptic } from "@/lib/haptics";

interface FontSizeScreenProps {
  open: boolean;
  onClose: () => void;
}

// ── Constants for the custom slider thumb geometry ─────────────────
// Match these to the CSS values in font-size.css (.tfs-slider-thumb).
const THUMB_PX = 32;

/**
 * Settings sub-screen for choosing the size of user-typed content.
 * Slides in from the right when `open` flips true. Save commits to
 * localStorage + applies globally; Back closes without saving.
 */
export default function FontSizeScreen({ open, onClose }: FontSizeScreenProps) {
  // The screen is mounted permanently and just toggles a class so
  // the CSS transform transition fires both ways. State below
  // tracks the *unsaved* preview value while the screen is open.
  const [pendingSize, setPendingSize] = useState<number>(DEFAULT_SIZE);
  const [saved, setSaved] = useState<boolean>(false);

  // Whenever the screen opens, snap the pending value to whatever
  // is currently persisted so we don't show a stale preview from
  // the previous open.
  useEffect(() => {
    if (!open) return;
    setPendingSize(getSavedSize());
    setSaved(false);
  }, [open]);

  // Auto-close + reset after the brief "✓ Saved" confirmation.
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    return () => {
      if (closeTimer.current) clearTimeout(closeTimer.current);
    };
  }, []);

  function handleSave() {
    applyFontSize(pendingSize, true);
    setSaved(true);
    haptic("light");
    if (closeTimer.current) clearTimeout(closeTimer.current);
    closeTimer.current = setTimeout(() => {
      onClose();
      // Defer the saved-state reset until after the slide-out so the
      // "✓ Saved" pill doesn't flash back to "Save" mid-animation.
      setTimeout(() => setSaved(false), 400);
    }, 900);
  }

  function handleBack() {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    onClose();
  }

  // Slider geometry — thumb sits at the centre of the value position
  // along the track, clamped so it never overhangs either edge.
  const pct = (pendingSize - MIN_SIZE) / (MAX_SIZE - MIN_SIZE);
  const thumbLeft = `calc((100% - ${THUMB_PX}px) * ${pct} + ${THUMB_PX / 2}px)`;
  const fillWidth = `${pct * 100}%`;

  return (
    <div
      className={`tfs-screen${open ? " tfs-open" : ""}`}
      role="dialog"
      aria-modal={open ? true : undefined}
      aria-labelledby="tfs-title"
      aria-hidden={!open}
    >
      <div className="tfs-header">
        <button
          type="button"
          className="tfs-back-btn"
          onClick={handleBack}
          aria-label="Back"
        >
          ←
        </button>
        <h1 id="tfs-title" className="tfs-title">
          Text Size
        </h1>
        <button
          type="button"
          className={`tfs-save-btn${saved ? " tfs-saved" : ""}`}
          onClick={handleSave}
          disabled={saved}
        >
          {saved ? "✓ Saved" : "Save"}
        </button>
      </div>

      <div className="tfs-content">
        {/* Preview — shows what user-typed text will look like */}
        <div className="tfs-preview-wrap">
          <div className="tfs-preview-label">Preview</div>
          <div className="tfs-preview-card">
            <p className="tfs-preview-name">Tether</p>
            <p
              className="tfs-preview-text"
              style={{ fontSize: `${pendingSize}px` }}
            >
              You're my entire world.
            </p>
          </div>
        </div>

        {/* Numeric size readout */}
        <div className="tfs-size-display">
          <span className="tfs-size-value">{pendingSize}</span>
          <span className="tfs-size-unit">pt</span>
        </div>

        {/* Glass-pill slider with custom thumb */}
        <div className="tfs-slider-wrap">
          <span className="tfs-slider-min" aria-hidden="true">A</span>
          <div className="tfs-slider-track">
            <div
              className="tfs-slider-fill"
              style={{ width: fillWidth }}
              aria-hidden="true"
            />
            <div
              className="tfs-slider-thumb"
              style={{ left: thumbLeft }}
              aria-hidden="true"
            />
            <input
              type="range"
              className="tfs-slider"
              min={MIN_SIZE}
              max={MAX_SIZE}
              step={1}
              value={pendingSize}
              onChange={(e) => {
                const next = parseInt(e.target.value, 10);
                if (Number.isFinite(next)) {
                  setPendingSize(next);
                  if (saved) setSaved(false);
                }
              }}
              aria-label="Text size"
            />
          </div>
          <span className="tfs-slider-max" aria-hidden="true">A</span>
        </div>

        {/* Quick-jump presets */}
        <div className="tfs-presets">
          {SIZE_PRESETS.map((size, i) => (
            <button
              key={size}
              type="button"
              className={`tfs-preset-btn${
                pendingSize === size ? " tfs-active" : ""
              }`}
              onClick={() => {
                setPendingSize(size);
                haptic("light");
                if (saved) setSaved(false);
              }}
              aria-pressed={pendingSize === size}
            >
              {PRESET_LABELS[i]}
            </button>
          ))}
        </div>

        <p className="tfs-note">
          This adjusts the size of text you and your partner type — captions,
          notes, messages, and answers. App labels and headings stay the same.
        </p>
      </div>
    </div>
  );
}
