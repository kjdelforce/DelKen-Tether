import { useEffect } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "framer-motion";
import { haptic } from "@/lib/haptics";

interface PrivacyModalProps {
  open: boolean;
  onClose: () => void;
}

const LOGO_SRC = (import.meta.env.BASE_URL ?? "/") + "delken-logo.jpeg";

export function PrivacyModal({ open, onClose }: PrivacyModalProps) {
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          className="tsp-modal"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          onClick={(e) => {
            if (e.target === e.currentTarget) { haptic("tap"); onClose(); }
          }}
        >
          <motion.div
            className="tsp-modal-card"
            initial={{ y: 40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 40, opacity: 0 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            role="dialog"
            aria-modal="true"
            aria-labelledby="tsp-privacy-title"
          >
            <div className="tsp-modal-header">
              <h2 id="tsp-privacy-title" className="tsp-modal-title">
                Privacy Policy
              </h2>
              <button
                type="button"
                className="tsp-modal-close"
                aria-label="Back to Settings"
                onClick={() => { haptic("tap"); onClose(); }}
              >
                ← Back
              </button>
            </div>

            <div className="tsp-modal-body">
              <p className="tsp-privacy-updated">Effective Date: 28/04/2026</p>
              <p style={{ fontSize: "0.82rem", color: "rgba(180,196,240,0.65)", marginBottom: 4 }}>
                App Name: Tether · Developer: DelKen Tech (a subsidiary of DelKen)
              </p>

              <h3>❤️ Overview</h3>
              <p>
                Tether is a private app designed exclusively for couples. We are committed to
                protecting your personal information and ensuring your data remains secure and
                private. This Privacy Policy explains what information we collect, how we use
                it, and the choices you have.
              </p>

              <h3>📊 Information We Collect</h3>
              <p>We collect only the information necessary to provide Tether's core functionality:</p>
              <p><strong>Account Information</strong></p>
              <ul>
                <li>Email address</li>
                <li>First names</li>
              </ul>
              <p><strong>Relationship Information</strong></p>
              <ul>
                <li>Dates of birth</li>
                <li>Anniversary date</li>
              </ul>
              <p><strong>User Content</strong></p>
              <ul>
                <li>Photos and content shared within the app</li>
                <li>Messages, game responses, and other in-app interactions</li>
              </ul>
              <p><strong>Technical Data</strong></p>
              <ul>
                <li>Basic usage data (such as app performance and error logs)</li>
                <li>Device and connection information (for security and optimisation)</li>
              </ul>
              <p>
                We do not collect unnecessary personal or sensitive information beyond what
                is required for the app to function.
              </p>

              <h3>🎯 How We Use Your Information</h3>
              <p>We use your information to:</p>
              <ul>
                <li>Create and manage your account</li>
                <li>Pair your account with your partner</li>
                <li>Provide relationship tracking features, milestones, and reminders</li>
                <li>Enable private sharing of content between partners</li>
                <li>Maintain app performance, security, and reliability</li>
              </ul>
              <p>We do not use your data for advertising or sell it to third parties.</p>

              <h3>🔒 Data Storage &amp; Security</h3>
              <p>
                We take reasonable and appropriate steps to protect your information using
                industry-standard security practices. This includes:
              </p>
              <ul>
                <li>Encrypted data transmission (HTTPS)</li>
                <li>Secure cloud infrastructure provided by Supabase and Vercel</li>
                <li>Secure development environment via Replit</li>
                <li>Access controls to restrict unauthorised access</li>
              </ul>
              <p>
                While we implement strong safeguards, no method of transmission or storage
                is completely secure.
              </p>

              <h3>🔐 Private Content</h3>
              <p>Tether is built to be a private experience:</p>
              <ul>
                <li>Content is only visible to you and your partner</li>
                <li>We do not publicly display or share your content</li>
                <li>We do not monitor or manually review your private content</li>
              </ul>
              <p>Your data stays within your relationship.</p>

              <h3>🚫 Data Sharing</h3>
              <p>We do not:</p>
              <ul>
                <li>Sell your personal information</li>
                <li>Share your data with third parties for marketing</li>
                <li>Allow external access to your private content</li>
              </ul>
              <p>
                We may only disclose information if required by law or to comply with legal
                obligations.
              </p>

              <h3>🔑 Account Pairing</h3>
              <p>Tether allows two users to connect within a relationship:</p>
              <ul>
                <li>Accounts are paired securely</li>
                <li>Only authenticated users can access shared content</li>
                <li>We implement safeguards to prevent unauthorised access</li>
              </ul>

              <h3>🧼 Your Rights &amp; Choices</h3>
              <p>You have control over your data:</p>
              <ul>
                <li>You can update or delete your content within the app</li>
                <li>You can request account deletion</li>
                <li>Upon account deletion, your personal data will be removed from active systems</li>
              </ul>
              <p>
                To request deletion, contact us at:{" "}
                <a href="mailto:delken.tech@outlook.com" style={{ color: "#93C5FD" }}>
                  delken.tech@outlook.com
                </a>
              </p>

              <h3>🕒 Data Retention</h3>
              <p>We retain your data only as long as necessary:</p>
              <ul>
                <li>While your account is active</li>
                <li>Until you request deletion</li>
              </ul>
              <p>
                Backup systems may temporarily retain data before it is securely deleted.
              </p>

              <h3>⚠️ Security Incidents</h3>
              <p>If a data breach occurs, we will:</p>
              <ul>
                <li>Take immediate steps to secure our systems</li>
                <li>Notify affected users where required</li>
              </ul>

              <h3>🔞 Age Requirements</h3>
              <p>
                Tether may contain mature themes intended for adult users. Tether is intended
                for users aged 17 and over. We do not knowingly collect data from minors. We
                implement an age verification step before onboarding to restrict access to
                eligible users.
              </p>

              <h3>⚖️ Legal Compliance</h3>
              <p>
                We comply with applicable privacy laws, including the{" "}
                <em>Privacy Act 1988</em> and the Australian Privacy Principles (APPs).
              </p>

              <h3>🌍 International Users</h3>
              <p>
                If you access Tether from outside Australia, your data may be processed in
                secure servers located in other regions. We take steps to ensure your data
                remains protected.
              </p>

              <h3>🔄 Changes to This Policy</h3>
              <p>
                We may update this Privacy Policy from time to time. Updates will be reflected
                by the revised effective date.
              </p>

              <h3>📩 Contact Us</h3>
              <p>
                If you have any questions or concerns about this Privacy Policy or your data:
              </p>
              <p>
                <strong>DelKen Tech</strong>
                <br />
                <a href="mailto:delken.tech@outlook.com" style={{ color: "#93C5FD" }}>
                  delken.tech@outlook.com
                </a>
              </p>

              <div className="tsp-privacy-footer">
                <p>Tether is a DelKen Tech service.</p>
                <p>DelKen Tech Pty Ltd is a subsidiary of DelKen.</p>
                <img
                  src={LOGO_SRC}
                  alt="DelKen"
                  style={{
                    width: "100%", maxWidth: 200,
                    borderRadius: 12, marginTop: 16,
                    opacity: 0.88,
                  }}
                />
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
