import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { playSound } from "@/lib/audioManager";
import { haptic } from "@/lib/haptics";

const TOTAL = 10;

type SlideContent =
  | {
      kind: "hero";
      iconSrc: string;
      heading: string;
      sub: string;
      brandNote: string;
    }
  | {
      kind: "feature";
      icon: string;
      heading: string;
      sub: string;
      tipLabel: string;
      tipText: string;
    }
  | {
      kind: "outro";
      icon: string;
      heading: string;
      sub: string;
      brandName: string;
      brandSub: string;
    };

const ICON_SRC =
  (import.meta.env.BASE_URL ?? "/") + "icon-192.png";

const SLIDES: SlideContent[] = [
  {
    kind: "hero",
    iconSrc: ICON_SRC,
    heading: "Welcome to Tether",
    sub:
      "A private digital sanctuary built exclusively for two. Tether is your shared living space — a place to store memories, stay connected, and build your story together.",
    brandNote: "A DelKen product",
  },
  {
    kind: "feature",
    icon: "🌅",
    heading: "Living Home",
    sub:
      "Your Home screen is alive. It shifts its atmosphere based on your local weather and time of day — morning, night, rain, sun. It reflects the world around you both in real time.",
    tipLabel: "Tip",
    tipText:
      "The background colour and mood changes automatically — no setup needed.",
  },
  {
    kind: "feature",
    icon: "💓",
    heading: "The Pulse",
    sub:
      "A single tap that tells the other person you're thinking of them. No words, no pressure — just a quiet signal that says \u201chey, you're on my mind.\u201d",
    tipLabel: "How to use",
    tipText:
      "Tap the Pulse button on the Home screen any time. Your partner receives a gentle notification instantly.",
  },
  {
    kind: "feature",
    icon: "📖",
    heading: "Scrapbook",
    sub:
      "Your shared memory book. Upload photos and notes that become pages in a beautiful, private album only you two can see.",
    tipLabel: "How to use",
    tipText:
      "Tap Scrapbook in the dock, then rotate your phone to landscape to read your book. Swipe left and right to turn pages. Tap + to add a new memory.",
  },
  {
    kind: "feature",
    icon: "📅",
    heading: "Dates",
    sub:
      "Plan, propose, and archive your outings, adventures, and shared goals. Every date — past and future — lives here forever.",
    tipLabel: "How to use",
    tipText:
      "Tap Dates in the dock. Add a new date with the + button. Set a title, date, and notes. Both of you can see and update it.",
  },
  {
    kind: "feature",
    icon: "🎮",
    heading: "Games",
    sub:
      "Private games built just for two. Play together whether you're side by side or on opposite sides of the world.",
    tipLabel: "How to use",
    tipText:
      "Tap Games in the dock to see available games. Select one and play — your partner is notified when it's their turn.",
  },
  {
    kind: "feature",
    icon: "⏳",
    heading: "Capsules",
    sub:
      "Seal a message, photo, or promise inside a time capsule to be opened at a future date. Letters to your future selves, locked until the moment is right.",
    tipLabel: "How to use",
    tipText:
      "Tap Capsules in the dock. Tap + to create one — write your message, set an open date, and seal it. Neither of you can read it until that day arrives.",
  },
  {
    kind: "feature",
    icon: "👥",
    heading: "Us",
    sub:
      "Your relationship hub. See your days together, your mood status, shared stats, and access your profile settings — all in one place.",
    tipLabel: "How to use",
    tipText:
      "Tap Us in the dock. Update your mood emoji, view your timeline, and access any account settings from here.",
  },
  {
    kind: "feature",
    icon: "⚙️",
    heading: "Settings",
    sub:
      "Control how Tether sounds and notifies you. You can always revisit this guide, read our privacy statement, or adjust your preferences.",
    tipLabel: "How to find it",
    tipText: "Tap the Settings icon at the end of the bottom dock at any time.",
  },
  {
    kind: "outro",
    icon: "🔗",
    heading: "You're Tethered",
    sub:
      "That's everything you need to know. Your story is just beginning — every photo, pulse, date, and capsule is a thread that connects you.",
    brandName: "Tether",
    brandSub: "A DelKen Tech service",
  },
];

interface WelcomeGuideProps {
  open: boolean;
  onClose: () => void;
}

export function WelcomeGuide({ open, onClose }: WelcomeGuideProps) {
  const [index, setIndex] = useState(0);
  const [direction, setDirection] = useState<1 | -1>(1);
  const touchStartX = useRef<number | null>(null);

  // Reset to slide 0 every time the guide is reopened.
  useEffect(() => {
    if (open) {
      setIndex(0);
      setDirection(1);
    }
  }, [open]);

  if (!open) return null;

  const isLast = index === TOTAL - 1;
  const slide = SLIDES[index];

  const next = () => {
    if (index < TOTAL - 1) {
      setDirection(1);
      setIndex((i) => i + 1);
      playSound("glassClick");
      haptic("tap");
    }
  };

  const prev = () => {
    if (index > 0) {
      setDirection(-1);
      setIndex((i) => i - 1);
      playSound("glassClick");
      haptic("tap");
    }
  };

  const finish = () => {
    playSound("crystalPlink");
    haptic("light");
    onClose();
  };

  const skip = () => {
    haptic("tap");
    onClose();
  };

  // Touch-driven swipe — mirrors the prompt's 50px threshold.
  const onTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0]?.clientX ?? null;
  };
  const onTouchEnd = (e: React.TouchEvent) => {
    const start = touchStartX.current;
    touchStartX.current = null;
    if (start == null) return;
    const diff = start - (e.changedTouches[0]?.clientX ?? start);
    if (Math.abs(diff) > 50) {
      if (diff > 0) next();
      else prev();
    }
  };

  const pct = ((index + 1) / TOTAL) * 100;

  return (
    <motion.div
      className="twg-overlay"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      onTouchStart={onTouchStart}
      onTouchEnd={onTouchEnd}
      role="dialog"
      aria-modal="true"
      aria-label="Tether welcome guide"
    >
      <div className="twg-progress-wrap">
        <div className="twg-progress-bar" style={{ width: `${pct}%` }} />
      </div>

      <div className="twg-slides">
        <AnimatePresence initial={false} mode="wait">
          <motion.div
            key={index}
            className="twg-slide"
            initial={{ opacity: 0, x: direction > 0 ? 50 : -50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: direction > 0 ? -50 : 50 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          >
            <SlideBody slide={slide} onFinish={finish} />
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="twg-bottom">
        <div className="twg-dots" aria-hidden="true">
          {Array.from({ length: TOTAL }).map((_, i) => (
            <div
              key={i}
              className={`twg-dot ${i === index ? "active" : ""}`}
            />
          ))}
        </div>
        <div className="twg-nav-row">
          <button
            type="button"
            className="twg-skip-btn"
            onClick={skip}
            disabled={isLast}
            aria-hidden={isLast}
          >
            Skip
          </button>
          <button
            type="button"
            className="twg-next-btn"
            onClick={next}
            hidden={isLast}
          >
            Next →
          </button>
        </div>
      </div>
    </motion.div>
  );
}

function SlideBody({
  slide,
  onFinish,
}: {
  slide: SlideContent;
  onFinish: () => void;
}) {
  if (slide.kind === "hero") {
    return (
      <div className="twg-slide-inner">
        <div className="twg-icon-wrap">
          <img src={slide.iconSrc} alt="Tether" className="twg-app-icon" />
          <div className="twg-icon-glow" aria-hidden="true" />
        </div>
        <h1 className="twg-heading">{slide.heading}</h1>
        <p className="twg-sub">{slide.sub}</p>
        <p className="twg-brand-note">{slide.brandNote}</p>
      </div>
    );
  }

  if (slide.kind === "outro") {
    return (
      <div className="twg-slide-inner">
        <div className="twg-feature-icon" aria-hidden="true">
          {slide.icon}
        </div>
        <h2 className="twg-heading">{slide.heading}</h2>
        <p className="twg-sub">{slide.sub}</p>
        <div className="twg-brand-block">
          <p className="twg-brand-name">{slide.brandName}</p>
          <p className="twg-brand-sub">{slide.brandSub}</p>
        </div>
        <button
          type="button"
          className="twg-finish-btn"
          onClick={onFinish}
        >
          Tether Up ✦
        </button>
      </div>
    );
  }

  return (
    <div className="twg-slide-inner">
      <div className="twg-feature-icon" aria-hidden="true">
        {slide.icon}
      </div>
      <h2 className="twg-heading">{slide.heading}</h2>
      <p className="twg-sub">{slide.sub}</p>
      <div className="twg-tip">
        <span className="twg-tip-label">{slide.tipLabel}</span>
        {slide.tipText}
      </div>
    </div>
  );
}
