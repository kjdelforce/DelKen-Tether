import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/lib/AuthContext";
import { haptic } from "@/lib/haptics";

/* ──────────────────────────────────────────────────────────────────
   OnboardingWizard
   ──────────────────────────────────────────────────────────────────
   3-step multi-tenant signup for new couples.

   Step 1 — Account
     • Email + password (Supabase Auth)
     • First name (used everywhere as the friendly display name)

   Step 2 — Couple
     • Create new couple → generates a 6-digit invite code to share
     • OR Join existing couple → enter partner's invite code

   Step 3 — Relationship setup
     • When did you start dating?
     • Your birthday
     • Partner's birthday (optional — they can fill it in themselves
       once they sign in)
   ────────────────────────────────────────────────────────────────── */

interface Props {
  onCancel: () => void;
}

type CoupleMode = "create" | "join";

export default function OnboardingWizard({ onCancel }: Props) {
  const {
    signUpWithEmail,
    createCoupleAndProfile,
    joinCoupleByCode,
    saveRelationshipDetails,
  } = useAuth();

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Step 1
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [firstName, setFirstName] = useState("");
  const [authUserId, setAuthUserId] = useState<string | null>(null);

  // Step 2
  const [mode, setMode] = useState<CoupleMode>("create");
  const [joinCode, setJoinCode] = useState("");
  const [createdCode, setCreatedCode] = useState<string | null>(null);

  // Step 3
  const [startDate, setStartDate] = useState("");
  const [myBirthday, setMyBirthday] = useState("");
  const [partnerBirthday, setPartnerBirthday] = useState("");

  // Wrap submit handlers ────────────────────────────────────────
  async function submitStep1(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!email.trim() || !password.trim() || !firstName.trim()) {
      setError("Email, password and your first name are all required.");
      return;
    }
    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }
    setBusy(true);
    haptic("light");
    const res = await signUpWithEmail(email, password);
    setBusy(false);
    if (res.error) { setError(res.error); return; }
    setAuthUserId(res.userId!);
    setStep(2);
  }

  async function submitStep2(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!authUserId) { setError("Sign-up state lost. Please start over."); return; }

    setBusy(true);
    haptic("light");
    if (mode === "create") {
      const res = await createCoupleAndProfile({
        authUserId,
        email,
        firstName: firstName.trim(),
      });
      setBusy(false);
      if (res.error) { setError(res.error); return; }
      setCreatedCode(res.inviteCode ?? null);
      setStep(3);
    } else {
      const res = await joinCoupleByCode({
        authUserId,
        email,
        firstName: firstName.trim(),
        inviteCode: joinCode,
      });
      setBusy(false);
      if (res.error) { setError(res.error); return; }
      setStep(3);
    }
  }

  async function submitStep3(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!startDate || !myBirthday) {
      setError("Please add your relationship start date and your birthday.");
      return;
    }
    setBusy(true);
    haptic("medium");
    const res = await saveRelationshipDetails({
      startDate,
      myBirthday,
      partnerBirthday: partnerBirthday || undefined,
    });
    setBusy(false);
    if (res.error) { setError(res.error); return; }
    setStep(4);
  }

  // ──── UI ─────────────────────────────────────────────────────
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#0a0a0f] px-6 relative overflow-hidden">
      {/* Background orbs */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-32 -left-32 w-72 h-72 rounded-full bg-[#C53030]/15 blur-3xl" />
        <div className="absolute -bottom-24 -right-24 w-64 h-64 rounded-full bg-blue-400/10 blur-3xl" />
      </div>

      <div className="relative w-full max-w-sm z-10">
        {/* Logo + step pill */}
        <div className="text-center mb-6">
          <h1 className="text-4xl font-bold text-white tracking-tight" style={{ fontFamily: "'Playfair Display', serif" }}>
            Tether
          </h1>
          <p className="text-blue-200/70 mt-1 text-xs tracking-widest uppercase">
            {step === 1 && "Step 1 of 3 · Create account"}
            {step === 2 && "Step 2 of 3 · Your couple"}
            {step === 3 && "Step 3 of 3 · Your story"}
            {step === 4 && "All set"}
          </p>
        </div>

        <AnimatePresence mode="wait">
          {/* ── STEP 1 ─────────────────────────────────────── */}
          {step === 1 && (
            <motion.form
              key="s1"
              onSubmit={submitStep1}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="glass-card rounded-2xl p-6 space-y-4"
            >
              <Field label="Your first name">
                <input
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  placeholder="What should your partner call you?"
                  className={inputCls}
                  autoCapitalize="words"
                />
              </Field>
              <Field label="Email">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className={inputCls}
                  autoCapitalize="none"
                  autoComplete="email"
                />
              </Field>
              <Field label="Password">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 8 characters"
                  className={inputCls}
                  autoComplete="new-password"
                />
              </Field>
              {error && <ErrorBox>{error}</ErrorBox>}
              <PrimaryBtn busy={busy}>Continue →</PrimaryBtn>
              <button type="button" onClick={onCancel} className="w-full text-blue-200/60 text-xs hover:text-white">
                ← Back to sign in
              </button>
            </motion.form>
          )}

          {/* ── STEP 2 ─────────────────────────────────────── */}
          {step === 2 && (
            <motion.form
              key="s2"
              onSubmit={submitStep2}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="glass-card rounded-2xl p-6 space-y-4"
            >
              {/* Toggle */}
              <div className="grid grid-cols-2 rounded-xl overflow-hidden border border-white/15">
                {(["create", "join"] as CoupleMode[]).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => { setMode(m); setError(null); }}
                    className={`py-2.5 text-xs font-semibold uppercase tracking-widest transition-colors ${
                      mode === m
                        ? "bg-white/15 text-white"
                        : "bg-transparent text-blue-200/60 hover:text-white"
                    }`}
                  >
                    {m === "create" ? "Create couple" : "Join couple"}
                  </button>
                ))}
              </div>

              {mode === "create" ? (
                <p className="text-blue-100/70 text-sm leading-relaxed">
                  We'll create a private Tether for you and generate a 6-digit code to share with your partner. They'll use it to join.
                </p>
              ) : (
                <Field label="Partner's invite code">
                  <input
                    type="text"
                    value={joinCode}
                    onChange={(e) => setJoinCode(e.target.value.toUpperCase().slice(0, 6))}
                    placeholder="6-digit code"
                    className={`${inputCls} tracking-widest font-mono`}
                    maxLength={6}
                  />
                </Field>
              )}

              {error && <ErrorBox>{error}</ErrorBox>}
              <PrimaryBtn busy={busy}>{mode === "create" ? "Create our Tether" : "Join Tether"}</PrimaryBtn>
            </motion.form>
          )}

          {/* ── STEP 3 ─────────────────────────────────────── */}
          {step === 3 && (
            <motion.form
              key="s3"
              onSubmit={submitStep3}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="glass-card rounded-2xl p-6 space-y-4"
            >
              {createdCode && (
                <div className="rounded-xl bg-white/5 border border-white/10 p-4 text-center">
                  <p className="text-xs uppercase tracking-widest text-blue-200/70 mb-1">Your invite code</p>
                  <p className="text-3xl font-mono tracking-[0.4em] text-white">{createdCode}</p>
                  <p className="text-xs text-blue-100/50 mt-2">Send this to your partner so they can join.</p>
                </div>
              )}

              <Field label="When did you start dating?">
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className={inputCls}
                />
              </Field>
              <Field label="Your birthday">
                <input
                  type="date"
                  value={myBirthday}
                  onChange={(e) => setMyBirthday(e.target.value)}
                  className={inputCls}
                />
              </Field>
              <Field label={`Partner's birthday (optional)`}>
                <input
                  type="date"
                  value={partnerBirthday}
                  onChange={(e) => setPartnerBirthday(e.target.value)}
                  className={inputCls}
                />
              </Field>

              {error && <ErrorBox>{error}</ErrorBox>}
              <PrimaryBtn busy={busy}>Finish setup ✓</PrimaryBtn>
            </motion.form>
          )}

          {/* ── STEP 4 ─────────────────────────────────────── */}
          {step === 4 && (
            <motion.div
              key="s4"
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              className="glass-card rounded-2xl p-8 text-center space-y-3"
            >
              <div className="text-5xl">💞</div>
              <h2 className="text-xl font-semibold text-white">You're tethered.</h2>
              <p className="text-blue-100/70 text-sm">
                Welcome to Tether, {firstName || "you"}. Your space is ready.
              </p>
              <button
                onClick={() => window.location.reload()}
                className="mt-4 w-full py-3 rounded-xl text-white font-semibold text-sm shadow-lg active:scale-95 transition-all"
                style={{ background: "radial-gradient(circle at 35% 35%, #E53E3E, #742A2A)" }}
              >
                Enter Tether →
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

/* ── tiny presentational helpers ──────────────────────────── */
const inputCls =
  "w-full px-4 py-3 rounded-xl bg-white/10 text-white placeholder-blue-400/60 border border-white/20 focus:outline-none focus:ring-2 focus:ring-[#C53030] focus:border-transparent text-sm";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-blue-200 text-xs font-semibold mb-2 uppercase tracking-widest">
        {label}
      </label>
      {children}
    </div>
  );
}

function ErrorBox({ children }: { children: React.ReactNode }) {
  return (
    <p className="text-red-300 text-sm bg-red-900/30 rounded-xl px-3 py-2 border border-red-500/30">
      {children}
    </p>
  );
}

function PrimaryBtn({ busy, children }: { busy: boolean; children: React.ReactNode }) {
  return (
    <button
      type="submit"
      disabled={busy}
      className="w-full py-3 rounded-xl text-white font-semibold text-sm shadow-lg active:scale-95 transition-all disabled:opacity-60"
      style={{ background: "radial-gradient(circle at 35% 35%, #E53E3E, #742A2A)" }}
    >
      {busy ? "Working…" : children}
    </button>
  );
}
