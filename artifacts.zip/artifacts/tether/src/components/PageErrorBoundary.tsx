import { Component, type ErrorInfo, type ReactNode } from "react";

interface Props {
  /** Identifies which page boundary caught the error (for logs/UI). */
  pageKey: string;
  /** When pageKey changes (i.e. user switches tabs) the boundary resets. */
  children: ReactNode;
  /** Called so the parent can offer a "go home" recovery path. */
  onReset?: () => void;
}

interface State {
  error: Error | null;
}

/**
 * Catches render errors thrown by a single page so a transient bug in one
 * tab can't white-screen the whole app. Resets automatically when the user
 * navigates to a different tab (pageKey changes), and offers a manual
 * "Try again" button on the fallback UI.
 *
 * Designed to wrap each entry under <AnimatePresence> in App.tsx.
 */
export class PageErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // Surface to console + (optionally) any error reporting service.
    // eslint-disable-next-line no-console
    console.error(
      `[PageErrorBoundary:${this.props.pageKey}]`,
      error,
      info.componentStack,
    );
  }

  componentDidUpdate(prev: Props) {
    if (prev.pageKey !== this.props.pageKey && this.state.error) {
      this.setState({ error: null });
    }
  }

  private handleRetry = () => {
    this.setState({ error: null });
    this.props.onReset?.();
  };

  render() {
    if (!this.state.error) return this.props.children;

    return (
      <div
        role="alert"
        style={{
          flex: 1,
          minHeight: 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: "32px 24px",
          textAlign: "center",
          color: "rgba(255,255,255,0.85)",
          fontFamily: "'Quicksand', sans-serif",
          gap: 14,
        }}
      >
        <div style={{ fontSize: "2.4rem" }} aria-hidden="true">
          💫
        </div>
        <h2 style={{ fontSize: "1.05rem", fontWeight: 700, margin: 0 }}>
          This page hiccupped
        </h2>
        <p
          style={{
            fontSize: "0.85rem",
            color: "rgba(255,255,255,0.65)",
            maxWidth: 280,
            margin: 0,
            lineHeight: 1.45,
          }}
        >
          Something went sideways while loading this view. Try again, or
          tap a different tab — the rest of the app is fine.
        </p>
        <button
          type="button"
          onClick={this.handleRetry}
          style={{
            marginTop: 6,
            padding: "10px 20px",
            borderRadius: 14,
            border: "1px solid rgba(255,255,255,0.18)",
            background: "rgba(255,255,255,0.06)",
            color: "white",
            fontFamily: "'Quicksand', sans-serif",
            fontWeight: 600,
            fontSize: "0.85rem",
            letterSpacing: "0.02em",
            cursor: "pointer",
          }}
        >
          Try again
        </button>
        {import.meta.env.DEV && (
          <pre
            style={{
              marginTop: 12,
              maxWidth: "92vw",
              maxHeight: 160,
              overflow: "auto",
              padding: 10,
              borderRadius: 10,
              background: "rgba(0,0,0,0.35)",
              border: "1px solid rgba(255,255,255,0.08)",
              fontSize: 11,
              lineHeight: 1.4,
              color: "rgba(255,180,180,0.9)",
              textAlign: "left",
              whiteSpace: "pre-wrap",
            }}
          >
            {this.state.error.message}
            {"\n"}
            {this.state.error.stack}
          </pre>
        )}
      </div>
    );
  }
}
