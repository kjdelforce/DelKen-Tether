import * as React from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import { haptic } from "@/lib/haptics";
import { playModalOpen, playModalClose } from "@/lib/sounds";

interface GuideItem {
  key: string;
  icon: string;
  title: string;
  sub: string;
  /** Detail body — interpreted as HTML so the spec's <strong>/tip blocks render. */
  body: string;
  /** When true, this item renders in the "✦ New" section at the top of the list. */
  isNew?: boolean;
}

// Verbatim copy from the brief — content order is intentional and must
// match the spec (Living Home → The Pulse → … → Settings, with Safe View
// sitting in second-to-last position). New features (isNew: true) are
// surfaced in a special section at the top of the list.
const GUIDE_ITEMS: GuideItem[] = [
  // ── New ──────────────────────────────────────────────────────────
  {
    key: "contact_high",
    icon: "✨",
    title: "Contact High",
    sub: "Tap your phones together for a synced spark",
    isNew: true,
    body: `When you and your partner physically tap your phones together, both screens light up at the exact same moment with a synchronised <strong>three-second moment</strong>.<br><br>A glowing <strong>Liquid-Glass spark</strong> emerges from the inner edge of each screen, swirls across an arc, and lands at the centre. The mesh gradient behind it <strong>vortexes</strong> toward the contact point, then bursts back out. A soft white <strong>border light leak</strong> halos both screens at the moment of impact and fades back into your active theme's accent colour. A heartbeat <strong>haptic</strong> pulses through the build-up — 75ms on, 100ms off — so it feels physical too.<div class="detail-tip"><span class="detail-tip-label">How it works</span>The sequence is triggered on one device and instantly mirrored to your partner via Tether's realtime channel, so the spark visually jumps the bezel gap between your screens. Reduced-motion users keep the spark and flash but the background vortex is suppressed.</div>`,
  },
  {
    key: "tether_strike",
    icon: "🏒",
    title: "Tether Strike",
    sub: "Cross-device Liquid-Glass air hockey",
    isNew: true,
    body: `A real-time game in the Games hub that turns <strong>both your phones into one continuous table</strong>. Drag your refractive glass mallet around the lower half of your screen to defend your goal-line. When the puck flies off the top of your screen it instantly appears at the bottom of your partner's screen — same X position, same velocity, same direction — escalating <strong>5% faster every crossing</strong>.<br><br>The puck is a <strong>Liquid-Glass disc</strong> that magnifies and warms the mesh gradient behind it as it moves, leaving a fading light-leak trail in your active theme's colour. Wall bounces fire a liquid splash and a haptic thud; mallet hits feel weighted thanks to spring physics. A floating glass score counter at the top updates in real-time on both devices.<div class="detail-tip"><span class="detail-tip-label">How to play</span>Open Games and tap the Tether Strike card on both phones. Once the lobby orb settles, drag your mallet anywhere in the lower half of your screen. First to outscore the other wins the rally — last scorer serves next.</div>`,
  },
  {
    key: "luxury_themes",
    icon: "💎",
    title: "Luxury Themes Collection",
    sub: "Five premium atmospheres for the whole app",
    isNew: true,
    body: `A curated collection of five <strong>premium atmospheres</strong> that re-skin the entire app — accent colours, fonts, glass blur depth, background mesh, and texture all shift together as one cohesive feel.<br><br><strong>Midnight Silk</strong> — deep violets and silver, a hushed late-night elegance.<br><strong>Golden Hour</strong> — warm ambers and rose gold, that low-sun sunset glow.<br><strong>Nordic</strong> — cool greys and pale ice, minimal Scandinavian calm.<br><strong>Retro Analog</strong> — burnt sienna and cream with a film-grain texture, a 70s warmth.<br><strong>Cyber Luxe</strong> — neon cyan and magenta over deep navy, polished futurism.<div class="detail-tip"><span class="detail-tip-label">How to apply</span>Go to Settings → App Themes. Tap any Luxury theme to preview it, then choose to apply it to yourself, your partner, or both. The change cascades through every surface of the app immediately — including the puck trails in Tether Strike and the spark colour in Contact High.</div>`,
  },
  {
    key: "living_atmosphere",
    icon: "🌊",
    title: "Living Atmosphere",
    sub: "Subtle motion and weather woven through the app",
    isNew: true,
    body: `A layer of always-on ambient details that make the app feel alive without ever getting in your way.<br><br><strong>Mesh Gradient</strong> — four soft colour blobs drift slowly behind everything, tinted by your active theme.<br><strong>Heartbeat Pulse</strong> — when your partner pulses you, a soft glow ripples around the screen border.<br><strong>Morphing NavIcons</strong> — the dock icons gently morph and the active tab swells as you switch.<br><strong>Micro-typography</strong> — text weight breathes from light to medium on hover and tap, so every interaction feels responsive.<br><strong>Liquid Realism</strong> — when your local weather is rainy, raindrops streak the glass; ocean light caustics shimmer on cards in beach conditions; tapping anywhere leaves a brief liquid ripple.<br><strong>Beach Shoreline</strong> — when the Beach theme is active, three layered SVG waves morph at the bottom of the screen with foam bubbles, gyroscope parallax, and a wet-sand pulse.<div class="detail-tip"><span class="detail-tip-label">Note</span>These all run automatically. Reduced-motion settings on your device will quiet down the heavier animations.</div>`,
  },
  {
    key: "proximity_pulse",
    icon: "📍",
    title: "Proximity Pulse",
    sub: "Senses when you're together or apart",
    isNew: true,
    body: `When you and your partner are physically close together — within the same area — your Home screen transforms. A glowing <strong>Tethered</strong> pill appears below your profile circles, the background warms gently, and a soft harp melody plays once to mark the moment.<br><br>When apart, the pill shows a poetic sense of distance — <em>Close by</em>, <em>Across the city</em>, <em>Far away</em>, or <em>Worlds apart</em>.<div class="detail-tip"><span class="detail-tip-label">How to enable</span>Go to Settings → Proximity Pulse and switch it on. Location is only ever shared between the two of you and is never stored beyond what's needed to calculate distance. You can turn it off any time.</div>`,
  },
  {
    key: "love_note",
    icon: "💌",
    title: "Love Note Drop",
    sub: "Sealed handwritten notes for your partner",
    isNew: true,
    body: `Leave a sealed handwritten note for your partner to find. It floats near your profile circles on their Home screen — glowing gently until they tap it to unfold it.<br><br>Once read, every note is kept forever in the <strong>Keepsake Drawer</strong> in the Profile Hub.<div class="detail-tip"><span class="detail-tip-label">How to leave a note</span>Tap the Leave a Note button near the profile circles on the Home screen. Write your message, tap Seal and Leave, and it appears waiting on their app. Only one note at a time.</div>`,
  },
  {
    key: "two_truths",
    icon: "🎭",
    title: "Two Truths One Lie",
    sub: "The new game in Games",
    isNew: true,
    body: `A private game in the Games section. One of you writes <strong>three statements</strong> — two true, one false — and the other has to spot the lie.<br><br>Roles swap after every round and a running score is kept. It reveals new things about each other even after years together.<div class="detail-tip"><span class="detail-tip-label">How to play</span>Open Games and tap Two Truths One Lie. Write your three statements, tap Lie next to the false one, and send it. Your partner gets notified and taps the one they think is the lie. The answer reveals with an animation.</div>`,
  },
  {
    key: "wrapped",
    icon: "🎁",
    title: "Tether Wrapped",
    sub: "Your year together — Dec 25 to Jan 1",
    isNew: true,
    body: `Available every year from <strong>December 25 through January 1</strong>. A cinematic swipeable story of your year together — memories added, pulses sent, dates planned, capsules sealed, and an AI-written love letter to your year.<br><br>It appears as a special card in the Games section during the festive window.<div class="detail-tip"><span class="detail-tip-label">How to access</span>Open Games between December 25 and January 1. Tap the Tether Wrapped card and tap Unwrap to begin. Swipe through your year.</div>`,
  },
  {
    key: "themes",
    icon: "🎨",
    title: "Colour Themes",
    sub: "Gift a theme to your partner",
    isNew: true,
    body: `Five premium themes that change the visual feel of the app. The unique mechanic — <strong>you pick a theme for your partner, not yourself</strong>. When you choose a theme it applies to your partner's app, and when they choose one it applies to yours.<br><br>Themes: Midnight, Rosewood, Arctic, Ember, and Celestial.<div class="detail-tip"><span class="detail-tip-label">How to gift a theme</span>Go to Settings. Under "Gift a Theme", tap the theme you want to give your partner and tap the Gift button. It applies to their app instantly and they'll see a notification.</div>`,
  },
  {
    key: "themes_seasonal",
    icon: "🎨",
    title: "Seasonal Themes",
    sub: "Six special themes that transform the app",
    isNew: true,
    body: `Six special themes that transform the entire app atmosphere.<br><br><strong>Beach</strong> — warm whites, ocean blues and water shimmer on glass cards.<br><strong>Christmas</strong> — snowy white, fairy lights on cards, hanging decorations and a festive wreath around your names.<br><strong>Autumn</strong> — burnt orange, amber and falling leaves.<br><strong>Camping</strong> — forest green with a live animated campfire and smoke in your weather card.<br><strong>St Patrick's Day</strong> — emerald green, gold and drifting shamrocks with a rainbow sweep.<br><strong>Easter</strong> — soft lavender, mint and pastel with floating eggs and a pastel shimmer on cards.<div class="detail-tip"><span class="detail-tip-label">How to apply</span>Go to Settings → App Themes. Select a theme and choose to apply it to yourself, your partner, or both.</div>`,
  },
  {
    key: "island",
    icon: "💫",
    title: "Live Notifications",
    sub: "Dynamic Island style alerts",
    isNew: true,
    body: `When your partner pulses you or adds a new memory, a <strong>pill-shaped notification</strong> slides down from the top of the screen — styled after the iPhone Dynamic Island.<br><br>It shows who sent the pulse, animates briefly, then quietly retreats. No interruption, just a beautiful moment of presence.<div class="detail-tip"><span class="detail-tip-label">Note</span>These appear automatically — no setup needed. They work whenever the app is open and your partner triggers an event.</div>`,
  },

  {
    key: "cheat_sheet",
    icon: "☕",
    title: "The Cheat Sheet",
    sub: "Quick-reference details about each other",
    isNew: true,
    body: `The Cheat Sheet lives on each of your profiles. It's a <strong>quick-reference card</strong> for the little things that are easy to forget but lovely to remember — coffee orders, shoe sizes, ring sizes, favourite colours, favourite foods, clothing sizes, the movies and shows you love most, how you wind down at night, and the music you reach for.<br><br>Both of you can fill in your own. The Coffee Order card has a one-tap copy button so it's instantly ready when you're standing in the queue.<div class="detail-tip"><span class="detail-tip-label">How to fill it in</span>Go to the Us page, tap your own profile, then tap ✏️ to edit. Scroll to "The Cheat Sheet" and fill in any fields you'd like to share. Save when done — your partner sees the update straight away.</div>`,
  },

  // ── Classics ─────────────────────────────────────────────────────
  {
    key: "home",
    icon: "🌅",
    title: "Living Home",
    sub: "Dynamic sky & home screen",
    body: `Your Home screen is a living space. It reads your <strong>real-time local weather and time of day</strong> and shifts its atmosphere to match — warm amber mornings, deep blue nights, grey rainy afternoons.<br><br>The background is always moving, always current. It reflects the world you're both in right now.<div class="detail-tip"><span class="detail-tip-label">Tip</span>The sky updates automatically each time you open the app. No setup needed.</div>`,
  },
  {
    key: "pulse",
    icon: "💓",
    title: "The Pulse",
    sub: "Send a silent thinking-of-you signal",
    body: `The Pulse is a single tap that sends a quiet signal to your partner — <strong>no words, no pressure</strong>, just a gentle notification that says you're thinking of them.<br><br>It sits on the Home screen and is always one tap away.<div class="detail-tip"><span class="detail-tip-label">How to use</span>Tap the Pulse button on the Home screen. Your partner receives an instant notification. There's no reply required — it's just a moment of connection.</div>`,
  },
  {
    key: "scrapbook",
    icon: "📖",
    title: "Scrapbook",
    sub: "Your shared memory book",
    body: `The Scrapbook is your private shared memory book. Every photo and note you add becomes a <strong>page in a real book</strong> that only you and your partner can read.<br><br>It's designed to feel physical — pages turn, photos sit like polaroids, notes appear in handwriting-style text.<div class="detail-tip"><span class="detail-tip-label">How to use</span>Tap Scrapbook in the dock. <strong>Rotate your phone to landscape</strong> to open the book view. Swipe left and right to turn pages. Tap the + button to add a new photo or note memory.</div>`,
  },
  {
    key: "dates",
    icon: "📅",
    title: "Dates",
    sub: "Plan and archive your outings",
    body: `Dates is your shared planning and archive space. <strong>Propose outings, organise plans, and keep a permanent record</strong> of every adventure you've had together.<br><br>Both of you can see, edit, and add to the Dates planner at any time.<div class="detail-tip"><span class="detail-tip-label">How to use</span>Tap Dates in the dock. Tap + to add a new date — give it a title, set the date, and add any notes. Both of you will see it instantly.</div>`,
  },
  {
    key: "games",
    icon: "🎮",
    title: "Games",
    sub: "Private games for two",
    body: `Private games built <strong>exclusively for two</strong>. Play together whether you're side by side on the couch or on opposite sides of the world.<br><br>Your partner is notified when it's their turn so games carry on naturally across time.<div class="detail-tip"><span class="detail-tip-label">How to use</span>Tap Games in the dock to see all available games. Tap one to start or continue playing. Notifications let your partner know when you've made a move.</div>`,
  },
  {
    key: "capsules",
    icon: "⏳",
    title: "Capsules",
    sub: "Time-locked messages to your future selves",
    body: `A Capsule is a <strong>sealed message, photo, or promise</strong> that can only be opened on a future date you choose. Like a letter to your future selves — locked until the moment is right.<br><br>Once sealed, neither of you can read it until the open date arrives.<div class="detail-tip"><span class="detail-tip-label">How to use</span>Tap Capsules in the dock. Tap + to create one — write your message, optionally add a photo, set a future open date, and seal it. It will unlock automatically on that day.</div>`,
  },
  {
    key: "us",
    icon: "👥",
    title: "Us",
    sub: "Your relationship hub & profiles",
    body: `The Us page is your <strong>relationship hub</strong>. It shows your days together counter, both your mood statuses, shared stats, love language insights, and quick access to your individual profiles.<br><br>It's the most personal corner of Tether — everything that defines the two of you in one place.<div class="detail-tip"><span class="detail-tip-label">How to use</span>Tap Us in the dock. Update your mood from here, view your shared timeline, and access profile settings. The Love Language and Spicy Stats sections update as you both interact with the app.</div>`,
  },
  {
    key: "ai",
    icon: "✦",
    title: "Tether AI",
    sub: "Relationship memory & assistant",
    body: `The Tether AI is your <strong>relationship memory</strong>. It knows your entire shared history — every Scrapbook entry, every date, every capsule — and you can ask it anything.<br><br>It also writes photo captions for the Scrapbook and surfaces a daily insight about the two of you on the Home screen.<div class="detail-tip"><span class="detail-tip-label">How to use</span>The AI memory card lives on your Home screen — tap "Ask anything about us" to open a conversation. In the Scrapbook, tap the ✦ button below the caption field to generate a personalised caption. Voice input is available via the microphone button.</div>`,
  },
  {
    key: "diffuser",
    icon: "🕊",
    title: "The Diffuser",
    sub: "Find calm during hard moments",
    body: `The Diffuser is a <strong>private, calm space</strong> that appears in the Us page. When things feel tense or hard, it offers a neutral, compassionate space to process your thoughts before a conversation.<br><br>It never takes sides. It reflects, validates, and helps you find perspective.<div class="detail-tip"><span class="detail-tip-label">How to use</span>Go to the Us page and tap "Open a safe space" in the Diffuser card. Type or speak what's going on. The AI responds gently and neutrally. Everything in this space stays private.</div>`,
  },
  {
    key: "safeview",
    icon: "🛡️",
    title: "Safe View",
    sub: "Privacy mode for shared screens",
    body: `Safe View is a <strong>personal privacy mode</strong> for moments when others might see your screen — family, friends, or anyone nearby.<br><br>When turned on it blurs out your Love Language and Spicy Stats sections plus your Daily Connection answers. <strong>It only affects your own device</strong> — your partner's app is completely unaffected.<br><br>When you turn it back off, everything instantly reverts to exactly how it was.<div class="detail-tip"><span class="detail-tip-label">How to turn on</span>Go to Settings → Preferences → Safe View. Toggle it on. A small 🛡️ badge appears in the top corner of the app while it's active. Toggle it off any time to restore everything.</div>`,
  },
  {
    key: "settings",
    icon: "⚙️",
    title: "Settings",
    sub: "Sounds, notifications & preferences",
    body: `Settings lets you control how Tether behaves on <strong>your device</strong>.<br><br><strong>Sounds</strong> — toggle all app audio effects and the launch sound on or off.<br><br><strong>Notifications</strong> — enable or disable Pulse alerts and new memory notifications.<br><br><strong>Safe View</strong> — activate personal privacy mode (see Safe View guide for details).<br><br><strong>App Guide</strong> — return to this guide any time.<br><br><strong>Privacy Statement</strong> — read how DelKen Tech handles your data.<div class="detail-tip"><span class="detail-tip-label">How to access</span>Tap the ⚙️ Settings icon at the end of the bottom dock from anywhere in the app.</div>`,
  },
];

interface AppGuideMenuProps {
  open: boolean;
  onClose: () => void;
}

/**
 * Liquid-glass bottom-sheet App Guide. Two layers:
 *   1. Sheet with the scrollable list of features.
 *   2. Detail card overlay (rendered when an item is tapped).
 *
 * Both layers are rendered into <body> via createPortal so they sit
 * above all in-app stacking contexts. Esc closes the topmost layer
 * first (detail before sheet) — matching iOS modal behaviour.
 */
export function AppGuideMenu({ open, onClose }: AppGuideMenuProps) {
  const [detail, setDetail] = React.useState<GuideItem | null>(null);

  // Close detail whenever the menu itself closes — prevents a stale
  // detail card from flashing in if the user re-opens the menu later.
  React.useEffect(() => {
    if (!open) setDetail(null);
  }, [open]);

  // Esc handling — detail closes first, then the sheet
  React.useEffect(() => {
    if (!open) return;
    function onKey(e: KeyboardEvent) {
      if (e.key !== "Escape") return;
      e.preventDefault();
      if (detail) {
        setDetail(null);
        playModalClose();
      } else {
        onClose();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, detail, onClose]);

  // Lock background scroll while the sheet is up
  React.useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  const openDetail = React.useCallback((g: GuideItem) => {
    haptic("light");
    playModalOpen();
    setDetail(g);
  }, []);

  const closeDetail = React.useCallback(() => {
    haptic("light");
    playModalClose();
    setDetail(null);
  }, []);

  if (!open) return null;

  return createPortal(
    <>
      <div className="tgm-overlay open" role="dialog" aria-modal="true" aria-label="App Guide">
        <div className="tgm-backdrop" onClick={onClose} />
        <motion.div
          className="tgm-sheet"
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 40, opacity: 0 }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="tgm-handle" aria-hidden="true" />
          <div className="tgm-header">
            <h2 className="tgm-title">App Guide</h2>
            <button
              type="button"
              className="tgm-close"
              onClick={() => {
                haptic("light");
                playModalClose();
                onClose();
              }}
              aria-label="Back to Settings"
            >
              ← Back
            </button>
          </div>
          <p className="tgm-subtitle">Tap any feature to learn more</p>
          <div className="tgm-scroll">
            {/* New section — surfaced at the top with a label and a
                divider so just-shipped features are easy to spot. */}
            {GUIDE_ITEMS.some((g) => g.isNew) && (
              <div className="tgm-new-label">✦ New</div>
            )}
            {GUIDE_ITEMS.filter((g) => g.isNew).map((g) => (
              <button
                key={g.key}
                type="button"
                className="tgm-item tgm-item-new"
                onClick={() => openDetail(g)}
              >
                <span className="tgm-item-icon" aria-hidden="true">{g.icon}</span>
                <div className="tgm-item-text">
                  <p className="tgm-item-title">{g.title}</p>
                  <p className="tgm-item-sub">{g.sub}</p>
                </div>
                <span className="tgm-item-chevron" aria-hidden="true">›</span>
              </button>
            ))}
            {GUIDE_ITEMS.some((g) => g.isNew) && (
              <div className="tgm-section-divider" />
            )}

            {GUIDE_ITEMS.filter((g) => !g.isNew).map((g) => (
              <button
                key={g.key}
                type="button"
                className="tgm-item"
                onClick={() => openDetail(g)}
              >
                <span className="tgm-item-icon" aria-hidden="true">
                  {g.icon}
                </span>
                <div className="tgm-item-text">
                  <p className="tgm-item-title">{g.title}</p>
                  <p className="tgm-item-sub">{g.sub}</p>
                </div>
                <span className="tgm-item-chevron" aria-hidden="true">
                  ›
                </span>
              </button>
            ))}
          </div>
        </motion.div>
      </div>

      <AnimatePresence>
        {detail && (
          <motion.div
            key="detail"
            className="tgm-detail-overlay open"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={(e) => {
              if (e.target === e.currentTarget) closeDetail();
            }}
          >
            <motion.div
              className="tgm-detail-card"
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 30, opacity: 0 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="tgm-detail-handle" aria-hidden="true" />
              <div className="tgm-detail-icon" aria-hidden="true">
                {detail.icon}
              </div>
              <h3 className="tgm-detail-title">{detail.title}</h3>
              {/* Spec body uses <strong>, <br>, and a .detail-tip block. */}
              <div
                className="tgm-detail-body"
                dangerouslySetInnerHTML={{ __html: detail.body }}
              />
              <button
                type="button"
                className="tgm-detail-close-btn"
                onClick={closeDetail}
              >
                Got it ✦
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>,
    document.body,
  );
}
