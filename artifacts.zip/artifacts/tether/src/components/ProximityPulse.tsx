// ═══════════════════════════════════════════════════════════
//  ProximityPulse.tsx — Tethered/apart pill + permission UI
//  ─────────────────────────────────────────────────────────────
//  Self-contained: subscribes to its own enable/disable events,
//  uploads my location every 30 s while enabled, and renders
//  either nothing, the apart pill, or the glowing tethered pill
//  with a one-off harp melody when the state flips to tethered.
//
//  Two exports:
//    • <ProximityPulse>    — drop into Home below profile circles.
//    • <ProximityToggle>   — drop into Settings as a tsp-row.
// ═══════════════════════════════════════════════════════════
import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import {
  DISTANCE_TIERS,
  FIRST_PROMPT_KEY,
  STALE_AFTER_MINUTES,
  UPDATE_INTERVAL_MS,
  fetchPartnerLocation,
  getCurrentPosition,
  getDistanceKm,
  getDistanceTier,
  getStoredPermission,
  isProximityEnabled,
  playTetheredHarp,
  setProximityEnabled,
  setSharingEnabledOnly,
  setStoredPermission,
  upsertMyLocation,
  type DistanceTier,
} from "@/lib/proximity";
import { supabase } from "@/lib/supabaseClient";
import { haptic } from "@/lib/haptics";

// ════════════════════════════════════════════════════════════
//  Permission overlay — shown when enabling the toggle without
//  prior permission, and once on first launch.
// ════════════════════════════════════════════════════════════
function PermissionOverlay({
  open,
  onAllow,
  onSkip,
}: {
  open: boolean;
  onAllow: () => void;
  onSkip: () => void;
}) {
  return createPortal(
    <div className={`ppo-overlay ${open ? "open" : ""}`} aria-hidden={!open}>
      <div className="ppo-card" role="dialog" aria-label="Proximity Pulse permission">
        <div className="ppo-icon">📍</div>
        <h2 className="ppo-title">Proximity Pulse</h2>
        <p className="ppo-body">
          Allow Tether to sense when you and your partner are physically
          together. Your location is only ever shared with each other —
          never stored beyond what's needed to calculate distance.
        </p>
        <button className="ppo-allow-btn" type="button" onClick={onAllow}>
          Enable Proximity ✦
        </button>
        <button className="ppo-skip-btn" type="button" onClick={onSkip}>
          Not now
        </button>
      </div>
    </div>,
    document.body,
  );
}

// ════════════════════════════════════════════════════════════
//  Main pill — rendered on Home below the profile circles.
// ════════════════════════════════════════════════════════════
export function ProximityPulse({
  tetherId,
  userId,
  partnerId,
  partnerName,
}: {
  tetherId: string;
  userId: string;
  partnerId: string;
  partnerName: string;
}) {
  const [enabled, setEnabled] = useState<boolean>(() => isProximityEnabled());
  const [tier, setTier] = useState<DistanceTier | null>(null);
  const [hidden, setHidden] = useState(true); // pill hidden until first successful read
  const [overlayOpen, setOverlayOpen] = useState(false);
  const lastStateRef = useRef<"tethered" | "apart" | null>(null);

  // Listen for toggle events from Settings (same tab) and storage (other tab).
  useEffect(() => {
    const onCustom = (e: Event) => {
      const detail = (e as CustomEvent<{ enabled: boolean }>).detail;
      setEnabled(Boolean(detail?.enabled));
    };
    const onStorage = (e: StorageEvent) => {
      if (e.key === "tether_proximity_enabled") {
        setEnabled(e.newValue === "true");
      }
    };
    window.addEventListener("tether-proximity-toggle", onCustom);
    window.addEventListener("storage", onStorage);
    return () => {
      window.removeEventListener("tether-proximity-toggle", onCustom);
      window.removeEventListener("storage", onStorage);
    };
  }, []);

  // First-launch prompt — show once per device, after a short settle.
  useEffect(() => {
    if (localStorage.getItem(FIRST_PROMPT_KEY) === "true") return;
    const t = window.setTimeout(() => setOverlayOpen(true), 2500);
    return () => window.clearTimeout(t);
  }, []);

  // Main update cycle — runs every UPDATE_INTERVAL_MS while enabled.
  const runCycle = useCallback(async () => {
    try {
      const myPos = await getCurrentPosition();
      await upsertMyLocation({
        tetherId, userId,
        lat: myPos.lat, lng: myPos.lng,
        sharingEnabled: true,
      });

      const partnerLoc = await fetchPartnerLocation({ tetherId, partnerId });
      if (!partnerLoc || !partnerLoc.sharing_enabled) {
        setHidden(true);
        lastStateRef.current = null;
        return;
      }
      const ageMin = (Date.now() - new Date(partnerLoc.updated_at).getTime()) / 60_000;
      if (ageMin > STALE_AFTER_MINUTES) {
        setHidden(true);
        lastStateRef.current = null;
        return;
      }

      const km = getDistanceKm(myPos.lat, myPos.lng, partnerLoc.latitude, partnerLoc.longitude);
      const next = getDistanceTier(km);
      setTier(next);
      setHidden(false);

      if (next.state === "tethered" && lastStateRef.current !== "tethered") {
        // Coming together — celebrate once.
        haptic("success");
        window.setTimeout(playTetheredHarp, 600);
      }
      lastStateRef.current = next.state;
    } catch (err) {
      console.log("[proximity] cycle failed:", (err as Error).message);
      setHidden(true);
      lastStateRef.current = null;
    }
  }, [tetherId, userId, partnerId]);

  // Start / stop the polling loop based on the enabled flag.
  useEffect(() => {
    if (!enabled || getStoredPermission() !== "granted") {
      setHidden(true);
      lastStateRef.current = null;
      return;
    }
    runCycle();
    const id = window.setInterval(runCycle, UPDATE_INTERVAL_MS);
    return () => window.clearInterval(id);
  }, [enabled, runCycle]);

  // Body class for warm background shift.
  useEffect(() => {
    const cls = "proximity-tethered";
    if (!hidden && tier?.state === "tethered") {
      document.body.classList.add(cls);
    } else {
      document.body.classList.remove(cls);
    }
    return () => { document.body.classList.remove(cls); };
  }, [hidden, tier]);

  // Realtime: when the partner uploads a fresh row, recompute immediately.
  useEffect(() => {
    if (!enabled || getStoredPermission() !== "granted") return;
    const ch = supabase
      .channel(`partner-locations-${tetherId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "partner_locations",
          filter: `tether_id=eq.${tetherId}`,
        },
        (payload) => {
          const row = (payload.new ?? payload.old) as { user_id?: string } | null;
          if (row?.user_id && row.user_id !== userId) runCycle();
        },
      )
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [enabled, tetherId, userId, runCycle]);

  // Warm overlay div — single instance, mounted to body.
  useEffect(() => {
    let div = document.getElementById("proximity-warm-overlay");
    if (!div) {
      div = document.createElement("div");
      div.id = "proximity-warm-overlay";
      document.body.appendChild(div);
    }
  }, []);

  async function handleAllow() {
    haptic("light");
    localStorage.setItem(FIRST_PROMPT_KEY, "true");
    try {
      await getCurrentPosition(); // triggers browser prompt
      setStoredPermission("granted");
      setProximityEnabled(true);
      setOverlayOpen(false);
    } catch {
      setStoredPermission("denied");
      setOverlayOpen(false);
    }
  }

  function handleSkip() {
    haptic("tap");
    localStorage.setItem(FIRST_PROMPT_KEY, "true");
    setStoredPermission("denied");
    setOverlayOpen(false);
  }

  const showPill = enabled && !hidden && tier !== null;

  return (
    <>
      <div className={`pp-pill-wrap ${showPill ? "visible" : ""}`} aria-live="polite">
        {tier && (
          <div className={`pp-pill ${tier.state}`}>
            <div className="pp-dot" />
            {tier.state === "tethered" ? (
              <span className="pp-text">Tethered</span>
            ) : (
              <span className="pp-text">
                <span className="pp-partner-name">{partnerName}</span>
                {" "}is {tier.label.toLowerCase()}
              </span>
            )}
          </div>
        )}
      </div>
      <PermissionOverlay
        open={overlayOpen}
        onAllow={handleAllow}
        onSkip={handleSkip}
      />
    </>
  );
}

// ════════════════════════════════════════════════════════════
//  Settings toggle — drop in the Settings card.
// ════════════════════════════════════════════════════════════
export function ProximityToggle({
  tetherId,
  userId,
}: {
  tetherId: string;
  userId: string;
}) {
  const [enabled, setEnabled] = useState<boolean>(() => isProximityEnabled());
  const [overlayOpen, setOverlayOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  // Stay in sync if the flag flips elsewhere (Home overlay etc).
  useEffect(() => {
    const onCustom = (e: Event) => {
      const detail = (e as CustomEvent<{ enabled: boolean }>).detail;
      setEnabled(Boolean(detail?.enabled));
    };
    const onStorage = (e: StorageEvent) => {
      if (e.key === "tether_proximity_enabled") setEnabled(e.newValue === "true");
    };
    window.addEventListener("tether-proximity-toggle", onCustom);
    window.addEventListener("storage", onStorage);
    return () => {
      window.removeEventListener("tether-proximity-toggle", onCustom);
      window.removeEventListener("storage", onStorage);
    };
  }, []);

  async function handleChange(next: boolean) {
    if (busy) return;
    haptic("tap");
    if (next) {
      // Need permission first.
      if (getStoredPermission() !== "granted") {
        setOverlayOpen(true);
        return;
      }
      setBusy(true);
      setProximityEnabled(true);
      setEnabled(true);
      setBusy(false);
    } else {
      setBusy(true);
      setProximityEnabled(false);
      setEnabled(false);
      // Tell the partner we're no longer sharing so their pill hides.
      await setSharingEnabledOnly({ tetherId, userId, sharingEnabled: false });
      setBusy(false);
    }
  }

  async function handleAllow() {
    haptic("light");
    localStorage.setItem(FIRST_PROMPT_KEY, "true");
    try {
      await getCurrentPosition();
      setStoredPermission("granted");
      setProximityEnabled(true);
      setEnabled(true);
      setOverlayOpen(false);
    } catch {
      setStoredPermission("denied");
      setOverlayOpen(false);
    }
  }

  function handleSkip() {
    haptic("tap");
    localStorage.setItem(FIRST_PROMPT_KEY, "true");
    setStoredPermission("denied");
    setOverlayOpen(false);
  }

  return (
    <>
      <label className="tsp-row" htmlFor="tsp-proximity-toggle">
        <div className="tsp-row-info">
          <span className="tsp-row-icon" aria-hidden="true">📍</span>
          <div>
            <p className="tsp-row-title">Proximity Pulse</p>
            <p className="tsp-row-sub">Sense when you're together or apart</p>
          </div>
        </div>
        <span className="tsp-toggle">
          <input
            id="tsp-proximity-toggle"
            type="checkbox"
            checked={enabled}
            disabled={busy}
            onChange={(e) => handleChange(e.target.checked)}
          />
          <span className="tsp-toggle-track" />
        </span>
      </label>
      <PermissionOverlay
        open={overlayOpen}
        onAllow={handleAllow}
        onSkip={handleSkip}
      />
    </>
  );
}

// Re-export tiers for any future "settings detail" copy.
export { DISTANCE_TIERS };
