// ═══════════════════════════════════════════════════════════
//  MeshGradientBackground.tsx — Living mesh gradient layer.
//  ─────────────────────────────────────────────────────────────
//  Four large soft radial blobs that slowly translate across
//  the viewport on independent loops, producing the "oozing"
//  mesh-gradient effect. Each blob's colour is read directly
//  from the active theme's CSS custom properties so the entire
//  mesh recolours the moment a theme is gifted or chosen.
//
//  Sits at z-index 0 — above the body's #0a0a0f floor but
//  below every interactive UI surface — and is `pointer-events:
//  none` so it never intercepts touches.
//
//  All motion is GPU-only (`transform: translate3d`) so the
//  layer stays at 60fps on mobile.
// ═══════════════════════════════════════════════════════════
import { useEffect, useState } from "react";
import { THEME_CHANGE_EVENT } from "@/lib/themes";

export function MeshGradientBackground() {
  // Cheap re-render hook: bumping `tick` when the theme changes
  // forces React to recompute the inline `style` so blob colours
  // refresh even if the var() resolution somehow gets cached.
  const [, setTick] = useState(0);

  useEffect(() => {
    const onChange = () => setTick((n) => n + 1);
    window.addEventListener(THEME_CHANGE_EVENT, onChange);
    return () => window.removeEventListener(THEME_CHANGE_EVENT, onChange);
  }, []);

  return (
    <div className="mesh-gradient-bg" aria-hidden="true">
      {/* Four blobs, each with its own colour, size, and animation
       * loop. The fallback colours fire only on first paint before
       * the theme provider has run; after that, the var() takes
       * over and stays in lock-step with the theme. */}
      <div
        className="mesh-blob mesh-blob-1"
        style={{ background: "radial-gradient(circle at center, var(--theme-accent-glow, rgba(120,80,200,0.35)) 0%, transparent 65%)" }}
      />
      <div
        className="mesh-blob mesh-blob-2"
        style={{ background: "radial-gradient(circle at center, var(--theme-accent, rgba(180,140,255,0.30)) 0%, transparent 60%)" }}
      />
      <div
        className="mesh-blob mesh-blob-3"
        style={{ background: "radial-gradient(circle at center, var(--theme-bg-secondary, #0d1a2e) 0%, transparent 60%)" }}
      />
      <div
        className="mesh-blob mesh-blob-4"
        style={{ background: "radial-gradient(circle at center, var(--theme-particle, rgba(255,255,255,0.10)) 0%, transparent 70%)" }}
      />
    </div>
  );
}
