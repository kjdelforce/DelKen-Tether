import { useEffect, useRef } from "react";

/**
 * RippleOverlay
 * ──────────────
 * One-shot canvas effect that plays in response to the user tapping
 * the splash's Enter button. Three concentric expanding rings (white
 * core + lavender bloom) sweep outward from the tap point while the
 * whole layer fades to zero.
 *
 * Pure additive: this component sits on top of whatever the app
 * renders, plays for ~85 frames (~1.4s @ 60fps), then calls
 * `onComplete` so the parent can unmount it. The home screen renders
 * underneath and is fully visible the entire time — `pointer-events`
 * is disabled so the overlay never intercepts taps.
 *
 * `origin` defaults to the centre of the viewport. When provided
 * (typically the {clientX, clientY} from the Enter tap) the rings
 * radiate from that exact pixel, which makes the launch feel
 * physically responsive to the touch.
 */
export function RippleOverlay({
  onComplete,
  origin,
}: {
  onComplete?: () => void;
  origin?: { x: number; y: number };
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef   = useRef<HTMLDivElement | null>(null);
  // Guard onComplete behind a ref so prop-identity changes never
  // cause the rAF loop to be re-armed mid-flight.
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  useEffect(() => {
    // Honour the user's motion-sensitivity preference. If they've
    // asked the OS to reduce motion, skip the animated rings entirely
    // and hand back to the parent immediately.
    const reduceMotion =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    if (reduceMotion) {
      onCompleteRef.current?.();
      return;
    }

    const canvas = canvasRef.current;
    const wrap   = wrapRef.current;
    if (!canvas || !wrap) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = (canvas.width  = window.innerWidth);
    const H = (canvas.height = window.innerHeight);
    const cx = origin?.x ?? W / 2;
    const cy = origin?.y ?? H / 2;

    // Max distance the ripple has to cover to reach the furthest
    // corner from its origin. For an off-centre tap this is larger
    // than half-diagonal — so the rings stay visible until they've
    // truly swept the whole screen.
    const maxR =
      Math.sqrt(Math.max(cx, W - cx) ** 2 + Math.max(cy, H - cy) ** 2) * 1.1;

    // Three rings staggered in time, decreasing alpha + width — gives
    // the "wake behind a leading wave" look without overpowering the
    // home screen fading in beneath.
    const seeds = [
      { startFrame: 0,  speed: 18, alpha: 0.6,  width: 2.5 },
      { startFrame: 6,  speed: 20, alpha: 0.4,  width: 1.8 },
      { startFrame: 14, speed: 22, alpha: 0.22, width: 1.2 },
    ];

    let frame = 0;
    const maxFrames = 75;
    let raf = 0;
    let done = false;

    const finish = () => {
      if (done) return;
      done = true;
      cancelAnimationFrame(raf);
      onCompleteRef.current?.();
    };

    const drawFrame = () => {
      ctx.clearRect(0, 0, W, H);

      for (const seed of seeds) {
        const age = frame - seed.startFrame;
        if (age < 0) continue;

        const radius   = age * seed.speed;
        const progress = radius / maxR;
        const alpha    = seed.alpha * (1 - progress);
        if (alpha <= 0) continue;

        // White leading edge.
        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(255, 255, 255, ${alpha})`;
        ctx.lineWidth   = seed.width * (1 - progress * 0.5);
        ctx.stroke();

        // Lavender inner bloom — slightly behind the leading edge,
        // 3x thicker and lower alpha for the soft glow halo.
        ctx.beginPath();
        ctx.arc(cx, cy, radius * 0.96, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(180, 140, 255, ${alpha * 0.45})`;
        ctx.lineWidth   = seed.width * 3 * (1 - progress);
        ctx.stroke();
      }

      // Whole overlay fades from full to empty across the run.
      wrap.style.opacity = String(Math.max(0, 1 - (frame / maxFrames) * 1.2));
      frame++;

      if (frame < maxFrames + 10) {
        raf = requestAnimationFrame(drawFrame);
      } else {
        finish();
      }
    };

    raf = requestAnimationFrame(drawFrame);

    return () => {
      cancelAnimationFrame(raf);
      // Don't fire onComplete on unmount-before-finish — the parent
      // is already tearing us down for some other reason.
    };
    // origin is captured at mount on purpose: the ripple should
    // radiate from the pixel the user actually touched, not chase
    // a moving prop.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div
      ref={wrapRef}
      aria-hidden="true"
      style={{
        position: "fixed",
        inset: 0,
        // Above the splash (z-index 10000) so the ripple is visible
        // from the moment the user taps Enter — even during the
        // ~380ms window where the splash is still on top of the home
        // screen. Once the splash dismisses, the ripple continues
        // playing in front of the now-visible home until it fades.
        zIndex: 10001,
        // Critical: must NEVER intercept taps. The home screen lives
        // underneath and the user should be able to interact with it
        // the moment the splash hands off.
        pointerEvents: "none",
      }}
    >
      <canvas
        ref={canvasRef}
        style={{ display: "block", width: "100%", height: "100%" }}
      />
    </div>
  );
}

export default RippleOverlay;
