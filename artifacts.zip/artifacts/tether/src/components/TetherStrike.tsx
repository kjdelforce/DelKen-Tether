// ════════════════════════════════════════════════════════════
//  TetherStrike.tsx — Cross-device Liquid-Glass air hockey.
//  ─────────────────────────────────────────────────────────────
//  Each player holds their phone the same way, mallet at the
//  bottom. The two screens act as two views of one rally: when
//  the puck exits the TOP edge of Device A (struck forward by
//  player A) it re-enters the TOP edge of Device B travelling
//  DOWNWARD toward player B's mallet, at the same X position
//  and an inverted vy. Either player letting the puck escape
//  the BOTTOM of their own screen concedes a point.
//
//  Serves are stationary — the puck waits just above the
//  server's mallet until they swipe through it. The mallet's
//  recent velocity is folded into the collision so a fast
//  swipe imparts a hard hit, exactly like real air hockey.
//
//  Sync model
//  ──────────
//    • Single Supabase Realtime broadcast channel per tether,
//      `strike-${tether.id}`, used for:
//        - "join"   {role}                       — handshake
//        - "puck"   {x, vx, vy, score, ts}       — handoff packet
//        - "score"  {a, b}                       — authoritative
//        - "reset"  {servingTo: 'a'|'b'}         — round reset
//    • At any moment exactly ONE device is the puck OWNER (runs
//      physics). Ownership flips on handoff — i.e. when the puck
//      crosses the top edge of the current owner's screen.
//    • Payload contains only normalised scalars (x in [0,1] of
//      table width, vx/vy in table-units/second) so it's tiny —
//      4 floats per handoff. No frame-by-frame replication, so
//      WebSocket bandwidth is dominated by the score updates.
//    • The remote screen interpolates nothing for the puck (it
//      doesn't see the puck while the partner owns it). It sees
//      its OWN mallet via direct touch + spring, no network in
//      that loop, so latency for the controlling player is 0.
//
//  Roles are assigned by lexical comparison of profile.id so
//  both devices independently agree without a coin-toss round
//  trip: lower id → "a" (table top), higher id → "b" (bottom).
//  This affects nothing except the initial serve direction.
// ════════════════════════════════════════════════════════════
import { useEffect, useRef, useState, useCallback } from "react";
import { motion } from "framer-motion";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import { haptic } from "@/lib/haptics";
import { playSound } from "@/lib/audioManager";

// ── Tunables ──────────────────────────────────────────────
const PUCK_RADIUS_PX   = 34;   // visual size of the glass disc
const MALLET_RADIUS_PX = 56;   // visual size of the glass mallet
const PUCK_FRICTION    = 0.998;// per-frame velocity damping
// The puck starts the rally moving deliberately slowly — a gentle
// drift the receiver can read and react to. Each successful return
// (see SPEED_RAMP_PER_CROSS below) ramps the pace, so by the 6th or
// 7th exchange the rally is genuinely fast. The MIN floor exists
// only to stop a near-zero puck from stalling forever; it is set
// well below the typical opening serve so it doesn't override it.
const MIN_PUCK_SPEED   = 0.10; // table-units/sec — below this we boost
const MAX_PUCK_SPEED   = 2.4;  // hard cap for sanity
const MALLET_BOTTOM_PCT = 18;  // mallet's resting Y from screen bottom
// Mallet's resting X is parked on the FAR RIGHT (out of the way of
// the centred serve) so the player has to deliberately swipe in to
// strike the puck — no accidental tap-launch when the round starts.
const MALLET_REST_X     = 0.82;
const MALLET_REST_Y     = 1 - MALLET_BOTTOM_PCT / 100;

// Tracks how many times the puck has crossed devices in the
// current rally — used to escalate intensity. Combined with the
// slow opening serve this gives a clear "rally builds" arc:
//   crossing 1 → 1.10×, crossing 3 → 1.33×, crossing 6 → 1.77×.
const SPEED_RAMP_PER_CROSS = 1.10;

type Role = "a" | "b";

interface PuckPacket {
  x:  number;  // 0..1 of viewport width
  vx: number;  // viewport-widths per second
  vy: number;  // viewport-heights per second — POSITIVE = entering
               // partner's screen moving downward toward their mallet
  rally: number; // crossings so far this rally, for ramp
  ts: number;
}

interface ScorePacket { a: number; b: number; }
interface ResetPacket  { servingTo: Role; }

export function TetherStrike() {
  const { profile, partnerProfile, tether } = useAuth();

  // Deterministic role assignment without a network round-trip.
  const role: Role = (() => {
    if (!profile?.id || !partnerProfile?.id) return "a";
    return profile.id < partnerProfile.id ? "a" : "b";
  })();

  const [score,    setScore]    = useState<ScorePacket>({ a: 0, b: 0 });
  const [owns,     setOwns]     = useState<boolean>(role === "a");
  const [ready,    setReady]    = useState<boolean>(false);
  const [splash,   setSplash]   = useState<{ x: number; y: number; key: number } | null>(null);

  // Puck state — only meaningful while we own it. Mutable via ref
  // so the rAF loop doesn't re-render every frame. The serve sits
  // STATIONARY in the dead centre of the screen — right on the
  // midline, well clear of the mallet's bottom-right rest spot —
  // so it can never be hit by accident at the start of a round.
  // The server has to deliberately swipe their mallet up to it to
  // launch the rally (just like dropping the puck at centre ice).
  const SERVE_Y = 0.5;
  const puckRef = useRef({
    x:  0.5,
    y:  SERVE_Y,
    vx: 0,
    vy: 0,
    rally: 0,
  });
  const [puckTick, setPuckTick] = useState(0); // re-render trigger
  const lastFrameRef = useRef<number>(0);
  const rafRef       = useRef<number | null>(null);

  // Mallet state — controlled by touch on this device. We also
  // track the mallet's recent velocity so a real swipe transfers
  // force into the puck on contact (otherwise a stationary serve
  // could never be launched).
  const malletRef    = useRef({ x: MALLET_REST_X, y: MALLET_REST_Y });
  const malletVelRef = useRef({ x: 0, y: 0 });          // viewport-units / sec
  const lastMalletMoveRef = useRef({ x: MALLET_REST_X, y: MALLET_REST_Y, t: 0 });
  const [malletTick, setMalletTick] = useState(0);
  const prevPuckPos = useRef({ x: 0.5, y: 0.5 });

  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  // ── Channel setup ────────────────────────────────────────
  useEffect(() => {
    if (!tether?.id || !profile?.id) return;

    const ch = supabase
      .channel(`strike-${tether.id}`, {
        config: { broadcast: { ack: false, self: false } },
      })
      .on("broadcast", { event: "join" }, () => setReady(true))
      .on("broadcast", { event: "puck" }, ({ payload }) => {
        const p = payload as PuckPacket;
        // Partner just hit the puck off the top of their screen.
        // Both phones are held the same way (mallet at bottom),
        // so on our screen the puck must enter from the TOP edge
        // and travel DOWNWARD toward our mallet. The packet's vy
        // is already framed as "downward speed" by the sender, so
        // we use it as-is (just guard the sign).
        puckRef.current = {
          x:  p.x,
          y:  PUCK_RADIUS_PX / window.innerHeight,
          vx: p.vx,
          vy: Math.abs(p.vy),
          rally: p.rally,
        };
        setOwns(true);
        haptic("light");
      })
      .on("broadcast", { event: "score" }, ({ payload }) => {
        setScore(payload as ScorePacket);
        // Receiving a score broadcast means the *partner* just
        // conceded — i.e. WE scored. Celebrate locally only.
        playSound("tetherStrikeWin");
      })
      .on("broadcast", { event: "reset" }, ({ payload }) => {
        const r = payload as ResetPacket;
        const iServe = r.servingTo === role;
        if (iServe) {
          // Stationary serve waiting for the server's swipe.
          puckRef.current = {
            x: 0.5, y: SERVE_Y, vx: 0, vy: 0, rally: 0,
          };
          setOwns(true);
        } else {
          setOwns(false);
        }
      })
      .subscribe(status => {
        if (status === "SUBSCRIBED") {
          ch.send({ type: "broadcast", event: "join", payload: { role } });
          setReady(true);
        }
      });

    channelRef.current = ch;
    return () => {
      supabase.removeChannel(ch);
      channelRef.current = null;
    };
  }, [tether?.id, profile?.id, role]);

  // ── Physics loop (only runs while we own the puck) ────────
  useEffect(() => {
    if (!owns) {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
      return;
    }

    function step(ts: number) {
      const last = lastFrameRef.current || ts;
      const dt   = Math.min(0.05, (ts - last) / 1000); // clamp for tab-switch
      lastFrameRef.current = ts;

      const w = window.innerWidth;
      const h = window.innerHeight;
      const puck = puckRef.current;

      prevPuckPos.current = { x: puck.x, y: puck.y };

      // Integrate.
      puck.x += puck.vx * dt;
      puck.y += puck.vy * dt;

      // Friction + speed clamps.
      puck.vx *= PUCK_FRICTION;
      puck.vy *= PUCK_FRICTION;
      const speed = Math.hypot(puck.vx, puck.vy);
      if (speed > MAX_PUCK_SPEED) {
        const k = MAX_PUCK_SPEED / speed;
        puck.vx *= k; puck.vy *= k;
      } else if (speed < MIN_PUCK_SPEED && speed > 0.04) {
        // Only floor the speed for an in-flight puck. A truly
        // stationary serve (speed ≈ 0) must STAY put until the
        // server actually swipes through it.
        const k = MIN_PUCK_SPEED / speed;
        puck.vx *= k; puck.vy *= k;
      }

      // ── Wall bounce: left / right ────────────────────────
      const rxN = PUCK_RADIUS_PX / w;
      if (puck.x < rxN)         { puck.x = rxN;     puck.vx = Math.abs(puck.vx); fireSplash(puck.x, puck.y); }
      else if (puck.x > 1 - rxN){ puck.x = 1 - rxN; puck.vx = -Math.abs(puck.vx); fireSplash(puck.x, puck.y); }

      // ── Mallet collision (only ours can hit; we own puck) ──
      const mx = malletRef.current.x;
      const my = malletRef.current.y;
      const dxm = (puck.x - mx) * w;
      const dym = (puck.y - my) * h;
      const dist = Math.hypot(dxm, dym);
      const minDist = PUCK_RADIUS_PX + MALLET_RADIUS_PX;
      if (dist < minDist && dist > 0) {
        // Classic moving-paddle response: reflect the puck's
        // velocity *relative to the mallet* about the contact
        // normal, then add the mallet's velocity back. This way
        // a fast swipe transfers force into a stationary serve,
        // while in-flight pucks still bounce off a parked mallet.
        const nxN = dxm / dist;
        const nyN = dym / dist;
        const overlap = minDist - dist;
        puck.x += (nxN * overlap) / w;
        puck.y += (nyN * overlap) / h;

        // Use mallet velocity only if it's fresh (a recent move).
        const mvFresh = ts - lastMalletMoveRef.current.t < 90;
        const mvx = mvFresh ? malletVelRef.current.x : 0;
        const mvy = mvFresh ? malletVelRef.current.y : 0;

        const rvx = puck.vx - mvx;
        const rvy = puck.vy - mvy;
        const rvDotN = rvx * nxN + rvy * nyN;

        if (rvDotN < 0) {
          // Approaching — reflect relative velocity, re-add mallet.
          puck.vx = rvx - 2 * rvDotN * nxN + mvx;
          puck.vy = rvy - 2 * rvDotN * nyN + mvy;
        } else {
          // Stationary or separating — just shove the puck along
          // the mallet's motion (covers the serve-tap case). We
          // transfer ~40% of swipe velocity (down from 60%) so a
          // measured serve floats gently across rather than rocketing.
          puck.vx += mvx * 0.4;
          puck.vy += mvy * 0.4;
        }

        // Guarantee a minimum forward (upward) launch when the
        // mallet hits the puck from below — so even a gentle tap
        // serves the puck cleanly across to the partner. Set just
        // above MIN_PUCK_SPEED so the opening serve drifts rather
        // than zips; subsequent crossings will ramp it up.
        if (nyN < 0 && puck.vy > -0.18) {
          puck.vy = -0.22;
        }

        haptic("medium");
        // Soft glass clink on every mallet/puck contact.
        playSound("tetherStrikeHit");
      }

      // ── Top-edge handoff ────────────────────────────────
      const ryN = PUCK_RADIUS_PX / h;
      if (puck.y < -ryN) {
        puck.rally += 1;
        // Speed escalation per spec: +5% each crossing.
        puck.vx *= SPEED_RAMP_PER_CROSS;
        puck.vy *= SPEED_RAMP_PER_CROSS;
        channelRef.current?.send({
          type: "broadcast",
          event: "puck",
          payload: {
            x:  puck.x,
            vx: puck.vx,
            // Flip vy so the receiver gets a positive "downward
            // entry speed" — on their screen the puck spawns at
            // the top edge and drives down toward their mallet.
            vy: Math.abs(puck.vy),
            rally: puck.rally,
            ts: performance.now(),
          } satisfies PuckPacket,
        });
        setOwns(false);
        return; // stop loop; the !owns branch will cancel the RAF
      }

      // ── Bottom-edge: opponent scores ────────────────────
      if (puck.y > 1 + ryN) {
        const next = role === "a"
          ? { a: score.a, b: score.b + 1 }
          : { a: score.a + 1, b: score.b };
        setScore(next);
        channelRef.current?.send({ type: "broadcast", event: "score", payload: next });
        // Loser serves next round (so they get the puck back).
        const servingTo: Role = role;
        channelRef.current?.send({ type: "broadcast", event: "reset", payload: { servingTo } satisfies ResetPacket });
        // Stationary serve waiting on our mallet swipe.
        puckRef.current = { x: 0.5, y: SERVE_Y, vx: 0, vy: 0, rally: 0 };
        haptic("heartbeat");
        // Bottom-edge fired locally → THIS device just conceded.
        // Soft loss cue plays here only (the winner gets their cue
        // via the score broadcast handler above).
        playSound("tetherStrikeLose");
        // We still own the puck (loser serves next round), so we
        // must KEEP the physics loop running — otherwise the
        // freshly-reset stationary serve would never get a chance
        // to be struck. (Channel is self:false so our own `reset`
        // broadcast can't be relied on to re-arm the loop.)
        setPuckTick(t => (t + 1) & 0xffff);
        rafRef.current = requestAnimationFrame(step);
        return;
      }

      setPuckTick(t => (t + 1) & 0xffff);
      rafRef.current = requestAnimationFrame(step);
    }

    rafRef.current = requestAnimationFrame(step);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
      lastFrameRef.current = 0;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [owns]);

  // ── Touch / pointer drag for our mallet ────────────────────
  const onPointerMove = useCallback((e: React.PointerEvent) => {
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const xRaw = (e.clientX - rect.left) / rect.width;
    const yRaw = (e.clientY - rect.top)  / rect.height;
    // Constrain mallet to the lower 55% of its own screen so it
    // can't reach into the partner's territory.
    const x = Math.max(MALLET_RADIUS_PX / window.innerWidth,
                       Math.min(1 - MALLET_RADIUS_PX / window.innerWidth, xRaw));
    const y = Math.max(0.45,
                       Math.min(1 - MALLET_RADIUS_PX / window.innerHeight, yRaw));

    // Track mallet velocity (viewport-units / sec) so the physics
    // step can fold a real swipe into the puck's collision response.
    // Skip the sample if the gap since the last move is too long
    // (e.g. the user lifted and re-touched) to avoid a spurious
    // huge velocity spike.
    const now = performance.now();
    const last = lastMalletMoveRef.current;
    const dtMs = now - last.t;
    if (last.t > 0 && dtMs > 0 && dtMs < 80) {
      const inst = {
        x: (x - last.x) * 1000 / dtMs,
        y: (y - last.y) * 1000 / dtMs,
      };
      // Light EMA smoothing so a single jitter sample doesn't
      // dominate the imparted force.
      const a = 0.55;
      malletVelRef.current = {
        x: a * inst.x + (1 - a) * malletVelRef.current.x,
        y: a * inst.y + (1 - a) * malletVelRef.current.y,
      };
    } else {
      malletVelRef.current = { x: 0, y: 0 };
    }
    lastMalletMoveRef.current = { x, y, t: now };

    malletRef.current = { x, y };
    setMalletTick(t => (t + 1) & 0xffff);
  }, []);

  // Helper: fire a splash visual at a normalised coord.
  function fireSplash(xN: number, yN: number) {
    setSplash({ x: xN, y: yN, key: performance.now() });
    haptic("light");
  }

  // ── Rendering ──────────────────────────────────────────────
  const w = typeof window === "undefined" ? 400 : window.innerWidth;
  const h = typeof window === "undefined" ? 800 : window.innerHeight;
  const puckPxX = puckRef.current.x * w;
  const puckPxY = puckRef.current.y * h;
  const malletPxX = malletRef.current.x * w;
  const malletPxY = malletRef.current.y * h;
  // Suppress unused-tick warnings — the ticks are state purely so
  // React re-renders; their values are intentionally unused.
  void puckTick; void malletTick;

  return (
    <div
      className="ts-stage"
      onPointerDown={onPointerMove}
      onPointerMove={onPointerMove}
    >
      {/* Floating glass score counter ─────────────────── */}
      <div className="ts-score">
        <span className={`ts-score-cell ${role === "a" ? "me" : ""}`}>{score.a}</span>
        <span className="ts-score-sep">·</span>
        <span className={`ts-score-cell ${role === "b" ? "me" : ""}`}>{score.b}</span>
      </div>

      {/* Centre-line marker so the player can see their goal-line */}
      <div className="ts-midline" />

      {/* Puck trail — 4 lagged ghosts that fade out */}
      {owns && Array.from({ length: 4 }).map((_, i) => {
        const lag = (i + 1) * 0.018;
        return (
          <div
            key={`trail-${i}`}
            className="ts-puck-trail"
            style={{
              transform: `translate(${puckPxX - puckRef.current.vx * lag * w - PUCK_RADIUS_PX}px, ${puckPxY - puckRef.current.vy * lag * h - PUCK_RADIUS_PX}px)`,
              opacity: 0.35 - i * 0.07,
              width:  PUCK_RADIUS_PX * 2,
              height: PUCK_RADIUS_PX * 2,
            }}
          />
        );
      })}

      {/* Puck — refractive glass disc, only when we own it */}
      {owns && (
        <div
          className="ts-puck"
          style={{
            transform: `translate(${puckPxX - PUCK_RADIUS_PX}px, ${puckPxY - PUCK_RADIUS_PX}px)`,
            width:  PUCK_RADIUS_PX * 2,
            height: PUCK_RADIUS_PX * 2,
          }}
        />
      )}

      {/* Liquid splash on edge collisions */}
      {splash && (
        <motion.div
          key={splash.key}
          className="ts-splash"
          initial={{ scale: 0.4, opacity: 0.9 }}
          animate={{ scale: 2.2, opacity: 0 }}
          transition={{ duration: 0.55, ease: "easeOut" }}
          onAnimationComplete={() => setSplash(null)}
          style={{
            left: splash.x * w,
            top:  splash.y * h,
          }}
        />
      )}

      {/* Mallet — heavy spring-driven glass disc */}
      <motion.div
        className="ts-mallet"
        animate={{
          x: malletPxX - MALLET_RADIUS_PX,
          y: malletPxY - MALLET_RADIUS_PX,
        }}
        transition={{ type: "spring", stiffness: 480, damping: 32, mass: 1.1 }}
        style={{ width: MALLET_RADIUS_PX * 2, height: MALLET_RADIUS_PX * 2 }}
      />

      {!ready && (
        <div className="ts-lobby">
          <div className="ts-lobby-orb" />
          <div className="ts-lobby-text">Connecting to your partner…</div>
        </div>
      )}
    </div>
  );
}

export default TetherStrike;
