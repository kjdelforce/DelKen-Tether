// ════════════════════════════════════════════════════════════
//  BeachShoreline.tsx — Cinematic tidal shoreline.
//  ─────────────────────────────────────────────────────────────
//  Activates only when the Beach theme is on. Layers three
//  SVG waves (deep cerulean / turquoise / blurred white foam)
//  whose `d` attributes are morphed by framer-motion through a
//  set of hand-tuned keyframe profiles, so the crests don't
//  just slide but actually swell and break.
//
//  Adds a wet-sand pulse on the mesh below (saturation bumped
//  briefly when the foam peaks), foam-bubble particles at the
//  crest, a specular highlight line for sun glint, and an
//  optional gyroscope parallax that shifts the whole stack
//  with the device tilt for a "fish-tank" depth feel.
//
//  All motion is GPU-composited; the component unmounts cleanly
//  when the theme switches away.
// ════════════════════════════════════════════════════════════
import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { THEME_CHANGE_EVENT } from "@/lib/themes";

// ── Wave profile keyframes ───────────────────────────────────
// Each "d" string traces the crest from x=0 to x=1440 then
// drops to the SVG floor (240). Three profiles per layer let
// framer-motion morph between them, producing the "swell &
// break" cycle. Paths share the same number of segments so
// the morph is smooth — mismatched segment counts cause
// flicker.
const WAVE_BACK_FRAMES = [
  "M0,170 C220,140 380,200 600,160 C840,120 980,190 1200,150 C1320,130 1400,165 1440,158 L1440,240 L0,240 Z",
  "M0,160 C220,200 380,140 600,180 C840,210 980,140 1200,170 C1320,190 1400,150 1440,165 L1440,240 L0,240 Z",
  "M0,175 C220,155 380,210 600,150 C840,115 980,200 1200,140 C1320,125 1400,170 1440,150 L1440,240 L0,240 Z",
];
const WAVE_MID_FRAMES = [
  "M0,190 C200,160 380,220 620,185 C860,150 1020,210 1260,170 C1360,150 1420,180 1440,175 L1440,240 L0,240 Z",
  "M0,180 C200,215 380,170 620,200 C860,225 1020,170 1260,195 C1360,210 1420,180 1440,190 L1440,240 L0,240 Z",
  "M0,195 C200,170 380,225 620,180 C860,140 1020,220 1260,165 C1360,145 1420,190 1440,170 L1440,240 L0,240 Z",
];
const WAVE_FOAM_FRAMES = [
  "M0,205 C240,180 400,225 640,200 C880,180 1040,220 1280,195 C1380,180 1430,205 1440,200 L1440,240 L0,240 Z",
  "M0,195 C240,225 400,180 640,215 C880,235 1040,180 1280,215 C1380,225 1430,200 1440,210 L1440,240 L0,240 Z",
  "M0,210 C240,190 400,230 640,195 C880,170 1040,225 1280,180 C1380,170 1430,210 1440,185 L1440,240 L0,240 Z",
];

// One full cycle (back-and-forth-and-back) in seconds. Different
// per layer so the three crests never visibly resync.
const CYCLE_BACK = 9;
const CYCLE_MID  = 6.5;
const CYCLE_FOAM = 4.8;

export function BeachShoreline() {
  const [active, setActive] = useState<boolean>(() => {
    if (typeof document === "undefined") return false;
    return document.body.dataset.tetherTheme === "beach";
  });
  const tiltRef = useRef({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Re-evaluate active state on every theme change.
  useEffect(() => {
    const onTheme = (e: Event) => {
      const key = (e as CustomEvent<string>).detail;
      setActive(key === "beach");
    };
    window.addEventListener(THEME_CHANGE_EVENT, onTheme);
    return () => window.removeEventListener(THEME_CHANGE_EVENT, onTheme);
  }, []);

  // ── Gyroscope parallax ─────────────────────────────────────
  // DeviceOrientation gamma = device's left-right tilt (-90..90),
  // beta = front-back tilt (-180..180). We clamp + scale to a
  // few px of translation so the waves "swim" inside the phone.
  // iOS Safari requires explicit permission via a user gesture
  // (DeviceOrientationEvent.requestPermission). We try it once
  // on first pointerdown after the layer becomes active.
  useEffect(() => {
    if (!active || typeof window === "undefined") return;
    let raf = 0;

    const onOrient = (e: DeviceOrientationEvent) => {
      const gamma = (e.gamma ?? 0); // -90..90
      const beta  = (e.beta  ?? 0); // -180..180
      // Clamp aggressively + scale so 30° tilt = ~12px shift.
      tiltRef.current.x = Math.max(-12, Math.min(12, (gamma / 30) * 12));
      tiltRef.current.y = Math.max( -6, Math.min( 6, ((beta - 30) / 30) * 6));
    };
    window.addEventListener("deviceorientation", onOrient);

    // Apply tilt on a smoothing RAF so jittery sensor noise
    // doesn't translate into visible jitter on the waves.
    let curX = 0, curY = 0;
    const apply = () => {
      curX += (tiltRef.current.x - curX) * 0.08;
      curY += (tiltRef.current.y - curY) * 0.08;
      const el = containerRef.current;
      if (el) el.style.transform = `translate3d(${curX.toFixed(2)}px, ${curY.toFixed(2)}px, 0)`;
      raf = requestAnimationFrame(apply);
    };
    raf = requestAnimationFrame(apply);

    // iOS 13+ permission request — only fires after a user tap.
    const tryRequestPermission = async () => {
      type PermFn = () => Promise<"granted" | "denied">;
      const dev = (window as unknown as {
        DeviceOrientationEvent?: { requestPermission?: PermFn };
      }).DeviceOrientationEvent;
      if (dev?.requestPermission) {
        try { await dev.requestPermission(); } catch { /* user denied */ }
      }
      window.removeEventListener("pointerdown", tryRequestPermission);
    };
    window.addEventListener("pointerdown", tryRequestPermission, { once: true });

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("deviceorientation", onOrient);
      window.removeEventListener("pointerdown", tryRequestPermission);
    };
  }, [active]);

  // ── Wet-sand pulse on the mesh ─────────────────────────────
  // Every CYCLE_FOAM seconds the foam peaks; we toggle a body
  // class for ~700ms so the mesh gets a brief saturation+
  // brightness bump (defined in CSS). Reads as the sand looking
  // darker/wetter where the wave just washed.
  useEffect(() => {
    if (!active) return;
    const id = window.setInterval(() => {
      document.body.classList.add("beach-wet-sand");
      window.setTimeout(() => document.body.classList.remove("beach-wet-sand"), 700);
    }, CYCLE_FOAM * 1000);
    return () => {
      window.clearInterval(id);
      document.body.classList.remove("beach-wet-sand");
    };
  }, [active]);

  if (!active) return null;

  return (
    <div ref={containerRef} className="beach-shoreline" aria-hidden="true">
      <svg
        className="beach-waves"
        viewBox="0 0 1440 240"
        preserveAspectRatio="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Cerulean back layer — deep ocean tone. */}
          <linearGradient id="beach-back" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%"   stopColor="rgba(40,110,180,0.45)" />
            <stop offset="100%" stopColor="rgba(15,60,130,0.75)" />
          </linearGradient>
          {/* Turquoise middle — shallow tropical water. */}
          <linearGradient id="beach-mid" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%"   stopColor="rgba(80,210,220,0.55)" />
            <stop offset="100%" stopColor="rgba(20,140,180,0.80)" />
          </linearGradient>
          {/* Foam — near-white surf. */}
          <linearGradient id="beach-foam" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%"   stopColor="rgba(255,255,255,0.92)" />
            <stop offset="100%" stopColor="rgba(220,240,250,0.55)" />
          </linearGradient>
        </defs>

        {/* Back wave — slow, deep, low opacity. */}
        <motion.path
          fill="url(#beach-back)"
          opacity={0.55}
          initial={{ d: WAVE_BACK_FRAMES[0] }}
          animate={{ d: WAVE_BACK_FRAMES }}
          transition={{ duration: CYCLE_BACK, repeat: Infinity, ease: "easeInOut" }}
        />

        {/* Middle wave — medium speed turquoise. */}
        <motion.path
          fill="url(#beach-mid)"
          opacity={0.78}
          initial={{ d: WAVE_MID_FRAMES[0] }}
          animate={{ d: WAVE_MID_FRAMES }}
          transition={{ duration: CYCLE_MID, repeat: Infinity, ease: "easeInOut" }}
        />

        {/* Foam wave — fastest, blurred for sea-spray feel. */}
        <motion.path
          className="beach-wave-foam"
          fill="url(#beach-foam)"
          initial={{ d: WAVE_FOAM_FRAMES[0] }}
          animate={{ d: WAVE_FOAM_FRAMES }}
          transition={{ duration: CYCLE_FOAM, repeat: Infinity, ease: "easeInOut" }}
        />

        {/* Specular highlight — thin white glint riding the foam
            crest like sunlight reflecting off the wave top. Uses
            `pathLength` trick: a stroked open path with dasharray
            animated to look like a moving sparkle line. */}
        <motion.path
          className="beach-specular"
          fill="none"
          stroke="rgba(255,255,255,0.9)"
          strokeWidth={1.4}
          strokeLinecap="round"
          initial={{ d: WAVE_FOAM_FRAMES[0].split(" L1440,240")[0] }}
          animate={{ d: WAVE_FOAM_FRAMES.map((p) => p.split(" L1440,240")[0]) }}
          transition={{ duration: CYCLE_FOAM, repeat: Infinity, ease: "easeInOut" }}
        />
      </svg>

      {/* Foam bubbles — small particles spawned at wave crests
          that rise briefly and dissolve. Pure CSS keyframes so
          they cost effectively nothing. */}
      <FoamBubbles />
    </div>
  );
}

// ── Foam bubble particles ───────────────────────────────────
function FoamBubbles() {
  // Stable randomised positions so React doesn't reshuffle on
  // every render. 18 bubbles is enough density without crowding.
  const bubbles = useRef(
    Array.from({ length: 18 }, (_, i) => ({
      id:    i,
      left:  Math.random() * 100,         // % across the screen
      size:  3 + Math.random() * 5,       // px
      delay: Math.random() * 4.8,         // s — staggers across the cycle
      drift: -8 + Math.random() * 16,     // px horizontal drift
    })),
  ).current;

  return (
    <div className="beach-bubbles">
      {bubbles.map((b) => (
        <span
          key={b.id}
          className="beach-bubble"
          style={{
            left:                  `${b.left}%`,
            width:                 `${b.size}px`,
            height:                `${b.size}px`,
            animationDelay:        `${b.delay}s`,
            ["--drift" as string]: `${b.drift}px`,
          }}
        />
      ))}
    </div>
  );
}

export default BeachShoreline;
