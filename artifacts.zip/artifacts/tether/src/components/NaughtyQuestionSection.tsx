import React, { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { supabase } from "@/lib/supabaseClient";
import { useToast } from "@/hooks/use-toast";
import { haptic } from "@/lib/haptics";
import {
  isKyle,
  postNaughtyQuestion,
  getActiveNaughtyQuestion,
  getNaughtyAnswers,
  submitNaughtyAnswer,
  timeRemaining,
  type NaughtyQuestion,
  type NaughtyAnswer,
} from "@/lib/naughtyBox";

/**
 * Naughty Question section — extracted verbatim from HomePage so it
 * can be reused inside the Games Hub's combined "Daily Connection"
 * game (Connection / Naughty mode toggle). All logic, queries,
 * realtime subscription, FaceID-style privacy veil, and Kyle's
 * compose UI are preserved exactly as they were on Home.
 */
export function NaughtyQuestionSection({
  tetherId, myId, myName, partnerId, partnerName,
}: {
  tetherId: string; myId: string; myName: string;
  partnerId: string | null; partnerName: string;
}) {
  const { toast } = useToast();
  const amKyle = isKyle(myName);

  const [question,   setQuestion]   = useState<NaughtyQuestion | null | undefined>(undefined);
  const [answers,    setAnswers]    = useState<NaughtyAnswer[]>([]);
  const [myAnswer,   setMyAnswer]   = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [composing,  setComposing]  = useState(false);
  const [newQ,       setNewQ]       = useState("");
  const [posting,    setPosting]    = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [timeLeft,   setTimeLeft]   = useState("");
  const [revealed,   setRevealed]   = useState(false);

  const reload = useCallback(async () => {
    const q = await getActiveNaughtyQuestion(tetherId);
    setQuestion(q ?? null);
    if (q) {
      const ans = await getNaughtyAnswers(q.id);
      setAnswers(ans);
    } else {
      setAnswers([]);
    }
  }, [tetherId]);

  useEffect(() => { reload(); }, [reload]);

  // Live countdown timer
  useEffect(() => {
    if (!question) { setTimeLeft(""); return; }
    const tick = () => setTimeLeft(timeRemaining(question.expires_at));
    tick();
    timerRef.current = setInterval(tick, 30_000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [question]);

  // Realtime: new answers from partner
  useEffect(() => {
    if (!question) return;
    const ch = supabase
      .channel("naughty-answers-" + question.id)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "naughty_answers",
          filter: `question_id=eq.${question.id}` },
        () => { reload(); },
      ).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [question?.id, reload]);

  async function handlePost() {
    if (!newQ.trim()) return;
    setPosting(true);
    const { data: q, error } = await postNaughtyQuestion(tetherId, myId, newQ.trim());
    setPosting(false);
    if (q) { setQuestion(q); setAnswers([]); setComposing(false); setNewQ(""); haptic("success"); }
    else toast({ title: "Failed to post question", description: error ?? "Unknown error. Run the Naughty Questions migration in Supabase.", variant: "destructive" });
  }

  async function handleSubmitAnswer() {
    if (!question || !myAnswer.trim()) return;
    setSubmitting(true);
    const { error } = await submitNaughtyAnswer(question.id, tetherId, myId, myAnswer.trim());
    setSubmitting(false);
    if (error) { toast({ title: "Error", description: error, variant: "destructive" }); return; }
    haptic("success");
    setMyAnswer("");
    reload();
  }

  const myAnswerRow      = answers.find(a => a.user_id === myId);
  const partnerAnswerRow = partnerId ? answers.find(a => a.user_id === partnerId) : null;
  const bothAnswered     = !!myAnswerRow && !!partnerAnswerRow;

  const SPICY_CARD: React.CSSProperties = {
    background: "linear-gradient(135deg, rgba(197,48,48,0.12) 0%, rgba(10,10,20,0.82) 100%)",
    backdropFilter: "blur(28px) saturate(165%)",
    WebkitBackdropFilter: "blur(28px) saturate(165%)",
    border: "1px solid rgba(255,255,255,0.18)",
    borderRadius: 20,
    boxShadow: [
      "0 8px 32px rgba(0,0,0,0.50)",
      "0 0 30px 6px rgba(197,48,48,0.28)",
      "inset 0 1.5px 0 rgba(255,200,200,0.40)",
      "inset 0 -1px 0 rgba(0,0,0,0.25)",
      "inset 1px 0 0 rgba(197,48,48,0.20)",
      "inset -1px 0 0 rgba(197,48,48,0.20)",
    ].join(", "),
    padding: "22px 24px",
    position: "relative",
    overflow: "hidden",
  };

  const inputStyle: React.CSSProperties = {
    width: "100%",
    background: "rgba(255,255,255,0.07)",
    border: "1px solid rgba(197,48,48,0.35)",
    borderRadius: 12,
    color: "white",
    fontSize: "0.88rem",
    padding: "10px 12px",
    fontFamily: "'Quicksand', sans-serif",
    outline: "none",
    boxSizing: "border-box",
  };

  if (question === undefined) return null;

  return (
    <div style={SPICY_CARD}>
      {/* FaceID-style privacy overlay — tap to reveal */}
      <AnimatePresence>
        {!revealed && (
          <motion.div
            key="naughty-privacy-veil"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
            onClick={() => { haptic("light"); setRevealed(true); }}
            style={{
              position: "absolute",
              inset: 0,
              zIndex: 10,
              borderRadius: 20,
              backdropFilter: "blur(20px) saturate(120%)",
              WebkitBackdropFilter: "blur(20px) saturate(120%)",
              background: "rgba(8,4,4,0.45)",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
              cursor: "pointer",
            }}
          >
            <span style={{ fontSize: "1.8rem" }}>🔒</span>
            <p style={{
              fontFamily: "'Quicksand', sans-serif",
              fontSize: "0.72rem",
              fontWeight: 700,
              color: "rgba(255,200,200,0.80)",
              letterSpacing: "0.10em",
              textTransform: "uppercase",
              margin: 0,
            }}>
              Tap to Reveal
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
          <span style={{ fontSize: "1.1rem" }}>🔥</span>
          <span style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: "0.82rem",
            fontWeight: 700,
            color: "rgba(255,120,120,0.95)",
            letterSpacing: "0.07em",
            textTransform: "uppercase",
          }}>
            Naughty Question
          </span>
        </div>
        {amKyle && !composing && (
          <motion.button
            whileTap={{ scale: 0.88 }}
            onClick={() => { haptic("light"); setComposing(true); }}
            style={{
              background: "rgba(197,48,48,0.28)",
              border: "1px solid rgba(197,48,48,0.55)",
              borderRadius: 10,
              color: "rgba(255,150,150,0.95)",
              fontWeight: 700,
              fontSize: "1.1rem",
              width: 32,
              height: 32,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
            }}
          >
            +
          </motion.button>
        )}
      </div>

      <AnimatePresence>
        {composing && (
          <motion.div
            initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }} style={{ overflow: "hidden", marginBottom: 12 }}
          >
            <div style={{ display: "flex", gap: 8 }}>
              <input
                value={newQ}
                onChange={e => setNewQ(e.target.value)}
                style={{ ...inputStyle, flex: 1 }}
                placeholder="Ask anything… 😈"
                autoFocus
                onKeyDown={e => { if (e.key === "Enter") handlePost(); }}
              />
              <motion.button
                whileTap={{ scale: 0.92 }}
                onClick={handlePost}
                disabled={posting || !newQ.trim()}
                style={{
                  background: "linear-gradient(135deg, #C53030, #7B1313)",
                  border: "none", borderRadius: 10, color: "white",
                  fontSize: "0.8rem", fontWeight: 700, padding: "0 14px",
                  cursor: "pointer", flexShrink: 0,
                  opacity: (!newQ.trim() || posting) ? 0.5 : 1,
                }}
              >
                {posting ? "…" : "Post"}
              </motion.button>
              <motion.button
                whileTap={{ scale: 0.92 }}
                onClick={() => { setComposing(false); setNewQ(""); }}
                style={{ background: "none", border: "none", color: "rgba(255,255,255,0.40)", fontSize: "1.2rem", cursor: "pointer" }}
              >
                ×
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {!question && !composing && (
        <p style={{ color: "rgba(255,255,255,0.30)", fontStyle: "italic", fontSize: "0.85rem", textAlign: "center", paddingTop: 4 }}>
          {amKyle ? "Tap + to post a naughty question for you both…" : "No naughty question right now — check back soon 😈"}
        </p>
      )}

      {question && (
        <div>
          <div style={{
            background: "rgba(197,48,48,0.12)",
            borderRadius: 14,
            padding: "12px 14px",
            marginBottom: 12,
          }}>
            <p style={{
              fontFamily: "'Caveat', cursive",
              fontSize: "1.20rem",
              color: "white",
              margin: 0,
              lineHeight: 1.4,
            }}
            data-user-content
            >
              "{question.question_text}"
            </p>
            <p style={{ fontSize: "0.68rem", color: "rgba(255,140,140,0.55)", marginTop: 6, letterSpacing: "0.05em" }}>
              ⏳ {timeLeft}
            </p>
          </div>

          {bothAnswered ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              style={{ display: "flex", flexDirection: "column", gap: 8 }}
            >
              {[myAnswerRow, partnerAnswerRow].filter(Boolean).map(a => {
                const isMe = a!.user_id === myId;
                const name = isMe ? myName : partnerName;
                return (
                  <div key={a!.id} style={{
                    background: isMe ? "rgba(197,48,48,0.14)" : "rgba(255,255,255,0.06)",
                    border: `1px solid ${isMe ? "rgba(197,48,48,0.35)" : "rgba(255,255,255,0.10)"}`,
                    borderRadius: 12,
                    padding: "10px 13px",
                  }}>
                    <p style={{ fontSize: "0.68rem", color: "rgba(255,200,200,0.55)", marginBottom: 3, fontWeight: 600 }}>
                      {name}
                    </p>
                    <p data-user-content style={{ color: "rgba(255,255,255,0.88)", fontSize: "0.88rem", fontFamily: "'Quicksand', sans-serif", margin: 0 }}>
                      {a!.answer_text}
                    </p>
                  </div>
                );
              })}
            </motion.div>
          ) : (
            <div>
              {!myAnswerRow ? (
                <div style={{ display: "flex", gap: 8 }}>
                  <input
                    value={myAnswer}
                    onChange={e => setMyAnswer(e.target.value)}
                    style={{ ...inputStyle, flex: 1 }}
                    placeholder="Your answer…"
                    onKeyDown={e => { if (e.key === "Enter") handleSubmitAnswer(); }}
                  />
                  <motion.button
                    whileTap={{ scale: 0.92 }}
                    onClick={handleSubmitAnswer}
                    disabled={submitting || !myAnswer.trim()}
                    style={{
                      background: "linear-gradient(135deg, #C53030, #7B1313)",
                      border: "none", borderRadius: 10, color: "white",
                      fontSize: "0.8rem", fontWeight: 700, padding: "0 14px",
                      cursor: "pointer", flexShrink: 0,
                      opacity: (!myAnswer.trim() || submitting) ? 0.5 : 1,
                    }}
                  >
                    {submitting ? "…" : "Send"}
                  </motion.button>
                </div>
              ) : (
                <div style={{
                  background: "rgba(197,48,48,0.12)",
                  borderRadius: 12,
                  padding: "10px 13px",
                }}>
                  <p style={{ fontSize: "0.70rem", color: "rgba(255,200,200,0.55)", marginBottom: 3 }}>Your answer ✓</p>
                  <p data-user-content style={{ color: "rgba(255,255,255,0.80)", fontSize: "0.88rem", margin: 0, fontFamily: "'Quicksand', sans-serif" }}>
                    {myAnswerRow.answer_text}
                  </p>
                </div>
              )}
              {myAnswerRow && !partnerAnswerRow && (
                <p style={{ fontSize: "0.72rem", color: "rgba(255,200,200,0.45)", marginTop: 8, textAlign: "center", fontStyle: "italic" }}>
                  Waiting for {partnerName} to answer…
                </p>
              )}
              {!myAnswerRow && partnerAnswerRow && (
                <p style={{ fontSize: "0.72rem", color: "rgba(255,200,200,0.45)", marginTop: 8, textAlign: "center", fontStyle: "italic" }}>
                  {partnerName} answered — reply to see theirs 🔒
                </p>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
