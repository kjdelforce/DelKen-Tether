import { motion } from "framer-motion";
import { supabase } from "@/lib/supabaseClient";

const LS_KEY = "tether-age-verified";

interface AgeGateProps {
  profileId: string | null;
  onVerified: () => void;
}

export function AgeGate({ profileId, onVerified }: AgeGateProps) {
  async function handleConfirm() {
    try { localStorage.setItem(LS_KEY, "true"); } catch { /* ignore */ }
    if (profileId) {
      void supabase
        .from("profiles")
        .update({ age_verified: true })
        .eq("id", profileId);
    }
    onVerified();
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      style={{
        position:            "fixed",
        inset:               0,
        zIndex:              9998,
        display:             "flex",
        alignItems:          "center",
        justifyContent:      "center",
        background:          "rgba(0,0,0,0.97)",
        backdropFilter:      "blur(24px)",
        WebkitBackdropFilter:"blur(24px)",
        padding:             "24px",
        textAlign:           "center",
      }}
    >
      {/* Ambient purple glow */}
      <div
        aria-hidden="true"
        style={{
          position:      "absolute",
          inset:         0,
          pointerEvents: "none",
          background:    "radial-gradient(ellipse 70% 55% at 50% 35%, rgba(107,33,168,0.22) 0%, transparent 70%)",
        }}
      />

      <motion.div
        initial={{ scale: 0.92, y: 28, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        transition={{ delay: 0.08, type: "spring", stiffness: 260, damping: 22 }}
        style={{
          position:            "relative",
          width:               "100%",
          maxWidth:            360,
          padding:             "40px 28px 36px",
          borderRadius:        32,
          background:          "rgba(255,255,255,0.035)",
          backdropFilter:      "blur(40px)",
          WebkitBackdropFilter:"blur(40px)",
          border:              "1px solid rgba(255,255,255,0.10)",
          boxShadow:           "0 0 80px rgba(107,33,168,0.18), 0 32px 80px rgba(0,0,0,0.65)",
        }}
      >
        {/* 17+ badge */}
        <div
          style={{
            width:           64,
            height:          64,
            borderRadius:    "50%",
            border:          "2px solid rgba(197,48,48,0.55)",
            display:         "flex",
            alignItems:      "center",
            justifyContent:  "center",
            margin:          "0 auto 28px",
            background:      "rgba(197,48,48,0.07)",
          }}
        >
          <span
            style={{
              fontFamily: "'Playfair Display', serif",
              fontWeight:  700,
              fontSize:   "1.15rem",
              color:       "#EF4444",
            }}
          >
            17+
          </span>
        </div>

        {/* Heading */}
        <h2
          style={{
            fontFamily:    "'Playfair Display', serif",
            fontWeight:     400,
            fontSize:      "1.65rem",
            color:          "white",
            margin:         "0 0 16px",
            letterSpacing: "-0.02em",
            lineHeight:     1.2,
          }}
        >
          Age Verification
        </h2>

        {/* Body */}
        <p
          style={{
            fontFamily:  "'Quicksand', sans-serif",
            color:        "rgba(180,196,240,0.78)",
            fontSize:    "0.875rem",
            lineHeight:   1.7,
            margin:       "0 0 32px",
          }}
        >
          Tether is a private space designed for adult intimacy and connection.
          By continuing, you confirm that you are at least 17 years of age and
          agree to our Terms of Service.
        </p>

        {/* Buttons */}
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <motion.button
            whileTap={{ scale: 0.96 }}
            onClick={handleConfirm}
            style={{
              width:       "100%",
              padding:     "16px",
              borderRadius: 18,
              background:  "linear-gradient(135deg, rgba(255,255,255,0.93) 0%, rgba(225,230,255,0.93) 100%)",
              border:       "none",
              color:        "#0a0a14",
              fontFamily:  "'Playfair Display', serif",
              fontSize:    "1rem",
              fontWeight:   700,
              cursor:       "pointer",
            }}
          >
            I am 17 or older
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.96 }}
            onClick={() => { window.location.href = "https://www.google.com"; }}
            style={{
              width:       "100%",
              padding:     "12px",
              borderRadius: 18,
              background:   "none",
              border:        "none",
              color:        "rgba(180,196,240,0.40)",
              fontFamily:  "'Quicksand', sans-serif",
              fontSize:    "0.875rem",
              cursor:       "pointer",
            }}
          >
            Exit
          </motion.button>
        </div>

        {/* Footer caption */}
        <p
          style={{
            marginTop:     24,
            fontSize:     "0.6rem",
            color:        "rgba(255,255,255,0.18)",
            textTransform: "uppercase",
            letterSpacing: "0.14em",
            fontFamily:   "'Quicksand', sans-serif",
          }}
        >
          Private · Secure · Encrypted
        </p>
      </motion.div>
    </motion.div>
  );
}
