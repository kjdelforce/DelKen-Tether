import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/lib/AuthContext";
import { haptic } from "@/lib/haptics";
import { DailyConnectionCard } from "@/components/DailyConnectionCard";
import { NaughtyQuestionSection } from "@/components/NaughtyQuestionSection";

/**
 * Combined "Daily Connection" game launched from the Games Hub.
 *
 * Replaces the two separate Home-page sections (DailyConnectionCard
 * and NaughtyQuestionSection) with a single screen that toggles
 * between Connection mode (the original daily question card) and
 * Naughty mode (the spicy question/answer flow), preserving every
 * piece of underlying logic.
 *
 * Mode is local React state — nothing persisted. Defaults to
 * Connection on each launch.
 */
type Mode = "connection" | "naughty";

export function DailyConnectionGame() {
  const { profile, partnerProfile, tether } = useAuth();
  const [mode, setMode] = useState<Mode>("connection");

  // Auth not ready yet (rare — Games Hub gates behind auth) — render
  // an empty stage to avoid flashing broken state.
  if (!profile || !tether) {
    return (
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <p style={{ color: "rgba(255,255,255,0.4)", fontFamily: "'Quicksand', sans-serif" }}>
          Loading…
        </p>
      </div>
    );
  }

  const partnerName = partnerProfile?.full_name?.split(" ")[0] ?? "your partner";

  return (
    <div style={{
      flex: 1,
      display: "flex",
      flexDirection: "column",
      gap: 18,
      padding: "16px 18px 32px",
      overflow: "auto",
    }}>
      {/* Header */}
      <div style={{ textAlign: "center" }}>
        <h1 style={{
          fontFamily: "'Playfair Display', serif",
          fontSize: "1.6rem",
          fontWeight: 700,
          color: "rgba(255,255,255,0.95)",
          margin: "8px 0 4px",
          letterSpacing: "0.02em",
        }}>
          Daily Connection
        </h1>
        <p style={{
          fontFamily: "'Quicksand', sans-serif",
          fontSize: "0.66rem",
          color: "rgba(255,255,255,0.40)",
          letterSpacing: "0.18em",
          textTransform: "uppercase",
          margin: 0,
        }}>
          Two modes · One game
        </p>
      </div>

      {/* Mode toggle */}
      <div style={{ display: "flex", justifyContent: "center" }}>
        <div className="dcg-mode-toggle">
          <button
            className={`dcg-mode-pill connection${mode === "connection" ? " active" : ""}`}
            onClick={() => { if (mode !== "connection") { haptic("light"); setMode("connection"); } }}
          >
            Connection
          </button>
          <button
            className={`dcg-mode-pill naughty${mode === "naughty" ? " active" : ""}`}
            onClick={() => { if (mode !== "naughty") { haptic("light"); setMode("naughty"); } }}
          >
            Naughty
          </button>
        </div>
      </div>

      {/* Mode body — soft cross-fade between the two */}
      <AnimatePresence mode="wait">
        {mode === "connection" ? (
          <motion.div
            key="connection"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            style={{
              borderRadius: 28,
              border: "1px solid rgba(255,255,255,0.10)",
              overflow: "hidden",
              backdropFilter: "blur(32px) saturate(180%)",
              WebkitBackdropFilter: "blur(32px) saturate(180%)",
              background: "rgba(15,15,20,0.70)",
            }}
          >
            <DailyConnectionCard
              tetherId={tether.id}
              myId={profile.id}
              myName={profile.full_name}
              partnerId={partnerProfile?.id ?? null}
              partnerName={partnerName}
            />
          </motion.div>
        ) : (
          <motion.div
            key="naughty"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
          >
            <NaughtyQuestionSection
              tetherId={tether.id}
              myId={profile.id}
              myName={profile.full_name}
              partnerId={partnerProfile?.id ?? null}
              partnerName={partnerName}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
