import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/lib/AuthContext";
import { haptic } from "@/lib/haptics";

/* ──────────────────────────────────────────────────────────────────
   EditInfoScreen
   ──────────────────────────────────────────────────────────────────
   Settings → Edit Info modal. Lets either partner update the dates
   that drive the home page countdowns:
     • Anniversary / relationship start date  → Tether row
     • My birthday                            → my profile row
     • Partner's birthday                     → partner profile row
   All three are optional; saving a blank field clears it (sets the
   value to NULL in the DB) so the matching home-page card simply
   hides until the date is re-entered.
   ────────────────────────────────────────────────────────────────── */

interface Props {
  open: boolean;
  onClose: () => void;
}

/** Convert a possibly-null ISO string ("2025-04-07" or
 *  "2025-04-07T00:00:00+00") to the `YYYY-MM-DD` form that
 *  <input type="date"> expects. We deliberately avoid feeding ISO
 *  timestamps through `new Date()` + local getters because that can
 *  shift the date by a day for users in negative UTC offsets — a
 *  birthday saved as 1995-01-07 must always render as 1995-01-07
 *  regardless of the viewer's timezone. */
function isoToDateInput(value: string | null | undefined): string {
  if (!value) return "";
  // Both pure dates ("YYYY-MM-DD") and ISO timestamps
  // ("YYYY-MM-DDTHH:mm:ss…") begin with the calendar date, so the
  // first 10 chars are always the canonical answer.
  const head = value.slice(0, 10);
  return /^\d{4}-\d{2}-\d{2}$/.test(head) ? head : "";
}

export default function EditInfoScreen({ open, onClose }: Props) {
  const { profile, partnerProfile, tether, updateRelationshipInfo } = useAuth();

  const myFirstName      = profile?.first_name ?? profile?.full_name ?? "You";
  const partnerFirstName = partnerProfile?.first_name ?? partnerProfile?.full_name ?? "Partner";

  const [anniversary, setAnniversary]         = useState("");
  const [myBirthday, setMyBirthday]           = useState("");
  const [partnerBirthday, setPartnerBirthday] = useState("");
  const [busy, setBusy]                       = useState(false);
  const [saved, setSaved]                     = useState(false);
  const [error, setError]                     = useState<string | null>(null);

  // Refresh form values from the auth context every time we open so
  // we don't show stale text from the previous session.
  useEffect(() => {
    if (!open) return;
    setAnniversary(isoToDateInput(tether?.anniversary_date ?? tether?.start_date ?? null));
    setMyBirthday(isoToDateInput(profile?.birthday ?? null));
    setPartnerBirthday(isoToDateInput(partnerProfile?.birthday ?? null));
    setSaved(false);
    setError(null);
  }, [open, profile, partnerProfile, tether]);

  async function handleSave() {
    if (busy) return;
    setBusy(true);
    setError(null);
    haptic("medium");
    const res = await updateRelationshipInfo({
      anniversaryDate: anniversary  ? anniversary  : null,
      myBirthday:      myBirthday   ? myBirthday   : null,
      partnerBirthday: partnerProfile ? (partnerBirthday ? partnerBirthday : null) : undefined,
    });
    setBusy(false);
    if (res.error) {
      setError(res.error);
      return;
    }
    setSaved(true);
    setTimeout(() => {
      onClose();
      setTimeout(() => setSaved(false), 400);
    }, 900);
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 9100,
            display: "flex",
            alignItems: "flex-end",
            justifyContent: "center",
          }}
        >
          {/* Backdrop */}
          <div
            onClick={busy ? undefined : onClose}
            style={{
              position: "absolute",
              inset: 0,
              background: "rgba(0,0,0,0.55)",
              backdropFilter: "blur(4px)",
              WebkitBackdropFilter: "blur(4px)",
            }}
          />

          {/* Sheet — tall enough to clear the dock, with a flex
              column layout so the header stays pinned and only the
              body scrolls. */}
          <motion.div
            initial={{ y: 80 }}
            animate={{ y: 0 }}
            exit={{ y: 80 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            style={{
              position: "relative",
              zIndex: 1,
              width: "100%",
              maxWidth: 520,
              height: "88vh",
              borderRadius: "28px 28px 0 0",
              background: "rgba(20,15,25,0.95)",
              backdropFilter: "blur(48px) saturate(1.8)",
              WebkitBackdropFilter: "blur(48px) saturate(1.8)",
              border: "1px solid rgba(255,255,255,0.14)",
              borderBottom: "none",
              boxShadow: "0 -4px 40px rgba(0,0,0,0.5)",
              display: "flex",
              flexDirection: "column",
              overflow: "hidden",
            }}
          >
            {/* Handle */}
            <div
              style={{
                width: 36,
                height: 4,
                borderRadius: 2,
                background: "rgba(255,255,255,0.20)",
                margin: "14px auto 0",
                flexShrink: 0,
              }}
            />

            {/* Header */}
            <div
              style={{
                padding: "12px 20px 16px",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                borderBottom: "1px solid rgba(255,255,255,0.08)",
                flexShrink: 0,
              }}
            >
              <button
                type="button"
                onClick={onClose}
                disabled={busy}
                style={{
                  background: "transparent",
                  border: "none",
                  color: "rgba(255,255,255,0.65)",
                  fontSize: "0.9rem",
                  fontWeight: 500,
                  cursor: busy ? "default" : "pointer",
                  padding: "4px 8px",
                  opacity: busy ? 0.5 : 1,
                }}
              >
                Cancel
              </button>
              <h2
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: "1.05rem",
                  fontWeight: 700,
                  color: "white",
                  margin: 0,
                }}
              >
                Edit Info
              </h2>
              <button
                type="button"
                onClick={handleSave}
                disabled={busy || saved}
                style={{
                  background: saved
                    ? "rgba(72,187,120,0.20)"
                    : "linear-gradient(135deg, #E53E3E, #742A2A)",
                  border: saved
                    ? "1px solid rgba(72,187,120,0.45)"
                    : "1px solid rgba(255,255,255,0.18)",
                  color: "white",
                  fontSize: "0.85rem",
                  fontWeight: 600,
                  cursor: busy || saved ? "default" : "pointer",
                  padding: "6px 14px",
                  borderRadius: 12,
                  opacity: busy ? 0.7 : 1,
                  transition: "background 0.2s",
                }}
              >
                {saved ? "✓ Saved" : busy ? "Saving…" : "Save"}
              </button>
            </div>

            {/* Body — scrollable, fills the remaining height after the
                fixed header. Bottom padding clears the phone's home
                indicator / dock so the last field is always reachable. */}
            <div
              style={{
                padding: "20px 20px",
                paddingBottom: "max(32px, env(safe-area-inset-bottom, 32px))",
                overflowY: "auto",
                flex: 1,
                display: "flex",
                flexDirection: "column",
                gap: 18,
              }}
            >
              <p
                style={{
                  color: "rgba(200,210,235,0.75)",
                  fontSize: "0.85rem",
                  lineHeight: 1.45,
                  margin: 0,
                }}
              >
                Set the dates that drive your home page — the days-together
                counter and the birthday & anniversary countdowns. Leave a
                field empty to hide that card until you fill it in.
              </p>

              <DateField
                label="Our Anniversary"
                value={anniversary}
                onChange={setAnniversary}
              />

              <DateField
                label={`${myFirstName}'s Birthday`}
                value={myBirthday}
                onChange={setMyBirthday}
              />

              {partnerProfile ? (
                <DateField
                  label={`${partnerFirstName}'s Birthday`}
                  value={partnerBirthday}
                  onChange={setPartnerBirthday}
                />
              ) : (
                <p
                  style={{
                    color: "rgba(200,210,235,0.55)",
                    fontSize: "0.78rem",
                    margin: 0,
                    fontStyle: "italic",
                  }}
                >
                  Your partner hasn't joined yet — they'll be able to add
                  their own birthday once they sign in.
                </p>
              )}

              {error && (
                <p
                  style={{
                    color: "#fca5a5",
                    fontSize: "0.82rem",
                    background: "rgba(127,29,29,0.30)",
                    border: "1px solid rgba(248,113,113,0.30)",
                    borderRadius: 12,
                    padding: "10px 12px",
                    margin: 0,
                  }}
                >
                  {error}
                </p>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function DateField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (next: string) => void;
}) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <span
        style={{
          color: "rgba(180,200,235,0.85)",
          fontSize: "0.72rem",
          fontWeight: 600,
          letterSpacing: "0.08em",
          textTransform: "uppercase",
        }}
      >
        {label}
      </span>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <input
          type="date"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          style={{
            flex: 1,
            padding: "12px 14px",
            borderRadius: 14,
            background: "rgba(255,255,255,0.08)",
            border: "1px solid rgba(255,255,255,0.18)",
            color: "white",
            fontSize: "0.95rem",
            outline: "none",
            colorScheme: "dark",
          }}
        />
        {value && (
          <button
            type="button"
            onClick={() => onChange("")}
            style={{
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.14)",
              color: "rgba(255,255,255,0.65)",
              fontSize: "0.75rem",
              fontWeight: 500,
              cursor: "pointer",
              padding: "10px 12px",
              borderRadius: 12,
            }}
            aria-label={`Clear ${label}`}
          >
            Clear
          </button>
        )}
      </div>
    </label>
  );
}
