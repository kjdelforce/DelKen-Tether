import { useEffect, useRef } from "react";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import {
  applyTheme,
  isThemeKey,
  readLocalTheme,
  TETHER_THEMES,
  type ThemeKey,
} from "@/lib/themes";

/**
 * ThemeProvider — applies the signed-in user's theme on mount and
 * keeps it in sync across devices.
 *
 * Behaviour:
 *   1. On mount: applies whatever's in localStorage instantly so the
 *      first paint already has the right colours.
 *   2. Once the auth profile is known: fetches `profiles.app_theme`,
 *      applies it, and updates localStorage.
 *   3. Subscribes to realtime UPDATEs on the user's profile row so
 *      that when the partner gifts a new theme it animates in
 *      automatically. A subtle toast announces the change.
 *
 * The provider renders no DOM — it's a side-effect component.
 */
export function ThemeProvider() {
  const { profile, partnerProfile } = useAuth();
  const lastApplied = useRef<ThemeKey | null>(null);

  // Eagerly apply the locally-cached theme on mount so the first paint
  // is already on-brand.
  useEffect(() => {
    const cached = readLocalTheme();
    applyTheme(cached);
    lastApplied.current = cached;
  }, []);

  useEffect(() => {
    if (!profile?.id) return;
    let cancelled = false;

    (async () => {
      // Fetch the canonical value from Supabase. If the column doesn't
      // exist yet (migration not run) the request will error — we
      // degrade gracefully by keeping the cached/default theme.
      const { data, error } = await supabase
        .from("profiles")
        .select("app_theme")
        .eq("id", profile.id)
        .single();
      if (cancelled) return;
      if (error) {
        console.warn("[themes] could not load app_theme", error.message);
        return;
      }
      const t = (data as { app_theme?: string } | null)?.app_theme;
      if (isThemeKey(t) && t !== lastApplied.current) {
        applyTheme(t);
        lastApplied.current = t;
      }
    })();

    // Realtime: the partner can write to OUR profile row to gift a theme.
    const channel = supabase
      .channel(`theme_sync_${profile.id}`)
      .on(
        "postgres_changes",
        {
          event:  "UPDATE",
          schema: "public",
          table:  "profiles",
          filter: `id=eq.${profile.id}`,
        },
        (payload) => {
          const next = (payload.new as { app_theme?: string } | null)?.app_theme;
          if (!isThemeKey(next)) return;
          if (next === lastApplied.current) return;
          applyTheme(next);
          lastApplied.current = next;
          showThemeGiftToast(
            next,
            partnerProfile?.full_name?.split(" ")[0] ?? "your partner",
          );
        },
      )
      .subscribe();

    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, [profile?.id, partnerProfile?.full_name]);

  return null;
}

// ── Toast (vanilla DOM so it's independent of any toast framework) ─
function showThemeGiftToast(themeKey: ThemeKey, partnerName: string) {
  const theme = TETHER_THEMES[themeKey];
  if (!theme) return;

  const id = "tether-theme-toast";
  // De-dupe rapid-fire toasts (e.g. re-subscriptions).
  document.getElementById(id)?.remove();

  const accent = theme.preview[2];
  const toast = document.createElement("div");
  toast.id = id;
  toast.className = "tether-theme-toast";
  toast.style.cssText = `
    position: fixed;
    top: calc(env(safe-area-inset-top, 0px) + 16px);
    left: 50%;
    transform: translateX(-50%);
    background: rgba(20, 16, 36, 0.92);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid ${accent}55;
    border-radius: 22px;
    padding: 12px 22px;
    font-size: 14px;
    font-family: 'Quicksand', sans-serif;
    color: rgba(255,255,255,0.85);
    z-index: 99999;
    pointer-events: none;
    white-space: nowrap;
    animation: tetherThemeToast 3s ease forwards;
  `;
  toast.textContent = `✦ ${partnerName} gifted you ${theme.name}`;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3100);
}
