// ════════════════════════════════════════════════════════════
//  LiquidRealism.tsx — High-fidelity liquid physics layer.
//  ─────────────────────────────────────────────────────────────
//  Single mount that owns four interlocking effects, all gated
//  by the global `body.dataset.tetherWeather` flag so the layer
//  sits idle (zero work) when the app is in clear weather.
//
//    • Rain particle system — Canvas-based, ~80 drops, varying
//      length / speed / opacity, drawn at devicePixelRatio for
//      crisp hairlines on retina. Each impact at the bottom of
//      the viewport spawns a short-lived splash arc.
//    • Ocean wave layer — three overlapping SVG paths animated
//      with different cubic-bezier timings so the crest line
//      never visibly repeats.
//    • Caustics — a radial light-pattern div with shifting
//      mask-position to mimic underwater shimmer.
//    • Touch ripple distortion — listens to global pointerdown
//      and spawns a radial-gradient ripple at the touch coords
//      that distorts the mesh below it via mix-blend-mode.
//
//  Activate from anywhere with `setLiquidWeather("rainy")`.
//  The layer is `pointer-events: none` so it never intercepts
//  touches, but still receives them via a window-level listener.
// ════════════════════════════════════════════════════════════
import { useEffect, useRef, useState } from "react";

export type LiquidWeather = "clear" | "rainy" | "ocean" | "deepsea";

/**
 * Imperative API — set from anywhere (weather widget, theme
 * gift, debug menu) to switch the liquid layer's mode. Writes
 * to `body.dataset.tetherWeather` so CSS selectors can react
 * (glass condensation, etc.) and dispatches an event so the
 * React component re-renders without prop drilling.
 */
export function setLiquidWeather(mode: LiquidWeather): void {
  if (typeof document === "undefined") return;
  document.body.dataset.tetherWeather = mode;
  window.dispatchEvent(new CustomEvent("tether:liquid-weather", { detail: mode }));
}

const WEATHER_EVENT = "tether:liquid-weather";

export function LiquidRealism() {
  const [mode, setMode] = useState<LiquidWeather>(() => {
    if (typeof document === "undefined") return "clear";
    return (document.body.dataset.tetherWeather as LiquidWeather) ?? "clear";
  });

  // Keep React state in sync with the global setter.
  useEffect(() => {
    const onChange = (e: Event) => {
      const next = (e as CustomEvent<LiquidWeather>).detail;
      if (next) setMode(next);
    };
    window.addEventListener(WEATHER_EVENT, onChange);
    return () => window.removeEventListener(WEATHER_EVENT, onChange);
  }, []);

  return (
    <div className="liquid-realism" aria-hidden="true">
      {/* Rain canvas — only mounted when raining so the RAF loop
       *  doesn't run unnecessarily. */}
      {mode === "rainy" && <RainCanvas />}

      {/* Ocean waves + (for deep sea) caustics. Mounted together
       *  for both ocean themes since they share the wave geometry. */}
      {(mode === "ocean" || mode === "deepsea") && <OceanWaves />}
      {mode === "deepsea" && <Caustics />}

      {/* Touch ripples are always active — they're a global UX
       *  cue, not a weather effect. The layer is cheap when idle. */}
      <TouchRipples />
    </div>
  );
}

// ────────────────────────────────────────────────────────────
// 1. RAIN CANVAS — particle system + splash on impact
// ────────────────────────────────────────────────────────────
interface RainDrop {
  x: number;
  y: number;
  len: number;     // streak length in CSS px
  speed: number;   // CSS px / frame at 60fps reference
  opacity: number;
  /** Hue offset so streaks aren't mono-blue — gives the field life. */
  hue: number;
}

interface Splash {
  x: number;
  y: number;
  age: number;     // 0..1, normalised lifetime
  maxR: number;    // peak radius in px
}

function RainCanvas() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let drops: RainDrop[] = [];
    let splashes: Splash[] = [];
    let dpr = Math.min(window.devicePixelRatio || 1, 2);
    let w = 0;
    let h = 0;

    const COUNT = 70; // density — tuneable

    const seedDrops = () => {
      drops = Array.from({ length: COUNT }, () => makeDrop(true));
    };

    const makeDrop = (initial: boolean): RainDrop => ({
      x:       Math.random() * w,
      y:       initial ? Math.random() * h : -20 - Math.random() * 80,
      len:     8 + Math.random() * 14,
      speed:   6 + Math.random() * 7,
      opacity: 0.25 + Math.random() * 0.55,
      hue:     200 + Math.random() * 30, // cool blues
    });

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width  = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width  = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      seedDrops();
    };

    resize();
    window.addEventListener("resize", resize);

    const tick = () => {
      ctx.clearRect(0, 0, w, h);

      // Streaks — drawn as thin lines, slightly diagonal for wind feel.
      ctx.lineWidth = 1;
      ctx.lineCap = "round";
      for (const d of drops) {
        ctx.strokeStyle = `hsla(${d.hue}, 80%, 88%, ${d.opacity})`;
        ctx.beginPath();
        ctx.moveTo(d.x, d.y);
        ctx.lineTo(d.x - 1.5, d.y + d.len);
        ctx.stroke();

        d.x -= 0.6;             // slight wind
        d.y += d.speed;

        // Impact — splash + respawn at top.
        if (d.y > h - 4) {
          splashes.push({ x: d.x, y: h - 2, age: 0, maxR: 6 + Math.random() * 6 });
          Object.assign(d, makeDrop(false));
        } else if (d.x < -10) {
          // wandered offscreen left — recycle
          Object.assign(d, makeDrop(false));
          d.x = w + 10;
        }
      }

      // Splashes — small expanding arcs, fade with age.
      for (let i = splashes.length - 1; i >= 0; i--) {
        const s = splashes[i];
        s.age += 0.06;
        if (s.age >= 1) {
          splashes.splice(i, 1);
          continue;
        }
        const r = s.maxR * s.age;
        const alpha = (1 - s.age) * 0.6;
        ctx.strokeStyle = `hsla(210, 90%, 92%, ${alpha})`;
        ctx.lineWidth = 1.1;
        ctx.beginPath();
        // Half-arc opening upward, like a real splash crown.
        ctx.arc(s.x, s.y, r, Math.PI, Math.PI * 2);
        ctx.stroke();
      }

      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return <canvas ref={canvasRef} className="liquid-rain-canvas" />;
}

// ────────────────────────────────────────────────────────────
// 2. OCEAN WAVES — 3 stacked SVG paths with desync'd cubic-beziers
// ────────────────────────────────────────────────────────────
function OceanWaves() {
  // Three crest profiles. Each is a closed path tracing the wave
  // top across 1440 units, then dropping to the SVG floor (240).
  // Animations apply different cubic-beziers + durations so the
  // crests never visibly sync — that's what kills the "GIF loop"
  // feel and reads as real water.
  return (
    <svg
      className="liquid-waves"
      viewBox="0 0 1440 240"
      preserveAspectRatio="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="wave-grad-1" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor="rgba(80,160,220,0.35)" />
          <stop offset="100%" stopColor="rgba(20,80,160,0.55)" />
        </linearGradient>
        <linearGradient id="wave-grad-2" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor="rgba(60,140,200,0.45)" />
          <stop offset="100%" stopColor="rgba(10,60,140,0.65)" />
        </linearGradient>
        <linearGradient id="wave-grad-3" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stopColor="rgba(20,80,160,0.65)" />
          <stop offset="100%" stopColor="rgba(5,30,90,0.85)" />
        </linearGradient>
      </defs>

      <path
        className="wave wave-1"
        fill="url(#wave-grad-1)"
        d="M0,160 C220,120 360,200 600,150 C840,100 980,170 1200,130 C1320,110 1400,150 1440,140 L1440,240 L0,240 Z"
      />
      <path
        className="wave wave-2"
        fill="url(#wave-grad-2)"
        d="M0,180 C200,140 380,210 620,175 C860,140 1020,200 1260,160 C1360,140 1420,170 1440,165 L1440,240 L0,240 Z"
      />
      <path
        className="wave wave-3"
        fill="url(#wave-grad-3)"
        d="M0,200 C240,170 400,220 640,195 C880,170 1040,215 1280,185 C1380,170 1430,195 1440,190 L1440,240 L0,240 Z"
      />
    </svg>
  );
}

// ────────────────────────────────────────────────────────────
// 3. CAUSTICS — shifting underwater shimmer
// ────────────────────────────────────────────────────────────
function Caustics() {
  // SVG turbulence-based mask shifted via background-position
  // gives that organic, non-tileable shimmer at near-zero cost.
  return <div className="liquid-caustics" />;
}

// ────────────────────────────────────────────────────────────
// 4. TOUCH RIPPLES — pointer-coord ripple over the mesh
// ────────────────────────────────────────────────────────────
interface Ripple { id: number; x: number; y: number; }

function TouchRipples() {
  const [ripples, setRipples] = useState<Ripple[]>([]);
  const idRef = useRef(0);

  useEffect(() => {
    // We listen on window so any tap anywhere — even on a glass
    // card — still spawns a ripple behind it. Captures pointerdown
    // (covers both mouse and touch) so it fires on the very first
    // contact instead of waiting for click.
    const onDown = (e: PointerEvent) => {
      // Throttle: ignore if a ripple is already very close in time.
      // (Fast taps still register; only spam-drag floods are damped.)
      const r: Ripple = { id: ++idRef.current, x: e.clientX, y: e.clientY };
      setRipples((prev) => [...prev.slice(-5), r]); // cap at 6 live
      // Self-clean after the keyframe finishes (matches CSS duration).
      window.setTimeout(() => {
        setRipples((prev) => prev.filter((p) => p.id !== r.id));
      }, 900);
    };
    window.addEventListener("pointerdown", onDown, { passive: true });
    return () => window.removeEventListener("pointerdown", onDown);
  }, []);

  return (
    <div className="liquid-ripples">
      {ripples.map((r) => (
        <span
          key={r.id}
          className="liquid-ripple"
          style={{ left: r.x, top: r.y }}
        />
      ))}
    </div>
  );
}

export default LiquidRealism;
