import React, { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { playSound } from "@/lib/audioManager";

/**
 * SplashScreen — Welcome Sequence
 * ─────────────────────────────────
 * Replaces the previous auto-dismiss splash with an interactive
 * launch flow. The home screen never appears until the user taps
 * the Enter button — which solves the iOS / mobile-Safari audio
 * restriction (an `AudioContext` can only be unlocked from inside
 * a real user gesture, never from a `setTimeout` callback).
 *
 * Phase timeline (relative to mount):
 *
 *   0    ms — root mounted, icon + wordmark invisible
 *   300  ms — icon fades in at vertical centre
 *   700  ms — "Tether" wordmark fades in beneath the icon
 *   1400 ms — hero group rises to 38% from top
 *   1900 ms — "Tether" wordmark fades out (translates up + away)
 *   2150 ms — "Welcome to Tether" fades in
 *   2500 ms — frosted-glass "Enter" button fades in (interactive)
 *   tap     — synchronously plays the ripple sound + invokes
 *             `onEnter({x, y})` with the tap coordinates so the
 *             parent can drive the screen-wide ripple from that
 *             exact pixel
 *
 * Visual continuity with the rest of the app: uses the existing
 * `NeonMark` SVG (the official Tether icon), the project's serif
 * (`Playfair Display`) for typography, and a soft purple particle
 * field that matches the app's ambient orb aesthetic.
 */
type Phase =
  | "init"      // mount; icon + wordmark invisible
  | "icon-in"   // icon faded in at centre
  | "word-in"   // wordmark faded in (Tether)
  | "risen"     // hero group risen to upper position
  | "word-out"  // wordmark fading out, welcome about to enter
  | "welcome"   // welcome text visible
  | "enter";    // enter button visible + interactive

// Index lookup so phase comparisons read as "at or after X".
const PHASE_ORDER: Phase[] = [
  "init", "icon-in", "word-in", "risen", "word-out", "welcome", "enter",
];
const phaseAtOrAfter = (current: Phase, target: Phase) =>
  PHASE_ORDER.indexOf(current) >= PHASE_ORDER.indexOf(target);

export function SplashScreen({
  onEnter,
}: {
  onEnter: (origin: { x: number; y: number }) => void;
}) {
  const [phase, setPhase] = useState<Phase>("init");
  const enterFiredRef = useRef(false);

  useEffect(() => {
    // Spec timings — relative to mount.
    const timers = [
      setTimeout(() => setPhase("icon-in"),   300),
      setTimeout(() => setPhase("word-in"),   700),
      setTimeout(() => setPhase("risen"),     1400),
      setTimeout(() => setPhase("word-out"),  1900),
      setTimeout(() => setPhase("welcome"),   2150),
      setTimeout(() => setPhase("enter"),     2500),
    ];
    return () => { timers.forEach(clearTimeout); };
  }, []);

  const iconVisible          = phaseAtOrAfter(phase, "icon-in");
  const wordmarkVisible      = phase === "word-in" || phase === "risen";
  const wordmarkLeaving      = phaseAtOrAfter(phase, "word-out");
  const heroRisen            = phaseAtOrAfter(phase, "risen");
  const welcomeVisible       = phaseAtOrAfter(phase, "welcome");
  const enterVisible         = phase === "enter";

  const handleEnter = (e: React.MouseEvent<HTMLButtonElement> | React.TouchEvent<HTMLButtonElement>) => {
    if (enterFiredRef.current) return;
    enterFiredRef.current = true;

    // Capture the tap point. Mouse events expose clientX/Y directly;
    // touch events expose them on the first changed touch. Falls back
    // to the button centre if neither is available (programmatic
    // synthetic event in tests, etc.).
    const target = e.currentTarget;
    const rect   = target.getBoundingClientRect();
    let x = rect.left + rect.width  / 2;
    let y = rect.top  + rect.height / 2;
    if ("clientX" in e && typeof e.clientX === "number" && e.clientX !== 0) {
      x = e.clientX;
      y = e.clientY;
    } else if ("changedTouches" in e && e.changedTouches[0]) {
      x = e.changedTouches[0].clientX;
      y = e.changedTouches[0].clientY;
    }

    // CRITICAL: play the sound synchronously inside the event handler.
    // iOS / mobile Safari only allows `AudioContext.resume()` to
    // succeed if it happens during the user-gesture task — round-
    // tripping through React state setters or microtasks would break
    // the gesture chain and the ripple sound would silently fail.
    playSound("ripple");

    onEnter({ x, y });
  };

  // Lock particle positions/durations once at mount so they don't
  // re-roll on every render. 28 particles is plenty to read as a
  // "field" without taxing low-end devices.
  const particles = useMemo(
    () => Array.from({ length: 28 }, () => ({
      size: Math.random() * 5 + 3,
      left: Math.random() * 100,
      top:  Math.random() * 100,
      dur:  Math.random() * 6 + 5,
      del:  -Math.random() * 6,
      op:   Math.random() * 0.2 + 0.05,
    })),
    [],
  );

  return (
    <div
      id="tether-loading-screen"
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 10000,
        background:
          "radial-gradient(ellipse at 50% 60%, #1a0a1e 0%, #05080f 70%)",
        overflow: "hidden",
        // Don't intercept arbitrary taps anywhere on the screen —
        // only the Enter button is interactive.
        cursor: "default",
      }}
    >
      {/* ── Particle field ───────────────────────────────────────── */}
      <div
        aria-hidden
        style={{ position: "absolute", inset: 0, pointerEvents: "none" }}
      >
        {particles.map((p, i) => (
          <span
            key={i}
            className="tls-particle"
            style={{
              position: "absolute",
              width:  p.size,
              height: p.size,
              left:   `${p.left}%`,
              top:    `${p.top}%`,
              borderRadius: "50%",
              background: "rgba(255,255,255,0.12)",
              opacity: p.op,
              animation: `tlsParticleFloat ${p.dur}s linear ${p.del}s infinite`,
            } as CSSProperties}
          />
        ))}
      </div>

      {/* ── Hero group: icon + label + Enter button ──────────────── */}
      <div
        style={{
          position: "absolute",
          left: "50%",
          // Phase 1: vertical centre. Phase 2+ ("risen"): upper-third.
          top: heroRisen ? "38%" : "50%",
          transform: "translate(-50%, -50%)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          transition:
            "top 0.9s cubic-bezier(0.22, 1, 0.36, 1), transform 0.9s cubic-bezier(0.22, 1, 0.36, 1)",
          width: "min(86vw, 420px)",
        }}
      >
        {/* ── Icon + glow ring ─────────────────────────────────── */}
        <div
          style={{
            position: "relative",
            width: 140,
            height: 140,
            marginBottom: 22,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          {/* Soft purple glow ring behind the icon */}
          <div
            aria-hidden
            style={{
              position: "absolute",
              inset: -16,
              borderRadius: 36,
              background:
                "radial-gradient(ellipse, rgba(120,80,200,0.35) 0%, transparent 70%)",
              animation: "tlsIconGlow 3s ease-in-out infinite",
              zIndex: 0,
            }}
          />

          {/* Icon itself — the existing NeonMark SVG. Fades in from
              scale 0.88 → 1 once the splash has settled. */}
          <div
            style={{
              position: "relative",
              zIndex: 1,
              opacity: iconVisible ? 1 : 0,
              transform: iconVisible ? "scale(1)" : "scale(0.88)",
              transition:
                "opacity 0.6s ease, transform 0.6s cubic-bezier(0.34, 1.56, 0.64, 1)",
            }}
          >
            <NeonMark />
          </div>
        </div>

        {/* ── Wordmark "Tether" — visible word-in → word-out ─── */}
        <p
          style={{
            fontFamily: "'Playfair Display', 'Georgia', serif",
            fontSize: 38,
            fontWeight: 700,
            color: "rgba(255,255,255,0.95)",
            letterSpacing: "0.04em",
            margin: 0,
            textShadow:
              "0 0 12px rgba(120,200,255,0.45), 0 0 28px rgba(120,200,255,0.2)",
            opacity: wordmarkVisible ? 1 : 0,
            transform: wordmarkLeaving
              ? "translateY(-8px)"
              : wordmarkVisible
              ? "translateY(0)"
              : "translateY(10px)",
            transition: wordmarkLeaving
              ? "opacity 0.35s ease, transform 0.35s ease"
              : "opacity 0.5s ease, transform 0.5s ease",
            // Reserve the layout slot so swapping in "Welcome to Tether"
            // doesn't shift the icon position.
            position: "absolute",
            top: 162,
            whiteSpace: "nowrap",
          }}
        >
          Tether
        </p>

        {/* ── Welcome text — fades in once wordmark has left ── */}
        <p
          style={{
            fontFamily: "'Playfair Display', 'Georgia', serif",
            fontSize: 24,
            fontWeight: 400,
            color: "rgba(255,255,255,0.78)",
            letterSpacing: "0.06em",
            margin: 0,
            opacity: welcomeVisible ? 1 : 0,
            transform: welcomeVisible ? "translateY(0)" : "translateY(12px)",
            transition: "opacity 0.6s ease, transform 0.6s ease",
            position: "absolute",
            top: 165,
            whiteSpace: "nowrap",
          }}
        >
          Welcome to Tether
        </p>

        {/* ── Enter button ──────────────────────────────────── */}
        <button
          type="button"
          aria-label="Enter Tether"
          onClick={handleEnter}
          // Disable the button until the enter phase so an early tap
          // (e.g. on the hero group during the rise animation) can't
          // accidentally fire the ripple before the welcome lands.
          disabled={!enterVisible}
          style={{
            marginTop: 230,
            padding: "15px 52px",
            borderRadius: 50,
            border: "1px solid rgba(255,255,255,0.18)",
            background: "rgba(255,255,255,0.07)",
            backdropFilter: "blur(20px)",
            WebkitBackdropFilter: "blur(20px)",
            cursor: enterVisible ? "pointer" : "default",
            opacity: enterVisible ? 1 : 0,
            transform:
              enterVisible ? "translateY(0) scale(1)" : "translateY(16px) scale(0.96)",
            transition:
              "opacity 0.6s ease, transform 0.6s cubic-bezier(0.34, 1.56, 0.64, 1)",
            boxShadow:
              "0 4px 24px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.15)",
            WebkitTapHighlightColor: "transparent",
            // Even when invisible, no pointer events — prevents
            // ghost-tap firing during the fade-in.
            pointerEvents: enterVisible ? "auto" : "none",
          }}
        >
          <span
            style={{
              fontFamily: "'Playfair Display', 'Georgia', serif",
              fontSize: 17,
              fontWeight: 400,
              color: "rgba(255,255,255,0.9)",
              letterSpacing: "0.12em",
              pointerEvents: "none",
            }}
          >
            Enter
          </span>
        </button>
      </div>

      {/* Inline keyframes — scoped here rather than in index.css so
          this component stays self-contained. */}
      <style>{`
        @keyframes tlsParticleFloat {
          0%   { transform: translateY(0px)   scale(1);   opacity: 0.15; }
          50%  { transform: translateY(-18px) scale(1.1); opacity: 0.25; }
          100% { transform: translateY(0px)   scale(1);   opacity: 0.15; }
        }
        @keyframes tlsIconGlow {
          0%, 100% { opacity: 0.5; transform: scale(1);    }
          50%       { opacity: 1.0; transform: scale(1.08); }
        }
        @media (prefers-reduced-motion: reduce) {
          .tls-particle { animation: none !important; }
        }
      `}</style>
    </div>
  );
}

/* ── NeonMark ──────────────────────────────────────────────────────
 * Inline SVG of the official Tether icon: rounded glass tile + two
 * figure outlines + heartbeat line. Preserved verbatim from the
 * previous splash so the brand mark stays consistent across the
 * redesign. */
function NeonMark() {
  return (
    <svg
      width="140"
      height="140"
      viewBox="0 0 200 200"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <filter id="splash-neon-glow" x="-30%" y="-30%" width="160%" height="160%">
          <feGaussianBlur stdDeviation="2.4" result="b1" />
          <feGaussianBlur in="SourceGraphic" stdDeviation="6" result="b2" />
          <feMerge>
            <feMergeNode in="b2" />
            <feMergeNode in="b1" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <linearGradient id="splash-rim-grad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%"   stopColor="#3b82f6" />
          <stop offset="50%"  stopColor="#60a5fa" />
          <stop offset="100%" stopColor="#c53030" />
        </linearGradient>
      </defs>

      <rect
        x="6" y="6" width="188" height="188" rx="44" ry="44"
        fill="rgba(8,12,24,0.85)"
        stroke="url(#splash-rim-grad)"
        strokeWidth="3"
      />

      <g filter="url(#splash-neon-glow)">
        <circle cx="78"  cy="74" r="14" stroke="#cfeaff" strokeWidth="3" fill="none" strokeLinecap="round" />
        <path d="M62 130 Q62 96 78 96 Q94 96 94 130"
              stroke="#cfeaff" strokeWidth="3" strokeLinecap="round" fill="none" />
        <circle cx="122" cy="74" r="14" stroke="#cfeaff" strokeWidth="3" fill="none" strokeLinecap="round" />
        <path d="M106 130 Q106 96 122 96 Q138 96 138 130"
              stroke="#cfeaff" strokeWidth="3" strokeLinecap="round" fill="none" />
        <path
          d="M40 130 L72 130 L80 116 L92 144 L100 100 L108 152 L120 116 L128 130 L160 130"
          stroke="#cfeaff" strokeWidth="3.4"
          strokeLinecap="round" strokeLinejoin="round" fill="none"
        />
      </g>
    </svg>
  );
}
