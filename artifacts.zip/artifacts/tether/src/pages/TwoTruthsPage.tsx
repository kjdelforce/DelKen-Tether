import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import { haptic } from "@/lib/haptics";
import {
  sendTwoTruthsNewRoundNotification,
  sendTwoTruthsGuessNotification,
  sendTwoTruthsYourTurnNotification,
} from "@/lib/notifications";

// ── Types (mirrors two_truths_rounds table) ────────────────────────
type RoundStatus = "waiting_for_guess" | "completed";

interface TwoTruthsRound {
  id: string;
  couple_id: string;
  writer_id: string;
  guesser_id: string;
  statement_1: string;
  statement_2: string;
  statement_3: string;
  lie_index: 0 | 1 | 2;
  guess_index: 0 | 1 | 2 | null;
  guessed_at: string | null;
  created_at: string;
  status: RoundStatus;
}

type Screen = "loading" | "write" | "waiting" | "guess" | "result" | "noPartner";

// Localstorage key for the per-couple score (kept device-local so we don't
// add yet-another table just for a vanity counter).
const scoreKeyFor = (coupleId: string) => `ttol_score_${coupleId}`;

interface ScoreState { you: number; partner: number; }
const ZERO_SCORE: ScoreState = { you: 0, partner: 0 };

function readScore(coupleId: string): ScoreState {
  try {
    const raw = localStorage.getItem(scoreKeyFor(coupleId));
    if (!raw) return ZERO_SCORE;
    const parsed = JSON.parse(raw);
    return {
      you:     Number.isFinite(parsed.you)     ? parsed.you     : 0,
      partner: Number.isFinite(parsed.partner) ? parsed.partner : 0,
    };
  } catch {
    return ZERO_SCORE;
  }
}

function writeScore(coupleId: string, score: ScoreState) {
  try { localStorage.setItem(scoreKeyFor(coupleId), JSON.stringify(score)); } catch { /* ignore */ }
}

// ────────────────────────────────────────────────────────────────────
export default function TwoTruthsPage() {
  const { profile, partnerProfile, tether } = useAuth();

  const meId       = profile?.id ?? null;
  const partnerId  = partnerProfile?.id ?? null;
  const coupleId   = tether?.id ?? null;
  const partnerName = partnerProfile?.full_name?.split(" ")[0] || "your partner";
  // First-name only — keeps notification bodies short on iOS lock screens.
  const myName     = profile?.full_name?.split(" ")[0] || undefined;

  const [round, setRound]         = useState<TwoTruthsRound | null>(null);
  const [loading, setLoading]     = useState(true);
  const [s1, setS1]               = useState("");
  const [s2, setS2]               = useState("");
  const [s3, setS3]               = useState("");
  const [selectedLie, setLie]     = useState<number | null>(null);
  const [submitting, setSubmit]   = useState(false);
  const [error, setError]         = useState<string | null>(null);
  const [score, setScore]         = useState<ScoreState>(ZERO_SCORE);

  // When the user taps "Next Round" on the result screen we need to
  // stop showing that completed round — but realtime / refetch will
  // happily re-load the same row and bounce them back to the result
  // screen. So we remember the dismissed round id and treat it as
  // "no active round" until a NEW row appears (different id).
  const [dismissedRoundId, setDismissedRoundId] = useState<string | null>(null);

  // Re-load whenever realtime says the round changed. We keep a ref so
  // the realtime subscription never goes stale across re-renders.
  const reloadRef = useRef<() => Promise<void>>(async () => {});

  // ── Score: hydrate when couple resolves
  useEffect(() => {
    if (!coupleId) return;
    setScore(readScore(coupleId));
  }, [coupleId]);

  // ── Load latest round for the couple
  const loadRound = useCallback(async () => {
    if (!coupleId || !meId) return;
    setLoading(true);
    // Get the most recent round — could be waiting_for_guess (active) OR
    // completed (so we can show the result screen until "Next Round").
    const { data, error: dbErr } = await supabase
      .from("two_truths_rounds")
      .select("*")
      .eq("couple_id", coupleId)
      .order("created_at", { ascending: false })
      .limit(1);
    if (dbErr) {
      console.error("[ttol] loadRound error", dbErr);
      setError("Couldn't load the round. Pull to refresh or try again.");
      setLoading(false);
      return;
    }
    setRound((data?.[0] as TwoTruthsRound | undefined) ?? null);
    setError(null);
    setLoading(false);
  }, [coupleId, meId]);

  useEffect(() => { reloadRef.current = loadRound; }, [loadRound]);

  useEffect(() => { void loadRound(); }, [loadRound]);

  // ── Realtime subscription
  useEffect(() => {
    if (!coupleId) return;
    const channel = supabase
      .channel(`ttol_rounds_${coupleId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "two_truths_rounds", filter: `couple_id=eq.${coupleId}` },
        () => { void reloadRef.current(); },
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [coupleId]);

  // ── Derive screen
  const screen: Screen = useMemo(() => {
    if (!coupleId || !meId) return "loading";
    if (!partnerId)         return "noPartner";
    if (loading)            return "loading";
    if (!round)             return "write";
    // If this round is the one the user has already dismissed via
    // "Next Round", treat it as "no active round" and route them to
    // the write screen. They'll only see a new round when realtime
    // delivers one with a different id.
    if (round.id === dismissedRoundId) return "write";
    if (round.status === "completed")  return "result";
    // status === waiting_for_guess
    if (round.writer_id  === meId) return "waiting";
    if (round.guesser_id === meId) return "guess";
    return "loading";
  }, [coupleId, meId, partnerId, loading, round, dismissedRoundId]);

  // ── Submit write
  const submitWrite = useCallback(async () => {
    if (submitting) return;
    const a = s1.trim(), b = s2.trim(), c = s3.trim();
    if (!a || !b || !c)        { setError("Fill in all three statements."); return; }
    if (selectedLie === null)  { setError('Tap "Lie" next to the false one.'); return; }
    if (!coupleId || !meId || !partnerId) { setError("Couple link not ready yet."); return; }

    setSubmit(true); setError(null);
    haptic("medium");

    // Log everything we're about to send so the developer console
    // can be used to diagnose issues without needing a DB connection.
    console.log("[ttol] submitWrite payload", {
      coupleId, meId, partnerId,
      selectedLie,
      lens: { a: a.length, b: b.length, c: c.length },
    });

    // ── Insert via SECURITY DEFINER RPC.
    // Direct table INSERT kept getting blocked by RLS policy
    // evaluation quirks. The `ttol_insert_round` function runs
    // as the DB owner and validates auth.uid() = writer_id itself,
    // so it's equally secure but immune to RLS enforcement bugs.
    const { data: newId, error: insertErr } = await supabase
      .rpc("ttol_insert_round", {
        p_couple_id:   coupleId,
        p_writer_id:   meId,
        p_guesser_id:  partnerId,
        p_statement_1: a,
        p_statement_2: b,
        p_statement_3: c,
        p_lie_index:   selectedLie,
      });

    if (insertErr) {
      console.error("[ttol] rpc insert error", insertErr);
      setSubmit(false);
      const code = (insertErr as { code?: string }).code ?? "";
      const msg  = (insertErr as { message?: string }).message ?? "Unknown error";
      if (/ttol_insert_round.*does not exist/i.test(msg) || code === "42883" || code === "PGRST202") {
        setError("DB function missing. Please run the ttol_functions.sql in Supabase SQL Editor.");
      } else if (code === "42501" || /not authorized/i.test(msg)) {
        setError(`Authorisation failed [${code}]: ${msg}`);
      } else {
        setError(`Couldn't send [${code}]: ${msg}`);
      }
      return;
    }

    console.log("[ttol] rpc insert ok, new round id:", newId);

    // ── Fetch the round we just created by its id.
    const roundId = newId as string;
    const syntheticRound: TwoTruthsRound = {
      id:          roundId ?? "pending",
      couple_id:   coupleId,
      writer_id:   meId,
      guesser_id:  partnerId,
      statement_1: a,
      statement_2: b,
      statement_3: c,
      lie_index:   selectedLie as 0 | 1 | 2,
      guess_index: null,
      guessed_at:  null,
      created_at:  new Date().toISOString(),
      status:      "waiting_for_guess",
    };

    const { data: fetched } = await supabase
      .from("two_truths_rounds")
      .select("*")
      .eq("id", roundId)
      .maybeSingle();

    setSubmit(false);
    setRound((fetched as TwoTruthsRound | null) ?? syntheticRound);
    setS1(""); setS2(""); setS3(""); setLie(null);

    // Notify the partner it's their turn to guess. Fire-and-forget —
    // a network blip on the push call must never block the UI flow.
    if (coupleId && meId) {
      void sendTwoTruthsNewRoundNotification(coupleId, meId, myName);
    }
  }, [coupleId, meId, partnerId, selectedLie, s1, s2, s3, submitting, myName]);

  // ── Submit guess
  const submitGuess = useCallback(async (idx: 0 | 1 | 2) => {
    if (!round || submitting) return;
    setSubmit(true); setError(null);
    haptic("medium");

    // Use SECURITY DEFINER RPC for the same reason as insert —
    // direct UPDATE RLS was unreliable.
    const { error: guessErr } = await supabase
      .rpc("ttol_submit_guess", {
        p_round_id:    round.id,
        p_guess_index: idx,
      });

    if (guessErr) {
      console.error("[ttol] rpc guess error", guessErr);
      setSubmit(false);
      const msg = (guessErr as { message?: string }).message ?? "Unknown error";
      setError(`Couldn't send guess: ${msg}`);
      return;
    }

    // Fetch the updated round so we have the final state.
    const { data: updatedData } = await supabase
      .from("two_truths_rounds")
      .select("*")
      .eq("id", round.id)
      .maybeSingle();

    setSubmit(false);
    const updated = (updatedData as TwoTruthsRound | null) ?? {
      ...round,
      guess_index: idx,
      guessed_at:  new Date().toISOString(),
      status:      "completed" as RoundStatus,
    };
    setRound(updated);

    // Update local score: the *guesser* won the point if they got it right.
    // The writer's "partner got it" tally is updated when the writer's
    // device next loads this completed round (via realtime → loadRound).
    const correct = updated.guess_index === updated.lie_index;
    if (coupleId && correct) {
      const next = { ...score, you: score.you + 1 };
      setScore(next); writeScore(coupleId, next);
    }

    // Notify the writer of the result. Fire-and-forget.
    if (coupleId && meId) {
      void sendTwoTruthsGuessNotification(coupleId, meId, myName, correct);
    }
  }, [round, submitting, coupleId, score, meId, myName]);

  // For the writer: when a round flips to completed via realtime, bump
  // their "partner" score if their partner guessed correctly. Guarded
  // by the round id so we don't double-count on every render.
  const lastScoredId = useRef<string | null>(null);
  useEffect(() => {
    if (!coupleId || !round || !meId) return;
    if (round.status !== "completed") return;
    if (round.writer_id !== meId)      return;            // only the writer counts the partner here
    if (lastScoredId.current === round.id) return;
    lastScoredId.current = round.id;
    if (round.guess_index === round.lie_index) {
      const next = { ...score, partner: score.partner + 1 };
      setScore(next); writeScore(coupleId, next);
    }
  }, [round, coupleId, meId, score]);

  // ── Next round: park the dismissed round id so the screen
  // derivation routes the user to "write" even if loadRound /
  // realtime returns the same completed round. As soon as a new
  // round appears (different id) the dismissal no longer matches
  // and the partner's new round naturally takes over.
  const nextRound = useCallback(() => {
    haptic("light");
    if (round?.id) setDismissedRoundId(round.id);
    setS1(""); setS2(""); setS3(""); setLie(null);
    setError(null);

    // Notify the partner that a new round has been kicked off so they
    // can come write their statements. Fire-and-forget — UI flow must
    // never wait on a push round-trip.
    if (coupleId && meId) {
      void sendTwoTruthsYourTurnNotification(coupleId, meId, myName);
    }
  }, [round?.id, coupleId, meId, myName]);

  // ────────────────────────────────────────────────────────────────
  // Render
  // ────────────────────────────────────────────────────────────────
  return (
    <div className="ttol-root">
      {/* Header */}
      <div className="ttol-header">
        <div style={{ width: 64 }} /> {/* spacer to balance score column */}
        <div className="ttol-header-center">
          <span className="ttol-category">MIND GAMES</span>
          <h1 className="ttol-title">Two Truths One Lie</h1>
        </div>
        <div className="ttol-score-wrap">
          You <strong>{score.you}</strong>
          <br />
          {partnerName} <strong>{score.partner}</strong>
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={screen}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.25 }}
          className="ttol-screen"
        >
          {screen === "loading" && (
            <div className="ttol-screen-inner">
              <div className="ttol-prompt-icon ttol-pulse-anim">✦</div>
              <p className="ttol-screen-sub">Loading…</p>
            </div>
          )}

          {screen === "noPartner" && (
            <div className="ttol-screen-inner">
              <div className="ttol-prompt-icon">🔗</div>
              <h2 className="ttol-screen-title">No partner linked</h2>
              <p className="ttol-screen-sub">
                Two Truths One Lie needs both of you connected. Link with your
                partner from the Profile page first.
              </p>
            </div>
          )}

          {screen === "write" && (
            <div className="ttol-screen-inner">
              <div className="ttol-prompt-icon">✍️</div>
              <h2 className="ttol-screen-title">Your turn to write</h2>
              <p className="ttol-screen-sub">
                Write 3 statements about yourself or your relationship. Mark
                which one is the lie — {partnerName} has to guess.
              </p>

              {(() => {
                // Compute which step is blocking Send so the UI can
                // tell the user exactly what to do instead of leaving
                // a silently-disabled button. The Lie tag also pulses
                // when it's the only thing left to do.
                const allFilled = !!s1.trim() && !!s2.trim() && !!s3.trim();
                const lieMissing = selectedLie === null;
                const needLie = allFilled && lieMissing;
                const ready = allFilled && !lieMissing;
                return (
                  <>
                    <div className="ttol-statements">
                      {([s1, s2, s3] as const).map((val, i) => (
                        <div className="ttol-statement-wrap" key={i}>
                          <div className="ttol-statement-num">{i + 1}</div>
                          <textarea
                            className="ttol-statement-input"
                            placeholder="Write a statement…"
                            value={val}
                            onChange={(e) => {
                              const v = e.target.value;
                              if (i === 0) setS1(v);
                              if (i === 1) setS2(v);
                              if (i === 2) setS3(v);
                            }}
                          />
                          <button
                            type="button"
                            className={[
                              "ttol-lie-tag",
                              selectedLie === i ? "selected" : "",
                              // Pulse the unselected Lie buttons once
                              // all 3 statements are filled — that's
                              // the point where users get stuck.
                              needLie ? "pulsing" : "",
                            ].filter(Boolean).join(" ")}
                            onClick={() => { haptic("light"); setLie(i); }}
                          >
                            Lie
                          </button>
                        </div>
                      ))}
                    </div>

                    <p className={`ttol-lie-hint ${needLie ? "needs-action" : ""} ${ready ? "ready" : ""}`}>
                      {!allFilled && (
                        <>Fill in all <strong>3 statements</strong> to continue</>
                      )}
                      {needLie && (
                        <>Now tap <strong>Lie</strong> next to the false one</>
                      )}
                      {ready && (
                        <>Ready! ✦ Tap Send below</>
                      )}
                    </p>
                    {error && <p className="ttol-error">{error}</p>}
                    <button
                      className="ttol-submit-btn"
                      onClick={submitWrite}
                      disabled={submitting || !ready}
                    >
                      {submitting ? "Sending…" : `Send to ${partnerName} ✦`}
                    </button>
                  </>
                );
              })()}
            </div>
          )}

          {screen === "waiting" && round && (
            <div className="ttol-screen-inner">
              <div className="ttol-prompt-icon ttol-pulse-anim">⏳</div>
              <h2 className="ttol-screen-title">Waiting for {partnerName}</h2>
              <p className="ttol-screen-sub">
                {partnerName} is deciding which one is the lie. You'll feel a
                Pulse when they've guessed.
              </p>
              <div className="ttol-waiting-statements">
                {[round.statement_1, round.statement_2, round.statement_3].map((s, i) => (
                  <div className="ttol-waiting-statement" key={i}>
                    <strong>{i + 1}</strong>
                    {s}
                  </div>
                ))}
              </div>
            </div>
          )}

          {screen === "guess" && round && (
            <div className="ttol-screen-inner">
              <div className="ttol-prompt-icon">🤔</div>
              <h2 className="ttol-screen-title">Which one is the lie?</h2>
              <p className="ttol-screen-sub">
                {partnerName} wrote these. Tap the one you think is the lie.
              </p>
              <div className="ttol-guess-options">
                {[round.statement_1, round.statement_2, round.statement_3].map((s, i) => (
                  <button
                    key={i}
                    className="ttol-guess-option"
                    disabled={submitting}
                    onClick={() => submitGuess(i as 0 | 1 | 2)}
                  >
                    {s}
                  </button>
                ))}
              </div>
              {error && <p className="ttol-error">{error}</p>}
            </div>
          )}

          {screen === "result" && round && round.guess_index !== null && (
            <ResultScreen
              round={round}
              isGuesser={round.guesser_id === meId}
              partnerName={partnerName}
              score={score}
              onNext={nextRound}
            />
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────
function ResultScreen({
  round, isGuesser, partnerName, score, onNext,
}: {
  round: TwoTruthsRound;
  isGuesser: boolean;
  partnerName: string;
  score: ScoreState;
  onNext: () => void;
}) {
  const correct = round.guess_index === round.lie_index;
  const title = correct
    ? (isGuesser ? "You got it!" : `${partnerName} got it!`)
    : (isGuesser ? "Not quite!" : `${partnerName} didn't get it!`);
  const sub = correct ? "The lie was spotted." : "The lie slipped through.";

  return (
    <div className="ttol-screen-inner">
      <div className="ttol-result-icon">{correct ? "🎉" : "😅"}</div>
      <h2 className="ttol-screen-title">{title}</h2>
      <p className="ttol-screen-sub">{sub}</p>

      <div className="ttol-result-reveal">
        {[round.statement_1, round.statement_2, round.statement_3].map((s, i) => {
          const isLie = i === round.lie_index;
          return (
            <div key={i} className={`ttol-result-statement ${isLie ? "lie" : "truth"}`}>
              <span className="ttol-result-statement-label">
                {isLie ? "🔴 The Lie" : "✅ Truth"}
              </span>
              {s}
            </div>
          );
        })}
      </div>

      <div className="ttol-score-display">
        You: <strong>{score.you}</strong> &nbsp;·&nbsp;
        {partnerName}: <strong>{score.partner}</strong>
      </div>

      <button className="ttol-submit-btn" onClick={onNext}>
        Next Round ↩
      </button>
    </div>
  );
}
