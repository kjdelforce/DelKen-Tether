import { useEffect, useState } from "react";
import { useAuth } from "@/lib/AuthContext";
import { isAudioMuted, setAudioMuted } from "@/lib/audioManager";
import {
  isPushEnabled,
  enablePush,
  disablePush,
  isPushSupported,
  registerServiceWorker,
  setupPushNotifications,
} from "@/lib/notifications";
import { playSound } from "@/lib/audioManager";
import { playSave } from "@/lib/sounds";
import { haptic } from "@/lib/haptics";
import { useToast } from "@/hooks/use-toast";
import { PrivacyModal } from "@/components/welcome/PrivacyModal";
import { TermsModal } from "@/components/TermsModal";
import { useSafeView } from "@/lib/safeView";
import { ThemeGiftCard } from "@/components/ThemeGiftCard";
import FontSizeScreen from "@/components/FontSizeScreen";
import LegalModal from "@/components/LegalModal";
import EditInfoScreen from "@/components/EditInfoScreen";
import { supabase } from "@/lib/supabaseClient";
import { AnimatePresence, motion } from "framer-motion";
import { ProximityToggle } from "@/components/ProximityPulse";

const ICON_SRC = (import.meta.env.BASE_URL ?? "/") + "icon-192.png";

interface SettingsPageProps {
  /** Opens the App Guide bottom-sheet (mounted at the App root). */
  onOpenGuideMenu: () => void;
}

export function SettingsPage({ onOpenGuideMenu }: SettingsPageProps) {
  const { enabled: safeViewOn, toggle: toggleSafeView } = useSafeView();
  const { profile, tether, logout } = useAuth();
  const { toast } = useToast();

  const [soundsOn, setSoundsOn] = useState(() => !isAudioMuted());
  const [notifOn, setNotifOn] = useState(false);
  const [notifBusy, setNotifBusy] = useState(false);
  const [legalOpen, setLegalOpen] = useState(false);
  const supportsPush = isPushSupported();

  const [privacyOpen, setPrivacyOpen] = useState(false);
  const [termsOpen, setTermsOpen] = useState(false);
  const [fontSizeOpen, setFontSizeOpen] = useState(false);
  const [editInfoOpen, setEditInfoOpen] = useState(false);

  // Delete Account dialog state
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    isPushEnabled().then((on) => { if (!cancelled) setNotifOn(on); });
    return () => { cancelled = true; };
  }, []);

  const onToggleSounds = () => {
    const next = !soundsOn;
    setSoundsOn(next);
    setAudioMuted(!next);
    haptic("tap");
    if (next) playSound("glassClick");
  };

  // Force-refresh the push subscription. Useful when iOS/Android has
  // silently invalidated it (most common reason a user thinks their
  // notifications "stopped working" — the toggle still reads ON.)
  const onReenableNotifications = async () => {
    if (!profile?.id || !tether?.id) return;
    haptic("light");
    playSound("glassClick");
    try {
      const reg = await registerServiceWorker();
      if (!reg) {
        toast({ title: "Not supported", description: "This browser doesn't support notifications.", variant: "destructive" });
        return;
      }
      await setupPushNotifications(reg, profile.id, tether.id);
      if (Notification.permission === "granted") {
        haptic("success");
        playSave();
        toast({ title: "Notifications re-enabled ✓", description: "Push subscription saved." });
        setNotifOn(true);
      } else if (Notification.permission === "denied") {
        toast({ title: "Blocked by browser", description: "Open your device Settings → find this app → enable Notifications.", variant: "destructive" });
      } else {
        toast({ title: "Permission dismissed", description: "Tap again and choose Allow when prompted." });
      }
    } catch {
      toast({ title: "Something went wrong", variant: "destructive" });
    }
  };

  const onToggleNotifications = async () => {
    if (notifBusy) return;
    setNotifBusy(true);
    haptic("tap");
    try {
      if (notifOn) {
        await disablePush();
        setNotifOn(false);
      } else {
        if (!profile?.id || !tether?.id) { setNotifBusy(false); return; }
        const ok = await enablePush(profile.id, tether.id);
        setNotifOn(ok);
      }
    } finally {
      setNotifBusy(false);
    }
  };

  const onOpenGuide = () => {
    haptic("tap");
    playSound("glassClick");
    onOpenGuideMenu();
  };

  const onToggleSafeView = () => {
    haptic("tap");
    if (!isAudioMuted()) playSound("glassClick");
    toggleSafeView(!safeViewOn);
  };

  const onOpenPrivacy = () => {
    haptic("tap");
    playSound("glassClick");
    setPrivacyOpen(true);
  };

  const onOpenTerms = () => {
    haptic("tap");
    playSound("glassClick");
    setTermsOpen(true);
  };

  const onDeleteAccount = async () => {
    if (!profile || !tether) return;
    setDeleteLoading(true);
    setDeleteError(null);
    try {
      // 1. Delete all profiles linked to this tether (both partners)
      await supabase.from("profiles").delete().eq("tether_id", tether.id);
      // 2. Delete the tether itself (cascades content if FK set up)
      await supabase.from("tethers").delete().eq("id", tether.id);
      // 3. Purge localStorage keys
      const keysToRemove = Object.keys(localStorage).filter(
        (k) =>
          k.startsWith("tether") ||
          k.includes("profile") ||
          k.includes("seen_") ||
          k === "tether-age-verified"
      );
      keysToRemove.forEach((k) => localStorage.removeItem(k));
      // 4. Sign out of Supabase auth session (no-op for legacy users)
      await supabase.auth.signOut().catch(() => {});
      // 5. Clear React state via logout (resets context)
      logout();
    } catch {
      setDeleteError("Something went wrong. Please try again or contact support.");
      setDeleteLoading(false);
    }
  };

  return (
    <div className="tsp-page">
      <div className="tsp-header">
        <h1 className="tsp-title">Settings</h1>
      </div>

      <div className="tsp-content">
        {/* ── Preferences ───────────────────────────────────────── */}
        <div className="tsp-section-label">Preferences</div>

        <div className="tsp-card">
          <label className="tsp-row" htmlFor="tsp-sounds-toggle">
            <div className="tsp-row-info">
              <span className="tsp-row-icon" aria-hidden="true">🔊</span>
              <div>
                <p className="tsp-row-title">Sounds</p>
                <p className="tsp-row-sub">App sounds and audio effects</p>
              </div>
            </div>
            <span className="tsp-toggle">
              <input
                id="tsp-sounds-toggle"
                type="checkbox"
                checked={soundsOn}
                onChange={onToggleSounds}
              />
              <span className="tsp-toggle-track" />
            </span>
          </label>

          <div className="tsp-divider" />

          <label className="tsp-row" htmlFor="tsp-notif-toggle">
            <div className="tsp-row-info">
              <span className="tsp-row-icon" aria-hidden="true">🔔</span>
              <div>
                <p className="tsp-row-title">Notifications</p>
                <p className="tsp-row-sub">
                  {supportsPush
                    ? "Pulse alerts and new memories"
                    : "Not supported on this device"}
                </p>
              </div>
            </div>
            <span className="tsp-toggle">
              <input
                id="tsp-notif-toggle"
                type="checkbox"
                checked={notifOn}
                disabled={!supportsPush || notifBusy}
                onChange={onToggleNotifications}
              />
              <span className="tsp-toggle-track" />
            </span>
          </label>

          {profile && tether && supportsPush && (
            <>
              <div className="tsp-divider" />
              <button
                type="button"
                className="tsp-row tsp-row-btn"
                onClick={onReenableNotifications}
              >
                <div className="tsp-row-info">
                  <span className="tsp-row-icon" aria-hidden="true">🔔</span>
                  <div>
                    <p className="tsp-row-title">Re-enable Notifications</p>
                    <p className="tsp-row-sub">
                      Force-refresh push if alerts have stopped arriving
                    </p>
                  </div>
                </div>
                <span className="tsp-chevron" aria-hidden="true">›</span>
              </button>
            </>
          )}

          {profile && tether && (
            <>
              <div className="tsp-divider" />
              <ProximityToggle tetherId={tether.id} userId={profile.id} />
            </>
          )}

          <div className="tsp-divider" />

          <label
            className="tsp-row tsp-safe-view-row"
            htmlFor="tsp-safeview-toggle"
          >
            <div className="tsp-row-info">
              <span className="tsp-row-icon" aria-hidden="true">🛡️</span>
              <div>
                <p className="tsp-row-title">Safe View</p>
                <p className="tsp-row-sub">
                  Blur private sections on this device only
                </p>
              </div>
            </div>
            <span className="tsp-toggle">
              <input
                id="tsp-safeview-toggle"
                type="checkbox"
                checked={safeViewOn}
                onChange={onToggleSafeView}
              />
              <span className="tsp-toggle-track" />
            </span>
          </label>
          <p className="tsp-safe-view-note">
            Hides your Love Language, Spicy Stats, and Daily Connection
            answers behind a soft blur. Only affects this device — your
            partner's app is never changed.
          </p>

          <div className="tsp-divider" />

          <button
            type="button"
            className="tsp-row tsp-row-btn"
            onClick={() => { haptic("light"); setFontSizeOpen(true); }}
          >
            <div className="tsp-row-info">
              <span className="tsp-row-icon" aria-hidden="true">Aa</span>
              <div>
                <p className="tsp-row-title">Text Size</p>
                <p className="tsp-row-sub">Adjust size of your typed content</p>
              </div>
            </div>
            <span className="tsp-chevron">›</span>
          </button>
        </div>

        {/* ── Your Story ────────────────────────────────────────── */}
        <div className="tsp-section-label">Your Story</div>

        <div className="tsp-card">
          <button
            type="button"
            className="tsp-row tsp-row-btn"
            onClick={() => {
              haptic("light");
              playSound("glassClick");
              setEditInfoOpen(true);
            }}
          >
            <div className="tsp-row-info">
              <span className="tsp-row-icon" aria-hidden="true">💞</span>
              <div>
                <p className="tsp-row-title">Edit Info</p>
                <p className="tsp-row-sub">Update your anniversary &amp; birthdays</p>
              </div>
            </div>
            <span className="tsp-chevron" aria-hidden="true">›</span>
          </button>
        </div>

        {/* ── Themes ───────────────────────────────────────────── */}
        <ThemeGiftCard />

        {/* ── Support ───────────────────────────────────────────── */}
        <div className="tsp-section-label">Support</div>

        <div className="tsp-card">
          <button
            type="button"
            className="tsp-row tsp-row-btn"
            onClick={onOpenGuide}
          >
            <div className="tsp-row-info">
              <span className="tsp-row-icon" aria-hidden="true">📖</span>
              <div>
                <p className="tsp-row-title">App Guide</p>
                <p className="tsp-row-sub">How to use Tether</p>
              </div>
            </div>
            <span className="tsp-chevron" aria-hidden="true">›</span>
          </button>

          <div className="tsp-divider" />

          <button
            type="button"
            className="tsp-row tsp-row-btn"
            onClick={onOpenPrivacy}
          >
            <div className="tsp-row-info">
              <span className="tsp-row-icon" aria-hidden="true">🔒</span>
              <div>
                <p className="tsp-row-title">Privacy Policy</p>
                <p className="tsp-row-sub">How we handle your data</p>
              </div>
            </div>
            <span className="tsp-chevron" aria-hidden="true">›</span>
          </button>

          <div className="tsp-divider" />

          <button
            type="button"
            className="tsp-row tsp-row-btn"
            onClick={onOpenTerms}
          >
            <div className="tsp-row-info">
              <span className="tsp-row-icon" aria-hidden="true">📄</span>
              <div>
                <p className="tsp-row-title">Terms of Service</p>
                <p className="tsp-row-sub">Your agreement with Tether</p>
              </div>
            </div>
            <span className="tsp-chevron" aria-hidden="true">›</span>
          </button>

          <div className="tsp-divider" />

          <button
            type="button"
            className="tsp-row tsp-row-btn"
            onClick={() => setLegalOpen(true)}
          >
            <div className="tsp-row-info">
              <span className="tsp-row-icon" aria-hidden="true">⚖️</span>
              <div>
                <p className="tsp-row-title">Legal</p>
                <p className="tsp-row-sub">
                  Privacy Policy, Terms &amp; Security Statement
                </p>
              </div>
            </div>
            <span className="tsp-chevron" aria-hidden="true">›</span>
          </button>
        </div>

        {/* ── About ─────────────────────────────────────────────── */}
        <div className="tsp-section-label">About</div>

        <div className="tsp-card tsp-about-card">
          <img src={ICON_SRC} alt="Tether" className="tsp-about-icon" />
          <p className="tsp-about-name">Tether</p>
          <p className="tsp-about-version">Version 1.0</p>
          <p className="tsp-about-brand">A DelKen Tech service</p>
          <p className="tsp-about-copy">
            © 2026 DelKen Tech Pty Ltd.
            <br />
            A subsidiary of DelKen.
          </p>
        </div>

        {/* ── Danger Zone ───────────────────────────────────────── */}
        <div className="tsp-section-label" style={{ color: "rgba(255,90,90,0.75)" }}>
          Danger Zone
        </div>

        <div className="tsp-card" style={{ border: "1px solid rgba(255,80,80,0.18)" }}>
          <button
            type="button"
            className="tsp-row tsp-row-btn"
            onClick={() => {
              haptic("tap");
              setDeleteError(null);
              setDeleteDialogOpen(true);
            }}
            style={{ color: "rgba(255,100,100,0.90)" }}
          >
            <div className="tsp-row-info">
              <span className="tsp-row-icon" aria-hidden="true">🗑️</span>
              <div>
                <p className="tsp-row-title" style={{ color: "rgba(255,100,100,0.90)" }}>
                  Delete Account
                </p>
                <p className="tsp-row-sub">Permanently erase all data</p>
              </div>
            </div>
            <span className="tsp-chevron" aria-hidden="true">›</span>
          </button>
        </div>

        {/* Bottom breathing room */}
        <div style={{ height: 40 }} />
      </div>

      {/* ── Modals ─────────────────────────────────────────────── */}
      <PrivacyModal open={privacyOpen} onClose={() => setPrivacyOpen(false)} />
      <TermsModal   open={termsOpen}   onClose={() => setTermsOpen(false)} />
      <FontSizeScreen open={fontSizeOpen} onClose={() => setFontSizeOpen(false)} />
      <LegalModal  open={legalOpen}   onClose={() => setLegalOpen(false)} />
      <EditInfoScreen open={editInfoOpen} onClose={() => setEditInfoOpen(false)} />

      {/* ── Delete Account Confirmation Dialog ─────────────────── */}
      <AnimatePresence>
        {deleteDialogOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            style={{
              position: "fixed", inset: 0, zIndex: 9200,
              display: "flex", alignItems: "center", justifyContent: "center",
              padding: "0 20px",
            }}
          >
            {/* Backdrop */}
            <div
              style={{
                position: "absolute", inset: 0,
                background: "rgba(0,0,0,0.65)",
                backdropFilter: "blur(8px)",
                WebkitBackdropFilter: "blur(8px)",
              }}
              onClick={() => { if (!deleteLoading) setDeleteDialogOpen(false); }}
            />

            {/* Glass card */}
            <motion.div
              initial={{ scale: 0.92, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.92, opacity: 0, y: 20 }}
              transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              role="alertdialog"
              aria-modal="true"
              aria-labelledby="del-dialog-title"
              style={{
                position: "relative", zIndex: 1,
                width: "100%", maxWidth: 380,
                borderRadius: 24,
                background: "rgba(18,12,24,0.88)",
                backdropFilter: "blur(48px) saturate(1.8)",
                WebkitBackdropFilter: "blur(48px) saturate(1.8)",
                border: "1px solid rgba(255,80,80,0.22)",
                boxShadow: "0 8px 60px rgba(0,0,0,0.55), 0 0 0 1px rgba(255,255,255,0.04) inset",
                padding: "28px 24px 24px",
                fontFamily: "'Quicksand', sans-serif",
                textAlign: "center",
              }}
            >
              {/* Icon */}
              <div style={{ fontSize: 42, marginBottom: 14 }}>⚠️</div>

              <h2
                id="del-dialog-title"
                style={{
                  fontFamily: "'Playfair Display', Georgia, serif",
                  fontSize: 20, fontWeight: 700,
                  color: "rgba(255,255,255,0.95)", margin: "0 0 14px",
                }}
              >
                Delete Both Accounts?
              </h2>

              <p style={{
                fontSize: 14, lineHeight: 1.65,
                color: "rgba(255,255,255,0.72)", margin: "0 0 10px",
              }}>
                This will <strong style={{ color: "rgba(255,130,130,0.95)" }}>permanently delete
                both your account and your partner's account</strong>, along with{" "}
                <strong style={{ color: "rgba(255,130,130,0.95)" }}>all posts, images, messages,
                memories, and every piece of content</strong> stored in your Tether.
              </p>

              <p style={{
                fontSize: 13, lineHeight: 1.6,
                color: "rgba(255,180,80,0.85)", margin: "0 0 6px",
                fontWeight: 600,
              }}>
                This action cannot be undone.
              </p>

              <p style={{
                fontSize: 13, lineHeight: 1.55,
                color: "rgba(255,255,255,0.50)", margin: "0 0 26px",
              }}>
                If you rejoin Tether in the future you will start completely
                from scratch — nothing can be recovered.
              </p>

              {deleteError && (
                <p style={{
                  fontSize: 13, color: "rgba(255,120,120,0.90)",
                  margin: "0 0 14px", lineHeight: 1.5,
                }}>
                  {deleteError}
                </p>
              )}

              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {/* Confirm — destructive */}
                <button
                  type="button"
                  disabled={deleteLoading}
                  onClick={onDeleteAccount}
                  style={{
                    width: "100%", padding: "14px 0",
                    borderRadius: 14,
                    background: deleteLoading
                      ? "rgba(180,40,40,0.35)"
                      : "rgba(200,40,40,0.72)",
                    border: "1px solid rgba(255,80,80,0.40)",
                    color: deleteLoading ? "rgba(255,255,255,0.40)" : "#fff",
                    fontSize: 15, fontWeight: 700,
                    letterSpacing: "0.01em",
                    cursor: deleteLoading ? "not-allowed" : "pointer",
                    fontFamily: "'Quicksand', sans-serif",
                    transition: "background 0.2s",
                  }}
                >
                  {deleteLoading ? "Deleting…" : "Confirm Account Deletion"}
                </button>

                {/* Cancel — glass */}
                <button
                  type="button"
                  disabled={deleteLoading}
                  onClick={() => setDeleteDialogOpen(false)}
                  style={{
                    width: "100%", padding: "13px 0",
                    borderRadius: 14,
                    background: "rgba(255,255,255,0.07)",
                    border: "1px solid rgba(255,255,255,0.14)",
                    color: "rgba(255,255,255,0.80)",
                    fontSize: 15, fontWeight: 600,
                    cursor: deleteLoading ? "not-allowed" : "pointer",
                    fontFamily: "'Quicksand', sans-serif",
                    transition: "background 0.2s",
                  }}
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
