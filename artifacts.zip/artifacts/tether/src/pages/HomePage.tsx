import React, { useState, useEffect, useCallback, useRef } from "react";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { useIdle } from "@/hooks/useIdle";
import { haptic } from "@/lib/haptics";
import { sendLoveYouNotification } from "@/lib/notifications";
import { LoveYouSender } from "@/components/LoveYouSender";
import { LoveYouOverlay } from "@/components/LoveYouOverlay";
import { useUnreadLoveYou } from "@/hooks/useUnreadLoveYou";
import { VibeCheckSection } from "@/components/VibeCheckSection";
import { usePartnerPresence } from "@/lib/usePartnerPresence";
import { PullToRefresh } from "@/components/PullToRefresh";
import { LivingSkyHeader } from "@/components/LivingSkyHeader";
import {
  GhostCloudButton,
  GhostWhisperCompose,
  GhostWhisperReceive,
  type IncomingWhisper,
} from "@/components/GhostWhisper";
import { CapsuleWidget } from "@/components/CapsuleWidget";
import { EditableText } from "@/components/EditableText";
import { SpatialCard } from "@/components/SpatialCard";
import { SensorSyncIcon } from "@/components/SensorSyncIcon";
import { LoveNoteFloater, LoveNoteWriteButton } from "@/components/LoveNotes";
import { ProximityPulse } from "@/components/ProximityPulse";
import { triggerHeartbeatPulse } from "@/components/HeartbeatPulseBorder";

// ── Dates ─────────────────────────────────────────────────────────
// Every couple — including the original Tether — sources their
// dates from the database (`tether.start_date`, `tether.anniversary_date`,
// and `profiles.birthday`). When a value is NULL the matching card on
// this page hides itself entirely; couples set the dates from
// Settings → Edit Info (or the onboarding wizard for new sign-ups).

// ── Daily quotes (rotate by day-of-month) ─────────────────────────
const QUOTES = [
  "You are my favorite person.",
  "Every day with you is my best day.",
  "Home is wherever you are.",
  "You make ordinary moments extraordinary.",
  "I love you more than yesterday, less than tomorrow.",
  "You are my greatest adventure.",
  "With you, everything feels right.",
  "You are my calm in every storm.",
  "Choosing you — every single day.",
  "You had me from the very beginning.",
  "My heart found its home in you.",
  "You are enough. You are everything.",
  "I fall for you, again and again.",
  "You are the best thing that's ever happened to me.",
  "Forever isn't long enough with you.",
  "You are my reason to smile today.",
  "Being with you is my favorite feeling.",
  "You are the love I didn't know I needed.",
  "I am so lucky to be yours.",
  "Every moment with you is a gift.",
  "You are my sunshine on cloudy days.",
  "My love for you grows every single day.",
  "You are the person I want beside me always.",
  "Thank you for being exactly who you are.",
  "You are irreplaceable — wholly, completely.",
  "My favorite sound is your laugh.",
  "You make this life so much sweeter.",
  "With you, I am home.",
  "You are so deeply loved.",
  "I'd choose you in every lifetime.",
  "You are my person. Always.",
];

// ── Helpers ────────────────────────────────────────────────────────
function getNextOccurrence(date: Date): Date {
  const now = new Date();
  const next = new Date(date);
  next.setFullYear(now.getFullYear());
  if (next < now) next.setFullYear(now.getFullYear() + 1);
  return next;
}

function daysUntil(date: Date): number {
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const target = new Date(date);
  target.setHours(0, 0, 0, 0);
  return Math.ceil((target.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
}

function daysTogether(since: Date): number {
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  const s = new Date(since);
  s.setHours(0, 0, 0, 0);
  return Math.floor((now.getTime() - s.getTime()) / (1000 * 60 * 60 * 24));
}

function isBirthdayMonth(month: number): boolean {
  return new Date().getMonth() + 1 === month;
}

function todayQuote(): string {
  const day = new Date().getDate();
  return QUOTES[day % QUOTES.length];
}

// ── Avatar Totem — single 3D glass sphere with idle physics ───────
// Always-on: subtle breathe (scale) + periodic blink (Y squash).
// Idle Engine: after 10 s of no input, the totem shifts toward a
// fresh random {x, y, yaw} target every ~3 s — a believable "looking
// around the card" idle, replacing the previous always-on yaw loop
// that read as a metronome.  Glass-sphere "Lens" overlay sits on
// top; environmental aura colour-bleeds onto neighbours.
function AvatarTotem({
  initial, grad, rim, vibeGlow, delay = 0,
}: {
  initial: string;
  grad:    string;
  rim:     string;
  vibeGlow:string;
  delay?:  number;
}) {
  const isIdle = useIdle(10_000);
  const [look, setLook] = useState({ x: 0, y: 0, ry: 0, rx: 0 });

  // While idle, pick a fresh random "look-at" target every ~3 s.
  // Coordinates stay within ±5px / ±10° so the head/torso shift is
  // subtle, never theatrical.  When the user wakes the page we
  // immediately recentre.
  useEffect(() => {
    if (!isIdle) {
      setLook({ x: 0, y: 0, ry: 0, rx: 0 });
      return;
    }
    const pick = () => setLook({
      x:  (Math.random() - 0.5) * 10,
      y:  (Math.random() - 0.5) * 8,
      ry: (Math.random() - 0.5) * 18,
      rx: (Math.random() - 0.5) * 10,
    });
    pick();
    const id = setInterval(pick, 3000 + Math.random() * 1200);
    return () => clearInterval(id);
  }, [isIdle]);

  return (
    <div style={{ position: "relative", width: 44, height: 44, flexShrink: 0 }}>
      {/* Environmental glow — the totem casts coloured light onto neighbouring surfaces */}
      <motion.div
        aria-hidden
        animate={{ opacity: [0.55, 0.95, 0.55], scale: [1, 1.18, 1] }}
        transition={{ duration: 3.6, repeat: Infinity, ease: "easeInOut", delay }}
        style={{
          position: "absolute",
          inset:    -22,
          borderRadius: "50%",
          background:   `radial-gradient(circle at 50% 50%, ${vibeGlow} 0%, transparent 70%)`,
          filter:       "blur(14px)",
          pointerEvents:"none",
          zIndex:       0,
        }}
      />

      {/* Always-on breathe + blink wrapper */}
      <motion.div
        animate={{ scale: [1, 1.03, 1] }}
        transition={{ duration: 4.8, repeat: Infinity, ease: "easeInOut", delay }}
        style={{
          width: 44, height: 44, position: "relative",
          transformStyle: "preserve-3d",
          transformPerspective: 600,
        }}
      >
       {/* Idle "look-around" layer — random shift + yaw, only when idle */}
       <motion.div
        animate={{ x: look.x, y: look.y, rotateY: look.ry, rotateX: look.rx }}
        transition={{ type: "spring", stiffness: 40, damping: 14, mass: 0.9 }}
        style={{
          width: "100%", height: "100%", position: "relative",
          transformStyle: "preserve-3d",
        }}
       >
        {/* Sphere body */}
        <div
          style={{
            width: "100%", height: "100%", borderRadius: "50%",
            background: grad,
            display: "flex", alignItems: "center", justifyContent: "center",
            position: "relative",
            userSelect: "none",
            border: `1.5px solid ${rim}`,
            boxShadow: [
              `inset 1px 1px 0 rgba(255,255,255,0.55)`,
              `inset -1px -1px 0 rgba(0,0,0,0.55)`,
              `0 6px 20px rgba(0,0,0,0.55)`,
              `0 0 18px 4px ${vibeGlow}`,
            ].join(", "),
          } as React.CSSProperties}
        >
          {/* Initial */}
          <span style={{
            fontFamily: "'Playfair Display', serif",
            fontWeight: 700, fontSize: "1.15rem",
            color: "white", position: "relative", zIndex: 1,
            textShadow: "0 1px 4px rgba(0,0,0,0.55)",
          }}>
            {initial}
          </span>

          {/* Blink — eyelid sweep across the sphere face every ~5s */}
          <motion.div
            aria-hidden
            animate={{ scaleY: [0, 0, 1, 0], opacity: [0, 0, 0.55, 0] }}
            transition={{
              duration: 0.55, repeat: Infinity, repeatDelay: 4.5 + delay,
              times: [0, 0.45, 0.55, 1], ease: "easeInOut",
            }}
            style={{
              position: "absolute", inset: 0, borderRadius: "50%",
              background: "linear-gradient(180deg, rgba(0,0,0,0.55) 0%, rgba(0,0,0,0.0) 60%)",
              transformOrigin: "top",
              pointerEvents: "none", zIndex: 2,
            }}
          />

          {/* Glass lens overlay — characteristic specular arc + bottom sheen
           * making it read as if encased in a clear glass sphere. */}
          <div style={{
            position: "absolute", inset: 0, borderRadius: "50%",
            background: [
              "radial-gradient(ellipse 70% 35% at 38% 22%, rgba(255,255,255,0.72) 0%, rgba(255,255,255,0) 65%),",
              "radial-gradient(ellipse 50% 22% at 60% 88%, rgba(255,255,255,0.18) 0%, rgba(255,255,255,0) 70%)",
            ].join(" "),
            pointerEvents: "none", zIndex: 3,
          }} />
        </div>
       </motion.div>
      </motion.div>
    </div>
  );
}

function ProfileSpheres() {
  const spheres = [
    {
      initial: "K",
      grad: "radial-gradient(circle at 32% 28%, rgba(229,62,62,0.65) 0%, rgba(123,19,19,0.85) 55%, rgba(80,10,10,1) 100%)",
      rim:  "rgba(229,62,62,0.80)",
      glow: "rgba(229,62,62,0.55)",
    },
    {
      initial: "N",
      grad: "radial-gradient(circle at 32% 28%, rgba(59,130,246,0.65) 0%, rgba(30,58,138,0.85) 55%, rgba(15,30,80,1) 100%)",
      rim:  "rgba(59,130,246,0.75)",
      glow: "rgba(59,130,246,0.50)",
    },
  ];
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 18, marginTop: 10 }}>
      {spheres.map(({ initial, grad, rim, glow }, i) => (
        <AvatarTotem
          key={initial}
          initial={initial}
          grad={grad}
          rim={rim}
          vibeGlow={glow}
          delay={i * 0.7}
        />
      ))}
    </div>
  );
}

// ── Countdown Card ─────────────────────────────────────────────────
function CountdownCard({
  label, date, emoji, birthdayMonth,
}: {
  label: string; date: Date; emoji: string;
  birthdayMonth?: number;
}) {
  const next = getNextOccurrence(date);
  const days = daysUntil(next);
  const showSparkle = birthdayMonth !== undefined && isBirthdayMonth(birthdayMonth);

  return (
    <div
      className="glass-countdown rounded-2xl p-4 text-center relative overflow-hidden w-full"
      style={showSparkle ? {
        border: "1px solid rgba(255, 180, 0, 0.4)",
        boxShadow: "0 0 18px rgba(255,180,0,0.18), 0 4px 20px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.12)",
      } : undefined}
    >
      {showSparkle && (
        <>
          <span className="absolute top-1.5 right-2 text-xs animate-sparkle-float" style={{ animationDelay: "0s" }}>✨</span>
          <span className="absolute top-3 left-2 text-[10px] animate-sparkle-float" style={{ animationDelay: "0.7s" }}>⭐</span>
          <span className="absolute bottom-2 right-3 text-[10px] animate-sparkle-float" style={{ animationDelay: "1.2s" }}>✨</span>
        </>
      )}

      <div className="text-2xl mb-1">{emoji}</div>
      <div className="text-3xl font-bold text-white" style={{ fontFamily: "'Playfair Display', serif" }}>
        {days === 0 ? "Today!" : days}
      </div>
      <div style={{ letterSpacing: "1px", textTransform: "uppercase" }} className="text-blue-200 text-[10px] mt-0.5">
        {days === 0 ? "🎉" : "days away"}
      </div>
      <div className="text-blue-100 text-sm font-medium mt-2 tracking-wide">{label}</div>
      <div style={{ letterSpacing: "1px", textTransform: "uppercase" }} className="text-blue-300 text-[10px] mt-0.5">
        {next.toLocaleDateString("en-US", { month: "short", day: "numeric" })}
      </div>

      {showSparkle && (
        <div className="text-[10px] text-yellow-300/80 mt-1.5 font-medium tracking-wide uppercase" style={{ letterSpacing: "1px" }}>
          🎂 Birthday Month!
        </div>
      )}
    </div>
  );
}

// ── Main Page ──────────────────────────────────────────────────────
export default function HomePage({ together: togetherProp, onNavigateToCapsules }: { together?: number; onNavigateToCapsules?: () => void }) {
  const { profile, partnerProfile, tether, reload } = useAuth();
  const { toast } = useToast();

  // ── Ghost Whisper state
  const [composeOpen,     setComposeOpen]     = useState(false);
  const [incomingWhisper, setIncomingWhisper] = useState<IncomingWhisper | null>(null);

  // Check for a pending whisper from partner on mount
  useEffect(() => {
    if (!tether || !profile) return;
    supabase
      .from("temporary_whispers")
      .select("id, message")
      .eq("tether_id", tether.id)
      .neq("sender_id", profile.id)
      .order("created_at", { ascending: true })
      .limit(1)
      .then(({ data }) => {
        if (data && data.length > 0) setIncomingWhisper(data[0] as IncomingWhisper);
      });
  }, [tether, profile]);

  // Realtime: listen for new whispers from partner
  useEffect(() => {
    if (!tether || !profile) return;
    const channel = supabase
      .channel("ghost-whispers-" + tether.id)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "temporary_whispers",
          filter: `tether_id=eq.${tether.id}` },
        (payload) => {
          const row = payload.new as { id: string; message: string; sender_id: string };
          if (row.sender_id !== profile.id) {
            setIncomingWhisper({ id: row.id, message: row.message });
          }
        }
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [tether, profile]);

  // Unread love message from partner → triggers cinematic overlay.
  // The hook owns the Supabase polling + realtime subscription and
  // the read-mark mutation, so this page stays declarative.
  const { unreadId: pendingLoveId, dismiss: dismissReceiver } = useUnreadLoveYou({
    tetherId:  tether?.id,
    partnerId: partnerProfile?.id,
  });

  // Send a Love You
  const sendLoveYou = useCallback(async () => {
    if (!profile || !tether) return;

    // Fire the global heartbeat border the moment the sender taps —
    // the visual reads as their own pulse going out into the wire.
    triggerHeartbeatPulse();

    const { error } = await supabase.from("love_messages").insert({
      tether_id: tether.id,
      sender_id: profile.id,
    });

    if (error) {
      toast({ title: "Oops!", description: error.message, variant: "destructive" });
      return;
    }

    sendLoveYouNotification(tether.id, profile.id, profile.full_name).catch(() => {});
  }, [profile, tether, toast]);

  const partnerName =
    partnerProfile?.first_name ??
    partnerProfile?.full_name ??
    "your partner";
  // The days-together counter is driven entirely by the saved
  // anniversary / start date on the tether row. Until the couple sets
  // it from Settings → Edit Info (or during onboarding) the counter
  // simply doesn't render — better empty than wrong.
  const annivISO = tether?.anniversary_date ?? tether?.start_date ?? null;
  const tetherStart: Date | null = annivISO ? new Date(annivISO) : null;
  const together    = togetherProp ?? (tetherStart ? daysTogether(tetherStart) : null);
  const quote       = todayQuote();

  // ── Depth-aware parallax (gyroscope on mobile, mousemove on desktop)
  // Tilts three layers at different rates for a "looking through glass"
  // effect.  All listeners + RAF are cleaned up on unmount and reset
  // any inline transforms so the elements don't stay offset.
  useEffect(() => {
    // `bg` (the sky gradient inside LivingSkyHeader) is keyed by phase
    // and gets re-mounted by AnimatePresence on every dawn→day→golden→
    // night cross-fade — so we can't capture it once.  We re-resolve it
    // each frame if the previously captured node has detached.
    let bg  = document.querySelector<HTMLElement>(".parallax-bg");
    let mid = document.querySelector<HTMLElement>(".parallax-mid");
    const ui  = document.querySelector<HTMLElement>(".parallax-ui");
    const vig = document.querySelector<HTMLElement>(".parallax-vignette");
    if (!bg || !ui) return;

    const MULT = {
      bg:  { x: 8,  y: 6  },
      mid: { x: 14, y: 10 },
      ui:  { x: 20, y: 15 },
      vig: { x: 6,  y: 4  },
    };

    const current = { x: 0, y: 0 };
    const target  = { x: 0, y: 0 };
    let rafId: number | null = null;
    let isActive = false;
    let cancelled = false;

    const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

    const tick = () => {
      if (cancelled) return;
      // Re-resolve detached nodes (AnimatePresence swaps the sky on
      // phase change, leaving our captured ref pointing at a removed
      // element).  `isConnected` is cheap — checking once per frame
      // is well under any perf budget.
      if (!bg  || !bg.isConnected)  bg  = document.querySelector<HTMLElement>(".parallax-bg");
      if (!mid || !mid.isConnected) mid = document.querySelector<HTMLElement>(".parallax-mid");
      current.x = lerp(current.x, target.x, 0.08);
      current.y = lerp(current.y, target.y, 0.08);
      if (bg)  bg.style.transform  = `translate(${current.x * MULT.bg.x  * -1}px, ${current.y * MULT.bg.y  * -1}px)`;
      if (mid) mid.style.transform = `translate(${current.x * MULT.mid.x * -1}px, ${current.y * MULT.mid.y * -1}px)`;
      if (ui)  ui.style.transform  = `translate(${current.x * MULT.ui.x}px, ${current.y * MULT.ui.y}px)`;
      if (vig) vig.style.transform = `translate(${current.x * MULT.vig.x * -1}px, ${current.y * MULT.vig.y * -1}px)`;
      rafId = requestAnimationFrame(tick);
    };

    const handleOrientation = (e: DeviceOrientationEvent) => {
      const rawX = (e.gamma ?? 0) / 90;
      const rawY = ((e.beta ?? 0) - 20) / 90;
      target.x = Math.max(-1, Math.min(1, rawX));
      target.y = Math.max(-1, Math.min(1, rawY));
    };

    const startListening = () => {
      // Guard against the iOS permission-prompt race: requestPermission()
      // is async and can resolve *after* unmount.  Without this check
      // we'd attach a global listener that never gets cleaned up.
      if (cancelled || isActive) return;
      isActive = true;
      window.addEventListener("deviceorientation", handleOrientation, true);
      if (rafId == null) rafId = requestAnimationFrame(tick);
    };

    const stopListening = () => {
      isActive = false;
      window.removeEventListener("deviceorientation", handleOrientation, true);
      if (rafId != null) { cancelAnimationFrame(rafId); rafId = null; }
      target.x = 0; target.y = 0;
    };

    // ── iOS PWA standalone fix ─────────────────────────────────────
    // When the app is launched from the iOS Home Screen (standalone
    // mode), Safari blocks DeviceOrientationEvent.requestPermission()
    // unless it's invoked from a direct tap on a real visible element
    // — programmatic/document-level gesture handlers silently fail.
    // So in PWA standalone we render an in-app frosted prompt and fire
    // the permission request from the user's tap on its button.
    const nav = window.navigator as Navigator & { standalone?: boolean };
    const isStandalonePWA = nav.standalone === true;
    const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);

    const DOE = DeviceOrientationEvent as unknown as {
      requestPermission?: () => Promise<"granted" | "denied">;
    };

    let permissionOverlay: HTMLDivElement | null = null;
    let pwaAutoStartTimer: number | null = null;

    const showParallaxPermissionPrompt = () => {
      if (localStorage.getItem("motionGranted") === "true") {
        startListening();
        return;
      }
      if (permissionOverlay) return; // already showing

      const overlay = document.createElement("div");
      overlay.id = "parallax-permission-overlay";
      overlay.style.cssText = `
        position: fixed; inset: 0; z-index: 9999;
        display: flex; align-items: flex-end; justify-content: center;
        padding-bottom: 48px; background: transparent; pointer-events: none;
      `;

      const card = document.createElement("div");
      card.style.cssText = `
        background: rgba(20, 20, 30, 0.82);
        backdrop-filter: blur(24px);
        -webkit-backdrop-filter: blur(24px);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 20px;
        padding: 20px 24px;
        max-width: 320px; width: 90%;
        text-align: center; pointer-events: all;
        box-shadow: 0 8px 40px rgba(0,0,0,0.4);
      `;
      card.innerHTML = `
        <p style="margin:0 0 16px;color:rgba(255,255,255,0.75);font-size:14px;line-height:1.5;font-family:inherit;">
          Enable motion for the depth effect
        </p>
        <button id="parallax-allow-btn" style="
          width:100%;padding:13px;border-radius:12px;border:none;
          background:rgba(255,255,255,0.12);color:rgba(255,255,255,0.9);
          font-size:15px;font-family:inherit;cursor:pointer;letter-spacing:0.02em;
        ">Enable</button>
      `;
      overlay.appendChild(card);
      document.body.appendChild(overlay);
      permissionOverlay = overlay;

      const removeOverlay = () => {
        if (permissionOverlay && permissionOverlay.parentNode) {
          permissionOverlay.parentNode.removeChild(permissionOverlay);
        }
        permissionOverlay = null;
      };

      const allowBtn = overlay.querySelector<HTMLButtonElement>("#parallax-allow-btn");
      allowBtn?.addEventListener("click", () => {
        DOE.requestPermission?.()
          .then((state) => {
            if (state === "granted") {
              localStorage.setItem("motionGranted", "true");
              startListening();
            }
            removeOverlay();
          })
          .catch(() => removeOverlay());
      });

      // Tap outside the card to dismiss without enabling
      overlay.addEventListener("click", (e) => {
        if (e.target === overlay) removeOverlay();
      });
    };

    const requestPermissionAndStart = () => {
      if (typeof DeviceOrientationEvent !== "undefined" && typeof DOE.requestPermission === "function") {
        if (isStandalonePWA && isIOS) {
          // PWA standalone — must come from a tap on our own visible element
          showParallaxPermissionPrompt();
        } else {
          // Normal Safari — programmatic call from gesture handler works
          DOE.requestPermission()
            .then((state) => { if (state === "granted") startListening(); })
            .catch(() => {});
        }
      } else {
        // Android / older iOS — no permission required
        startListening();
      }
    };

    const onClickOnce = () => requestPermissionAndStart();
    const onTouchOnce = () => requestPermissionAndStart();
    document.addEventListener("click",      onClickOnce, { once: true });
    document.addEventListener("touchstart", onTouchOnce, { once: true });

    // On PWA standalone launch, auto-resume if permission has ever been
    // granted on this device — the prompt only ever shows once.
    if (isStandalonePWA && isIOS) {
      pwaAutoStartTimer = window.setTimeout(() => {
        if (localStorage.getItem("motionGranted") === "true") {
          startListening();
        }
      }, 500);
    }

    const onVisibility = () => {
      if (document.hidden) stopListening();
      else if (!isActive)  startListening();
    };
    document.addEventListener("visibilitychange", onVisibility);

    // Desktop fallback — mouse parallax
    let onMouseMove: ((e: MouseEvent) => void) | null = null;
    if (window.matchMedia("(hover: hover)").matches) {
      const W = window.innerWidth  / 2;
      const H = window.innerHeight / 2;
      onMouseMove = (e) => {
        target.x = (e.clientX - W) / W;
        target.y = (e.clientY - H) / H;
      };
      window.addEventListener("mousemove", onMouseMove);
      if (rafId == null) rafId = requestAnimationFrame(tick);
    }

    return () => {
      cancelled = true;
      document.removeEventListener("click",      onClickOnce);
      document.removeEventListener("touchstart", onTouchOnce);
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("deviceorientation", handleOrientation, true);
      if (onMouseMove) window.removeEventListener("mousemove", onMouseMove);
      if (rafId != null) cancelAnimationFrame(rafId);
      if (pwaAutoStartTimer != null) clearTimeout(pwaAutoStartTimer);
      // Tear down the in-app permission prompt if it's still open
      if (permissionOverlay && permissionOverlay.parentNode) {
        permissionOverlay.parentNode.removeChild(permissionOverlay);
      }
      // Reset transforms so elements don't stay offset after unmount
      [bg, mid, ui, vig].forEach((el) => { if (el) el.style.transform = ""; });
    };
  }, []);

  return (
    <>
      {/* ── Ghost Whisper overlays ───────────────────────────────── */}
      <AnimatePresence>
        {composeOpen && tether && profile && (
          <GhostWhisperCompose
            key="ghost-compose"
            tetherId={tether.id}
            senderId={profile.id}
            onClose={() => setComposeOpen(false)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {incomingWhisper && (
          <GhostWhisperReceive
            key={incomingWhisper.id}
            whisper={incomingWhisper}
            onDone={() => setIncomingWhisper(null)}
          />
        )}
      </AnimatePresence>

      {/* ── Cinematic Love-You arrival overlay ──────────────────── */}
      <AnimatePresence>
        {pendingLoveId && partnerProfile && (
          <LoveYouOverlay
            key={pendingLoveId}
            senderName={partnerProfile.full_name}
            onDismiss={dismissReceiver}
          />
        )}
      </AnimatePresence>

      <PullToRefresh onRefresh={reload} className="h-full">

        {/* ── "Us" Hero — Living Sky (full-bleed, no side padding) ─── */}
        <LivingSkyHeader>
          {/* Ghost Whisper button — top-right of hero */}
          <div style={{
            position: "absolute",
            top: 14,
            right: 16,
            zIndex: 20,
          }}>
            <GhostCloudButton onPress={() => setComposeOpen(true)} />
          </div>

          {/* Names are split into per-name spans so the Neon theme
              can light each partner in their own neon colour. The
              `.neon-name-kyle` / `.neon-name-nathan` classes are
              kept verbatim so existing CSS still applies — they
              now stand for "primary" and "partner" respectively. */}
          <motion.h1
            layoutId="couple-name"
            layout="position"
            className="text-4xl font-bold text-white leading-tight text-center neon-couple-h1"
            style={{
              fontFamily: "'Playfair Display', serif",
              textShadow: "0 0 48px rgba(197,48,48,0.35), 0 2px 24px rgba(0,0,0,0.90), 0 1px 6px rgba(0,0,0,0.70)",
            }}
          >
            <span className="neon-name-kyle">
              {profile?.first_name ?? profile?.full_name ?? "You"}
            </span>
            <span className="neon-couple-amp"> &amp; </span>
            <span className="neon-name-nathan">{partnerName}</span>
            <SensorSyncIcon size={16} />
          </motion.h1>

          {together !== null && (
            <motion.p
              layoutId="couple-days"
              layout="position"
              className="text-blue-100/90 mt-2 text-center neon-couple-days"
              style={{
                fontFamily: "'Caveat', cursive",
                fontSize: "1.15rem",
                textShadow: "0 1px 10px rgba(0,0,0,0.6)",
              }}
            >
              Building our life together for{" "}
              <span className="text-white font-semibold neon-couple-days-num">{together.toLocaleString()}</span> days
            </motion.p>
          )}

          {/* ── Live Presence Indicator ────────────────────────────── */}
          {tether && profile && partnerProfile && (
            <PresenceGlow
              tetherId={tether.id}
              profileId={profile.id}
              partnerId={partnerProfile.id}
              partnerName={partnerProfile.full_name}
            />
          )}

          {/* Proximity Pulse moved out of the sky header — it now
               lives in the parallax feed below, between the Vibe Check
               row and the Countdowns carousel, so it has its own
               breathing room and isn't lost behind cloud art. */}

          {!partnerProfile && (
            <p className="text-blue-200/80 text-xs mt-2 text-center">
              Share code{" "}
              <span className="font-mono font-bold text-white tracking-widest">{tether?.invite_code}</span>{" "}
              with {partnerName} to link profiles
            </p>
          )}

          {/* ── Love Note Drop (floater only) ───────────────
              The sealed-envelope floater stays inside the sky
              hero so it can hover over the profile circles when
              a note is waiting. The "Leave a Note" trigger pill
              lives further down the feed (just above the Daily
              Reminder) so it isn't hidden behind the weather. */}
          {tether && profile && partnerProfile && (
            <LoveNoteFloater
              tetherId={tether.id}
              recipientId={profile.id}
              recipientName={profile.first_name ?? profile.full_name ?? "You"}
              partnerName={partnerName}
            />
          )}
        </LivingSkyHeader>

        {/* Subtle vignette — fixed-fullscreen depth cue, drifts opposite
         * the UI so edges feel further away on tilt. */}
        <div className="parallax-vignette" aria-hidden />

        {/* Content cards sit seamlessly below the dissolved sky horizon.
         * `parallax-ui` is the foreground layer that drifts *with* tilt
         * (opposite the sky), creating the through-glass depth effect. */}
        <div className="parallax-ui px-5 pb-16 space-y-5 pt-4">

          {/* ── Vibe Check ─────────────────────────────────────────── */}
          {tether && profile && partnerProfile && (
            <VibeCheckSection
              tetherId={tether.id}
              myId={profile.id}
              myName={profile.full_name}
              partnerId={partnerProfile.id}
              partnerName={partnerProfile.full_name}
              initialMyVibe={profile.current_vibe ?? null}
              initialPartnerVibe={partnerProfile.current_vibe ?? null}
            />
          )}

          {/* ── Proximity Pulse — its own slot between the profile /
               vibe row above and the Countdowns carousel below. The
               wrapper inside the component collapses to zero height
               when no partner location is available, so this slot
               stays invisible until the pill has something to say. */}
          {tether && profile && partnerProfile && (
            <ProximityPulse
              tetherId={tether.id}
              userId={profile.id}
              partnerId={partnerProfile.id}
              partnerName={partnerProfile.first_name ?? partnerProfile.full_name ?? "they"}
            />
          )}

          {/* ── Countdowns carousel ─────────────────────────────────── */}
          <div className="space-y-3">
            {/* Section header rendered as a floating Liquid-Glass
             * secondary surface — small inline pill that matches the
             * dock's top-edge highlight and the rest of the design
             * language.  Padding kept minimal so the label still
             * reads as a section title, not a button. */}
            <p
              className="lg-surface-secondary inline-block text-blue-300/80 text-[10px] uppercase tracking-widest font-semibold"
              style={{ padding: "4px 10px", borderRadius: "var(--lg-radius-sm)" }}
            >
              Countdowns
            </p>
            <div
              className="no-scrollbar"
              style={{
                display: "flex",
                gap: 12,
                overflowX: "auto",
                scrollSnapType: "x mandatory",
                WebkitOverflowScrolling: "touch",
                marginLeft: -20,
                marginRight: -20,
                paddingLeft: 20,
                paddingRight: 20,
                paddingBottom: 4,
                scrollbarWidth: "none",
                msOverflowStyle: "none",
              } as React.CSSProperties}
            >
              {/* Anniversary card — only render if we actually have
                  a date saved on the tether (anniversary_date or
                  start_date). Otherwise the card is hidden until the
                  couple sets their anniversary in Settings → Edit Info. */}
              {(() => {
                const annivISO = tether?.anniversary_date ?? tether?.start_date ?? null;
                if (!annivISO) return null;
                return (
                  <SpatialCard intensity={0.6} radius={18} style={{ flexShrink: 0, width: "76vw", scrollSnapAlign: "start" }}>
                    <CountdownCard
                      label="Our Anniversary"
                      date={new Date(annivISO)}
                      emoji="🥂"
                    />
                  </SpatialCard>
                );
              })()}
              {/* Birthday cards — render only when we know each
                  person's birthday. Couples whose birthdays haven't
                  been written yet simply hide the card; they fill
                  them in from Settings → Edit Info. */}
              {(() => {
                const myBday      = profile?.birthday
                  ? new Date(profile.birthday)
                  : null;
                const partnerBday = partnerProfile?.birthday
                  ? new Date(partnerProfile.birthday)
                  : null;
                return (
                  <>
                    {myBday && (
                      <SpatialCard intensity={0.6} radius={18} style={{ flexShrink: 0, width: "58vw", scrollSnapAlign: "start" }}>
                        <CountdownCard
                          label={`${profile?.first_name ?? profile?.full_name ?? "Your"}'s Birthday`}
                          date={myBday}
                          emoji="🎂"
                          birthdayMonth={myBday.getMonth() + 1}
                        />
                      </SpatialCard>
                    )}
                    {partnerBday && (
                      <SpatialCard intensity={0.6} radius={18} style={{ flexShrink: 0, width: "58vw", scrollSnapAlign: "start" }}>
                        <CountdownCard
                          label={`${partnerName}'s Birthday`}
                          date={partnerBday}
                          emoji="🎂"
                          birthdayMonth={partnerBday.getMonth() + 1}
                        />
                      </SpatialCard>
                    )}
                  </>
                );
              })()}
            </div>
          </div>

          {/* ── Memory Capsule Teaser ──────────────────────────────── */}
          {onNavigateToCapsules && (
            <CapsuleWidget onNavigate={onNavigateToCapsules} />
          )}

          {/* AI Memory Widget removed — available via the games/tools
              section instead of the home feed. */}

          {/* Daily Connection + Naughty Question moved to Games Hub
              (combined into one game with mode toggle). */}

          {/* ── Love You button ─────────────────────────────────────── */}
          <LoveYouSender
            partnerName={partnerName}
            onSend={sendLoveYou}
          />

          {/* ── Leave a Note pill ──────────────────────────────────
              Sits just above the Daily Reminder so it's clear of
              the living-weather sky and always visible over the
              dark feed background. */}
          {tether && profile && partnerProfile && (
            <div style={{ display: "flex", justifyContent: "center" }}>
              <LoveNoteWriteButton
                tetherId={tether.id}
                senderId={profile.id}
                senderName={profile.first_name ?? profile.full_name ?? ""}
                recipientId={partnerProfile.id}
                partnerName={partnerName}
              />
            </div>
          )}

          {/* ── Daily Reminder ─────────────────────────────────────── */}
          {/* Promoted to `.lg-surface-primary` so the card's blur,
           * tint, radius, and shadow are sourced from the global
           * design tokens.  No padding/layout change. */}
          <div className="lg-surface-primary px-6 py-5 text-center">
            <EditableText
              id="home.daily_reminder_label"
              fallback="A Daily Reminder"
              tag="p"
              className="text-blue-300/70 text-[10px] uppercase tracking-widest font-semibold mb-2"
            />
            <EditableText
              id="home.daily_quote"
              fallback={`"${quote}"`}
              tag="p"
              className="text-white leading-snug"
              style={{ fontFamily: "'Caveat', cursive", fontSize: "1.35rem" }}
            />
          </div>

        </div>
      </PullToRefresh>
    </>
  );
}

// ── Live Presence Glow ─────────────────────────────────────────────
function PresenceGlow({
  tetherId, profileId, partnerId, partnerName,
}: {
  tetherId: string; profileId: string; partnerId: string; partnerName: string;
}) {
  const { isOnline, minutesAgo } = usePartnerPresence(tetherId, profileId, partnerId);

  // Three states
  const isActive = isOnline || (minutesAgo !== null && minutesAgo < 5);
  const isRecent = !isActive && minutesAgo !== null && minutesAgo < 30;

  function label(): string {
    if (isOnline)              return `${partnerName} is here with you`;
    if (minutesAgo === null)   return `tethered to ${partnerName}`;
    if (minutesAgo < 1)        return `${partnerName} was just here`;
    if (minutesAgo < 60)       return `${partnerName} was here ${minutesAgo}m ago`;
    const h = Math.floor(minutesAgo / 60);
    return `${partnerName} was here ${h}h ago`;
  }

  // Per-state design tokens
  const cfg = isActive
    ? {
        pill:   "rgba(197,48,48,0.28)",
        border: "rgba(255,100,130,0.55)",
        text:   "#FFD6DE",
        shadow: "0 0 28px rgba(220,50,80,0.55), 0 0 60px rgba(220,50,80,0.25)",
        heart:  "💗",
        dot:    "#FF6080",
      }
    : isRecent
    ? {
        pill:   "rgba(59,90,160,0.28)",
        border: "rgba(147,197,253,0.35)",
        text:   "rgba(190,220,255,0.90)",
        shadow: "0 0 14px rgba(100,150,255,0.20)",
        heart:  "🩷",
        dot:    "#93C5FD",
      }
    : {
        pill:   "rgba(255,255,255,0.05)",
        border: "rgba(255,255,255,0.10)",
        text:   "rgba(147,197,253,0.45)",
        shadow: "none",
        heart:  "🤍",
        dot:    "rgba(147,197,253,0.30)",
      };

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={isActive ? "active" : isRecent ? "recent" : "dim"}
        initial={{ opacity: 0, scale: 0.92, y: 6 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.92, y: -6 }}
        transition={{ duration: 0.55, ease: [0.34, 1.26, 0.64, 1] }}
        style={{ display: "flex", justifyContent: "center", marginTop: 10 }}
      >
        {/* Outer halo — only in active state */}
        <div style={{ position: "relative", display: "inline-flex" }}>
          {isActive && (
            <motion.div
              aria-hidden
              style={{
                position: "absolute", inset: -6,
                borderRadius: 999,
                background: "radial-gradient(ellipse, rgba(220,50,80,0.22) 0%, transparent 72%)",
                pointerEvents: "none",
              }}
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 3.2, repeat: Infinity, ease: "easeInOut" }}
            />
          )}

          {/* Pill */}
          <motion.div
            style={{
              display: "flex", alignItems: "center", gap: 8,
              padding: "6px 16px 6px 12px",
              borderRadius: 999,
              background: cfg.pill,
              border: `1px solid ${cfg.border}`,
              boxShadow: cfg.shadow,
              backdropFilter: "blur(12px)",
            }}
            animate={isActive ? { boxShadow: [
              "0 0 18px rgba(220,50,80,0.40), 0 0 50px rgba(220,50,80,0.15)",
              "0 0 32px rgba(220,50,80,0.70), 0 0 80px rgba(220,50,80,0.30)",
              "0 0 18px rgba(220,50,80,0.40), 0 0 50px rgba(220,50,80,0.15)",
            ]} : {}}
            transition={isActive ? { duration: 3.2, repeat: Infinity, ease: "easeInOut" } : {}}
          >
            {/* Live dot */}
            <div style={{ position: "relative", width: 8, height: 8, flexShrink: 0 }}>
              {isActive && (
                <motion.div
                  style={{
                    position: "absolute", inset: -3,
                    borderRadius: "50%",
                    background: cfg.dot,
                    opacity: 0.4,
                  }}
                  animate={{ scale: [1, 2.2, 1], opacity: [0.4, 0, 0.4] }}
                  transition={{ duration: 2.2, repeat: Infinity, ease: "easeOut" }}
                />
              )}
              <div style={{
                width: 8, height: 8, borderRadius: "50%",
                background: cfg.dot,
                boxShadow: isActive ? `0 0 6px ${cfg.dot}` : "none",
              }} />
            </div>

            {/* Heart */}
            <motion.span
              style={{ fontSize: "1.15rem", lineHeight: 1, display: "inline-block" }}
              animate={isActive ? { scale: [1, 1.18, 1] } : {}}
              transition={isActive ? { duration: 3.2, repeat: Infinity, ease: "easeInOut" } : {}}
            >
              {cfg.heart}
            </motion.span>

            {/* Text */}
            <p style={{
              fontFamily: "'Caveat', cursive",
              fontSize: "1.15rem",
              fontWeight: 600,
              margin: 0,
              color: cfg.text,
              letterSpacing: "0.01em",
              whiteSpace: "nowrap",
            }}>
              {label()}
            </p>
          </motion.div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
