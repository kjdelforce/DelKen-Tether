import { useState } from "react";
import { useAuth } from "@/lib/AuthContext";
import OnboardingWizard from "@/components/OnboardingWizard";

/* ──────────────────────────────────────────────────────────────────
   LoginPage
   ──────────────────────────────────────────────────────────────────
   Three sign-in modes:
     • "code"     — legacy invite-code + name (Kyle & Nathan)
     • "email"    — Supabase email/password (returning users)
     • "wizard"   — full multi-step onboarding for new couples
   Mode picker at top so existing users land on something familiar
   while new visitors get a clear "Create Tether" path.
   ────────────────────────────────────────────────────────────────── */

type Mode = "code" | "email" | "wizard";

export default function LoginPage() {
  const { login, signInWithEmail } = useAuth();
  const [mode, setMode] = useState<Mode>("code");

  // Invite-code form state (legacy)
  const [name, setName]   = useState("");
  const [code, setCode]   = useState("");

  // Email form state (new)
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");

  const [error, setError]     = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (mode === "wizard") {
    return <OnboardingWizard onCancel={() => setMode("code")} />;
  }

  async function handleCodeSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const result = await login(name, code);
    if (result.error) setError(result.error);
    setLoading(false);
  }

  async function handleEmailSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const result = await signInWithEmail(email, password);
    if (result.error) setError(result.error);
    setLoading(false);
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-[#0a0a0f] px-6 relative overflow-hidden">
      {/* Background orbs */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-32 -left-32 w-72 h-72 rounded-full bg-[#C53030]/15 blur-3xl" />
        <div className="absolute -bottom-24 -right-24 w-64 h-64 rounded-full bg-blue-400/10 blur-3xl" />
      </div>

      <div className="relative w-full max-w-sm z-10">
        {/* Logo */}
        <div className="text-center mb-8">
          <img
            src={`${import.meta.env.BASE_URL}icon-192.png`}
            alt="Tether"
            className="w-24 h-24 rounded-3xl mb-5 shadow-2xl mx-auto"
          />
          <h1 className="text-5xl font-bold text-white tracking-tight" style={{ fontFamily: "'Playfair Display', serif" }}>
            Tether
          </h1>
          <p className="text-blue-200 mt-2 text-xs tracking-widest uppercase">
            For two hearts
          </p>
        </div>

        {/* Mode toggle (Code / Email) */}
        <div className="grid grid-cols-2 rounded-xl overflow-hidden border border-white/15 mb-4">
          {(["code", "email"] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => { setMode(m); setError(null); }}
              className={`py-2.5 text-xs font-semibold uppercase tracking-widest transition-colors ${
                mode === m ? "bg-white/15 text-white" : "bg-transparent text-blue-200/60 hover:text-white"
              }`}
            >
              {m === "code" ? "Tether code" : "Email"}
            </button>
          ))}
        </div>

        {mode === "code" ? (
          <form onSubmit={handleCodeSubmit} className="glass-card rounded-2xl p-6 space-y-4">
            <div>
              <label className="block text-blue-200 text-xs font-semibold mb-2 uppercase tracking-widest">Your Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your first name"
                className="w-full px-4 py-3 rounded-xl bg-white/10 text-white placeholder-blue-400/60 border border-white/20 focus:outline-none focus:ring-2 focus:ring-[#C53030] focus:border-transparent text-sm"
                autoCapitalize="words"
              />
            </div>
            <div>
              <label className="block text-blue-200 text-xs font-semibold mb-2 uppercase tracking-widest">Tether Code</label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase().slice(0, 6))}
                placeholder="6-digit code"
                maxLength={6}
                className="w-full px-4 py-3 rounded-xl bg-white/10 text-white placeholder-blue-400/60 border border-white/20 focus:outline-none focus:ring-2 focus:ring-[#C53030] focus:border-transparent text-sm tracking-widest font-mono"
              />
            </div>
            {error && <p className="text-red-300 text-sm bg-red-900/30 rounded-xl px-3 py-2 border border-red-500/30">{error}</p>}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl text-white font-semibold text-sm shadow-lg active:scale-95 transition-all disabled:opacity-60"
              style={{ background: "radial-gradient(circle at 35% 35%, #E53E3E, #742A2A)" }}
            >
              {loading ? "Connecting..." : "Connect →"}
            </button>
          </form>
        ) : (
          <form onSubmit={handleEmailSubmit} className="glass-card rounded-2xl p-6 space-y-4">
            <div>
              <label className="block text-blue-200 text-xs font-semibold mb-2 uppercase tracking-widest">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-4 py-3 rounded-xl bg-white/10 text-white placeholder-blue-400/60 border border-white/20 focus:outline-none focus:ring-2 focus:ring-[#C53030] focus:border-transparent text-sm"
                autoCapitalize="none"
                autoComplete="email"
              />
            </div>
            <div>
              <label className="block text-blue-200 text-xs font-semibold mb-2 uppercase tracking-widest">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Your password"
                className="w-full px-4 py-3 rounded-xl bg-white/10 text-white placeholder-blue-400/60 border border-white/20 focus:outline-none focus:ring-2 focus:ring-[#C53030] focus:border-transparent text-sm"
                autoComplete="current-password"
              />
            </div>
            {error && <p className="text-red-300 text-sm bg-red-900/30 rounded-xl px-3 py-2 border border-red-500/30">{error}</p>}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl text-white font-semibold text-sm shadow-lg active:scale-95 transition-all disabled:opacity-60"
              style={{ background: "radial-gradient(circle at 35% 35%, #E53E3E, #742A2A)" }}
            >
              {loading ? "Signing in..." : "Sign in →"}
            </button>
          </form>
        )}

        {/* New here? */}
        <div className="mt-6 text-center">
          <p className="text-blue-100/60 text-sm">
            New to Tether?
          </p>
          <button
            onClick={() => setMode("wizard")}
            className="mt-2 text-white text-sm font-semibold underline-offset-4 hover:underline"
          >
            Create your Tether →
          </button>
        </div>
      </div>
    </div>
  );
}
