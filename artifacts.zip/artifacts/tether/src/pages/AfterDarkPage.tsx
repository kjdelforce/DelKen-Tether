import { useCallback, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/lib/AuthContext";
import { haptic } from "@/lib/haptics";
import {
  AFTER_DARK_DECKS,
  AFTER_DARK_DECK_ORDER,
  type AfterDarkCard,
  type AfterDarkDeckKey,
} from "@/data/afterDarkDecks";

/**
 * After Dark
 * ────────────────────────────────────────────────────────────────────
 * Private, turn-based intimacy game. Three opt-in intensity decks
 * (Warm Up → Heat → Inferno). Both players consent to a deck before
 * play starts; the chosen deck's accent colour drives every glow.
 *
 * Session shape (purely local — nothing persisted to the DB):
 *   - selected deck
 *   - currently displayed card
 *   - "drawn" set so the deck doesn't repeat until exhausted
 *   - whose turn (alternates each draw, seeded with the local user)
 */
type Phase = "picker" | "play";

function pickRandomFresh(
  cards: AfterDarkCard[],
  drawnIds: Set<string>,
): AfterDarkCard {
  const fresh = cards.filter(c => !drawnIds.has(c.id));
  const pool  = fresh.length > 0 ? fresh : cards; // recycle when exhausted
  return pool[Math.floor(Math.random() * pool.length)];
}

function firstNameOf(full: string | undefined | null, fallback: string): string {
  if (!full) return fallback;
  return full.split(" ")[0];
}

export default function AfterDarkPage() {
  const { profile, partnerProfile } = useAuth();

  // Fallbacks are intentionally distinct so the turn flip never
  // gets stuck in `myName === partnerName` when only one half of
  // the tether is signed in yet.
  const myName      = firstNameOf(profile?.full_name,        "Me");
  const partnerName = firstNameOf(partnerProfile?.full_name, "Partner");

  // If there's no partner profile at all, treat the session as solo
  // so the turn indicator doesn't lie.
  const isSolo = !partnerProfile?.id;

  const [phase,        setPhase]        = useState<Phase>("picker");
  const [deckKey,      setDeckKey]      = useState<AfterDarkDeckKey | null>(null);
  const [card,         setCard]         = useState<AfterDarkCard | null>(null);
  const [drawnIds,     setDrawnIds]     = useState<Set<string>>(new Set());
  // Whose turn it is *right now*. Seeded to the logged-in player so
  // they always start. Flips after every draw.
  const [currentTurn,  setCurrentTurn]  = useState<string>(myName);

  const deck = deckKey ? AFTER_DARK_DECKS[deckKey] : null;

  const accent = deck?.accentColor ?? "#a855f7";

  // ── Actions ──────────────────────────────────────────────────────
  const startWithDeck = useCallback((key: AfterDarkDeckKey) => {
    haptic("medium");
    setDeckKey(key);
    setCard(null);
    setDrawnIds(new Set());
    setCurrentTurn(myName);
    setPhase("play");
  }, [myName]);

  const drawCard = useCallback(() => {
    if (!deck) return;
    haptic("medium");
    // Pick + dedupe + commit inside the functional setter so a fast
    // double-tap can never read a stale `drawnIds` and pull the same
    // card twice. setCard / setCurrentTurn are queued in the same
    // React batch as setDrawnIds so the UI stays atomic.
    setDrawnIds(prev => {
      const next = pickRandomFresh(deck.cards, prev);
      const n = new Set(prev);
      n.add(next.id);
      setCard(next);
      if (!isSolo) {
        setCurrentTurn(t => (t === myName ? partnerName : myName));
      }
      // Wrap: keep just the card we showed so the next draw sees a
      // full pool minus the current one (no immediate repeat).
      if (n.size >= deck.cards.length) {
        return new Set([next.id]);
      }
      return n;
    });
  }, [deck, isSolo, myName, partnerName]);

  const changeIntensity = useCallback(() => {
    haptic("light");
    setPhase("picker");
    setDeckKey(null);
    setCard(null);
    setDrawnIds(new Set());
  }, []);

  // Memoised list once for the picker render path.
  const deckList = useMemo(
    () => AFTER_DARK_DECK_ORDER.map(k => AFTER_DARK_DECKS[k]),
    [],
  );

  return (
    <div
      className="ad-root"
      style={{
        // Each deck repaints the page accent in one place.
        ["--ad-accent"     as string]: accent,
        ["--ad-accent-soft" as string]: accent + "33",
      }}
    >
      <div className="ad-bg" />

      {/* ── Header ──────────────────────────────────────────────── */}
      <div className="ad-header">
        <h1 className="ad-title">After Dark</h1>
        <p className="ad-tagline">
          {phase === "picker"
            ? "Private. Intimate. No filters."
            : isSolo
              ? "Your turn"
              : `It's ${currentTurn}'s turn`}
        </p>
      </div>

      {/* ── Body ────────────────────────────────────────────────── */}
      <div className="ad-body">
        <AnimatePresence mode="wait">
          {phase === "picker" && (
            <motion.div
              key="picker"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0  }}
              exit={{    opacity: 0, y: -8 }}
              transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              className="ad-picker"
            >
              <p className="ad-picker-intro">
                Choose your intensity. You can change it any time.
              </p>

              <div className="ad-deck-grid">
                {deckList.map(d => (
                  <motion.button
                    key={d.key}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => startWithDeck(d.key)}
                    className="ad-deck-card"
                    aria-label={`Start ${d.name} deck, rated ${d.rating}. ${d.tagline}`}
                    style={{
                      ["--ad-deck-accent" as string]: d.accentColor,
                    }}
                  >
                    <div className="ad-deck-glow" />
                    <div className="ad-deck-content">
                      <div className="ad-deck-row">
                        <span className="ad-deck-name">{d.name}</span>
                        <span className="ad-deck-rating">{d.rating}</span>
                      </div>
                      <p className="ad-deck-tagline">{d.tagline}</p>
                    </div>
                  </motion.button>
                ))}
              </div>

              <p className="ad-consent-note">
                Both of you should agree on the intensity before tapping.
              </p>
            </motion.div>
          )}

          {phase === "play" && deck && (
            <motion.div
              key={`play-${deck.key}`}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{    opacity: 0, y: -8 }}
              transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              className="ad-play"
            >
              {/* Active deck pill */}
              <div className="ad-deck-pill">
                <span className="ad-deck-pill-dot" />
                <span className="ad-deck-pill-name">{deck.name}</span>
                <span className="ad-deck-pill-rating">{deck.rating}</span>
              </div>

              {/* Card area */}
              <div className="ad-card-stage">
                <AnimatePresence mode="wait">
                  {card ? (
                    <motion.div
                      key={card.id}
                      initial={{ rotateY: 180, opacity: 0 }}
                      animate={{ rotateY: 0,   opacity: 1 }}
                      exit={{    rotateY: -180, opacity: 0 }}
                      transition={{ duration: 0.55, ease: [0.4, 0, 0.2, 1] }}
                      className="ad-card"
                    >
                      <span className="ad-card-type">{card.type}</span>
                      <p className="ad-card-content">{card.content}</p>
                      <span className="ad-card-deck">{deck.name}</span>
                    </motion.div>
                  ) : (
                    <motion.button
                      key="empty"
                      whileTap={{ scale: 0.97 }}
                      onClick={drawCard}
                      className="ad-card ad-card-empty"
                    >
                      <p className="ad-card-empty-text">
                        Tap to draw from <strong>{deck.name}</strong>
                      </p>
                    </motion.button>
                  )}
                </AnimatePresence>
              </div>

              {/* Controls */}
              <div className="ad-controls">
                <motion.button
                  whileTap={{ scale: 0.96 }}
                  onClick={drawCard}
                  className="ad-btn-primary"
                >
                  {card ? "Next Turn" : "Draw Card"}
                </motion.button>

                <button
                  onClick={changeIntensity}
                  className="ad-btn-secondary"
                >
                  Change Intensity
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
