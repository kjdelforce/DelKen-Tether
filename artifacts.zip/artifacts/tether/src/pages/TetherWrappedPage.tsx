import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabaseClient";
import { haptic } from "@/lib/haptics";

// ── Anniversary (must match HomePage / App constant) ───────────────
const ANNIVERSARY = new Date("2025-04-07");
const TOTAL_SLIDES = 8;

// API base for the AI proxy. Mirrors the pattern in lib/notifications.ts.
function getApiUrl(): string {
  // dev: vite proxy might handle /api; prod: same-origin. Using "" works
  // because we always hit /api/* on the same host the page is loaded from.
  return "";
}

// ── Types ─────────────────────────────────────────────────────────
interface Stats {
  year:         number;
  daysThisYear: number;
  totalDays:    number;
  memories:     number;
  pulses:       number;
  dates:        number;
  capsules:     number;
}

interface Narratives {
  days:     string;
  memories: string;
  pulses:   string;
  dates:    string;
  capsules: string;
  summary:  string;
}

const FALLBACK_NARRATIVES = (year: number): Narratives => ({
  days:     "Every single one counted.",
  memories: "Each one a chapter in your story.",
  pulses:   "Each one a quiet whisper across the distance.",
  dates:    "Every adventure, written in the calendar of your hearts.",
  capsules: "Messages sealed with love, waiting for their moment.",
  summary:
    `${year} was yours. Every memory, every pulse, every plan — a thread in something beautiful being built together.`,
});

// ── Year selection ────────────────────────────────────────────────
// Dec → wrap THIS year. Jan → wrap LAST year. (The card itself is
// only visible Dec 25 → Jan 1, so this covers both ends of the window.)
function getWrappedYear(): number {
  const d = new Date();
  return d.getMonth() === 11 ? d.getFullYear() : d.getFullYear() - 1;
}

// Days the couple were tethered DURING the wrapped year
// (capped between the anniversary and Dec 31 of the year).
function daysInYear(year: number, anniversary: Date): number {
  const yearStart = new Date(`${year}-01-01T00:00:00Z`);
  const yearEnd   = new Date(`${year}-12-31T23:59:59Z`);
  const today     = new Date();

  const start = anniversary > yearStart ? anniversary : yearStart;
  const end   = today      < yearEnd    ? today       : yearEnd;
  if (end < start) return 0;
  const ms = end.getTime() - start.getTime();
  return Math.max(0, Math.floor(ms / (1000 * 60 * 60 * 24)));
}

// Total days since anniversary (cumulative).
function daysSince(anniversary: Date): number {
  const ms = Date.now() - anniversary.getTime();
  return Math.max(0, Math.floor(ms / (1000 * 60 * 60 * 24)));
}

// ── Component ─────────────────────────────────────────────────────
export default function TetherWrappedPage({ onBack }: { onBack?: () => void }) {
  const { profile, partnerProfile, tether } = useAuth();

  const meName      = profile?.first_name ?? profile?.full_name?.split(" ")[0] ?? "You";
  const partnerName = partnerProfile?.first_name ?? partnerProfile?.full_name?.split(" ")[0] ?? "Your partner";
  // Display order is alphabetical for stability so both partners see the
  // same opening title regardless of who opens it.
  const names = useMemo(
    () => [meName, partnerName].sort((a, b) => a.localeCompare(b)),
    [meName, partnerName],
  );

  const [slide,      setSlide]      = useState(0);
  const [stats,      setStats]      = useState<Stats | null>(null);
  const [narratives, setNarratives] = useState<Narratives | null>(null);
  const [loadingNar, setLoadingNar] = useState(false);

  const year = useMemo(getWrappedYear, []);

  // ── Load stats from Supabase
  useEffect(() => {
    if (!tether?.id) return;
    let cancelled = false;
    (async () => {
      // Clamp the lower bound to the anniversary — counting "memories
      // added in 2025" should NEVER include rows from before the couple
      // existed (defensive even though our app shouldn't have created
      // any). Upper bound is min(today, Dec 31).
      const yearStartIso = new Date(`${year}-01-01T00:00:00Z`);
      const yearEndIso   = new Date(`${year}-12-31T23:59:59Z`);
      const today        = new Date();
      const lower = ANNIVERSARY > yearStartIso ? ANNIVERSARY : yearStartIso;
      const upper = today      < yearEndIso    ? today       : yearEndIso;
      const lowerStr = lower.toISOString();
      const upperStr = upper.toISOString();

      // Parallel COUNT queries — much faster than serial.
      const tetherId = tether.id;
      const inYear = (table: string, dateCol: string) => supabase
        .from(table)
        .select("*", { count: "exact", head: true })
        .eq("tether_id", tetherId)
        .gte(dateCol, lowerStr)
        .lte(dateCol, upperStr);

      const [posts, loves, dates, caps] = await Promise.all([
        inYear("posts",         "created_at"),
        inYear("love_messages", "created_at"),
        inYear("date_plans",    "created_at"),
        inYear("time_capsules", "created_at"),
      ]);

      if (cancelled) return;
      setStats({
        year,
        daysThisYear: daysInYear(year, ANNIVERSARY),
        totalDays:    daysSince(ANNIVERSARY),
        memories:     posts.count ?? 0,
        pulses:       loves.count ?? 0,
        dates:        dates.count ?? 0,
        capsules:     caps.count  ?? 0,
      });
    })();
    return () => { cancelled = true; };
  }, [tether?.id, year]);

  // ── Generate narratives (cached per year in localStorage)
  const fetchNarratives = useCallback(async (s: Stats) => {
    const cacheKey = `tether_wrapped_${s.year}_narratives`;
    const cached = localStorage.getItem(cacheKey);
    if (cached) {
      try { return JSON.parse(cached) as Narratives; } catch { /* ignore */ }
    }

    const systemPrompt =
      "You write short, poetic, warm narrative lines for a couples app's year-in-review " +
      "feature called Tether Wrapped. Each line accompanies a stat in a cinematic " +
      "presentation. Keep each line to 1–2 sentences. Personal, specific, beautiful. " +
      "ALWAYS return ONLY a single JSON object with no Markdown fences and no commentary.";

    const userMsg = [
      `Couple: ${names.join(" & ")}`,
      `Year: ${s.year}`,
      `Stats:`,
      `- ${s.daysThisYear} days together this year (${s.totalDays} total since their anniversary)`,
      `- ${s.memories} memories added to their Scrapbook`,
      `- ${s.pulses} times they pulsed each other`,
      `- ${s.dates} dates planned`,
      `- ${s.capsules} time capsules sealed`,
      ``,
      `Return ONLY this JSON shape (no surrounding text, no code fences):`,
      `{`,
      `  "days": "narrative",`,
      `  "memories": "narrative",`,
      `  "pulses": "narrative",`,
      `  "dates": "narrative",`,
      `  "capsules": "narrative",`,
      `  "summary": "4–6 sentence poetic summary of their whole year"`,
      `}`,
    ].join("\n");

    try {
      const apiUrl = getApiUrl();
      const res = await fetch(`${apiUrl}/api/ai/chat`, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemPrompt,
          messages: [{ role: "user", content: userMsg }],
        }),
      });
      if (!res.ok) throw new Error(`AI ${res.status}`);
      const { reply } = (await res.json()) as { reply?: string };
      if (!reply) throw new Error("empty reply");

      // Defensive cleanup: strip code fences AND trailing commas before
      // the closing brace/bracket (a common LLM mistake that breaks
      // strict JSON.parse).
      const cleaned = reply
        .replace(/```json|```/g, "")
        .replace(/,(\s*[}\]])/g, "$1")
        .trim();
      const parsed = JSON.parse(cleaned) as Narratives;

      // Sanity-check shape — fall back if a key is missing.
      const required: (keyof Narratives)[] =
        ["days", "memories", "pulses", "dates", "capsules", "summary"];
      for (const k of required) {
        if (typeof parsed[k] !== "string" || !parsed[k].trim()) {
          throw new Error(`missing key ${k}`);
        }
      }

      localStorage.setItem(cacheKey, JSON.stringify(parsed));
      return parsed;
    } catch (err) {
      console.warn("[wrapped] narrative generation failed", err);
      return FALLBACK_NARRATIVES(s.year);
    }
  }, [names]);

  // Kick off narrative load once stats arrive (and only once per couple-year)
  const lastFetchedKey = useRef<string | null>(null);
  useEffect(() => {
    if (!stats) return;
    const key = `${stats.year}_${stats.daysThisYear}_${stats.memories}_${stats.pulses}_${stats.dates}_${stats.capsules}`;
    if (lastFetchedKey.current === key) return;
    lastFetchedKey.current = key;
    setLoadingNar(true);
    void fetchNarratives(stats).then((n) => {
      setNarratives(n);
      setLoadingNar(false);
    });
  }, [stats, fetchNarratives]);

  // ── Slide nav
  const goTo = useCallback((idx: number) => {
    if (idx < 0 || idx >= TOTAL_SLIDES) return;
    haptic("light");
    setSlide(idx);
  }, []);
  const next = useCallback(() => goTo(slide + 1), [slide, goTo]);
  const prev = useCallback(() => goTo(slide - 1), [slide, goTo]);

  const showNav = slide > 0 && slide < TOTAL_SLIDES - 1;

  // ── Touch swipe support
  const touchStart = useRef<number | null>(null);
  const onTouchStart = (e: React.TouchEvent) => { touchStart.current = e.touches[0].clientX; };
  const onTouchEnd   = (e: React.TouchEvent) => {
    if (touchStart.current == null) return;
    const diff = touchStart.current - e.changedTouches[0].clientX;
    touchStart.current = null;
    if (Math.abs(diff) < 50) return;
    if (diff > 0) next(); else prev();
  };

  // ── Render helpers
  const Stars = ({ count = 60 }: { count?: number }) => {
    // Generated once per mount; deterministic-enough random positions.
    const stars = useMemo(() => Array.from({ length: count }, (_, i) => ({
      key: i,
      size: Math.random() * 2 + 1,
      left: Math.random() * 100,
      top:  Math.random() * 100,
      dur:  Math.random() * 3 + 2,
      delay: -Math.random() * 4,
    })), [count]);
    return (
      <div className="tw-stars">
        {stars.map((s) => (
          <div
            key={s.key}
            className="tw-star"
            style={{
              width: s.size,
              height: s.size,
              left: `${s.left}%`,
              top: `${s.top}%`,
              animationDuration: `${s.dur}s`,
              animationDelay: `${s.delay}s`,
            }}
          />
        ))}
      </div>
    );
  };

  const StatSlide = ({
    n, label, value, narrative,
  }: { n: string; label: string; value: number; narrative: string }) => (
    <>
      <div className="tw-slide-number">{n}</div>
      <div className="tw-stat-display">
        <p className="tw-stat-label">{label}</p>
        <p className="tw-stat-number">{value.toLocaleString()}</p>
      </div>
      <p className="tw-narrative">{narrative}</p>
    </>
  );

  // Pre-resolved values for cleaner JSX
  const s = stats;
  const n = narratives;

  return (
    <div className="tw-root" onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
      <div className="tw-stage">
        <AnimatePresence mode="wait">
          <motion.div
            key={slide}
            className="tw-slide"
            style={{ pointerEvents: "all" }}
            initial={{ opacity: 0, x: 60 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -60 }}
            transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
          >
            {/* Slide 0: opening */}
            {slide === 0 && (
              <>
                <Stars />
                <p className="tw-year-label">{year}</p>
                <h1 className="tw-opening-title">{names.join(" & ")}</h1>
                <p className="tw-opening-sub">A year in review</p>
                <p className="tw-opening-days">
                  {s ? `${s.totalDays.toLocaleString()} days tethered` : "…"}
                </p>
                <button className="tw-begin-btn" onClick={next}>Begin ↓</button>
              </>
            )}

            {/* Slide 1: days */}
            {slide === 1 && (
              <StatSlide
                n="01"
                label="Days together this year"
                value={s?.daysThisYear ?? 0}
                narrative={n?.days ?? ""}
              />
            )}
            {/* Slide 2: memories */}
            {slide === 2 && (
              <StatSlide
                n="02"
                label="Memories added"
                value={s?.memories ?? 0}
                narrative={n?.memories ?? ""}
              />
            )}
            {/* Slide 3: pulses */}
            {slide === 3 && (
              <StatSlide
                n="03"
                label="Times you pulsed each other"
                value={s?.pulses ?? 0}
                narrative={n?.pulses ?? ""}
              />
            )}
            {/* Slide 4: dates */}
            {slide === 4 && (
              <StatSlide
                n="04"
                label="Dates planned"
                value={s?.dates ?? 0}
                narrative={n?.dates ?? ""}
              />
            )}
            {/* Slide 5: capsules */}
            {slide === 5 && (
              <StatSlide
                n="05"
                label="Capsules sealed"
                value={s?.capsules ?? 0}
                narrative={n?.capsules ?? ""}
              />
            )}

            {/* Slide 6: AI summary */}
            {slide === 6 && (
              <>
                <div className="tw-slide-number">06</div>
                <p className="tw-summary-label">Your year in words</p>
                <div className="tw-summary-text">
                  {loadingNar || !n ? (
                    <div className="tw-summary-loading">
                      <span /><span /><span />
                    </div>
                  ) : (
                    n.summary
                  )}
                </div>
              </>
            )}

            {/* Slide 7: closing */}
            {slide === 7 && (
              <>
                <Stars count={80} />
                <p className="tw-closing-year">{year} → {year + 1}</p>
                <h2 className="tw-closing-title">Here's to another</h2>
                <div className="tw-closing-names">{names.join(" & ")}</div>
                <p className="tw-closing-brand">Tether · A DelKen Tech service</p>
                <button className="tw-close-btn" onClick={() => onBack?.()}>
                  Close ✦
                </button>
              </>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Nav strip */}
      <div className={`tw-nav ${showNav ? "visible" : ""}`}>
        <button
          className="tw-nav-btn"
          onClick={prev}
          disabled={slide <= 0}
          aria-label="Previous slide"
        >
          ←
        </button>
        <div className="tw-progress-dots">
          {Array.from({ length: TOTAL_SLIDES }).map((_, i) => (
            <div key={i} className={`tw-progress-dot ${i === slide ? "active" : ""}`} />
          ))}
        </div>
        <button
          className="tw-nav-btn"
          onClick={next}
          disabled={slide >= TOTAL_SLIDES - 1}
          aria-label="Next slide"
        >
          →
        </button>
      </div>
    </div>
  );
}
