import { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { haptic, type HapticPattern } from "@/lib/haptics";
import CouplesCornerPage from "./CouplesCornerPage";
import TriviaPage from "./TriviaPage";
import TwoTruthsPage from "./TwoTruthsPage";
import TetherWrappedPage from "./TetherWrappedPage";
import AfterDarkPage from "./AfterDarkPage";
import { GamesLoadingScreen } from "@/components/GamesLoadingScreen";
import { DailyConnectionGame } from "@/components/DailyConnectionGame";
import { TetherStrike } from "@/components/TetherStrike";

// Tether Wrapped is only visible Dec 25 → Jan 1 each year. For QA
// outside that window, set `localStorage.tether_wrapped_force = "1"`.
function isWrappedSeason(): boolean {
  try {
    if (typeof localStorage !== "undefined" && localStorage.getItem("tether_wrapped_force") === "1") {
      return true;
    }
  } catch { /* ignore */ }
  const now = new Date();
  const month = now.getMonth();
  const day   = now.getDate();
  return (month === 11 && day >= 25) || (month === 0 && day <= 1);
}

// ── Game definitions ───────────────────────────────────────────────
//
// Each game owns: the painted card art (`cardClass` → games-hub.css),
// the catalogue text shown on the card front, whether it's locked,
// and the React component to render once the flip completes.
//
// Order intentionally mirrors the spec: Couples Corner → Two Truths
// → Trivia → Daily Connection → Red Light Matrix (locked) → and
// Tether Wrapped appended only during its window.
type Game = {
  id:        string;
  name:      string;
  category:  string;
  cardClass: string;
  locked?:   boolean;
  seasonal?: boolean;
  /** Extra art elements painted on top of `card-art` (e.g. animated glow). */
  artExtras?: { type: "glow" | "compass" | "particles" }[];
  /** Per-game tap haptic — gives each game its own "feel" on press
   *  (e.g. sharp tap for Strike, soft heartbeat for Couples Corner). */
  tapHaptic?: HapticPattern;
};

const GAMES: Game[] = [
  {
    id:        "corner",
    name:      "Couples Corner",
    category:  "Mystery & Magic",
    cardClass: "card-couples-corner",
    artExtras: [{ type: "glow" }, { type: "particles" }],
    tapHaptic: "heartbeat",   // soft lub-dub for the romance card
  },
  {
    id:        "twotruths",
    name:      "Two Truths One Lie",
    category:  "Mind Games",
    cardClass: "card-two-truths",
    tapHaptic: "error",       // double-strike — bluff-detection beat
  },
  {
    id:        "trivia",
    name:      "Trivia",
    category:  "How Well Do You Know",
    cardClass: "card-trivia",
    artExtras: [{ type: "compass" }],
    tapHaptic: "medium",
  },
  {
    id:        "daily-connection",
    name:      "Daily Connection",
    category:  "Connect & Explore",
    cardClass: "card-daily-connection",
    tapHaptic: "soft",
  },
  {
    id:        "after-dark",
    name:      "After Dark",
    category:  "Private. Intimate. No Filters.",
    cardClass: "card-after-dark",
    tapHaptic: "heavy",       // long, deliberate pulse
  },
  {
    id:        "strike",
    name:      "Tether Strike",
    category:  "Cross-Device Air Hockey",
    cardClass: "card-strike",
    artExtras: [{ type: "glow" }],
    tapHaptic: "tap",         // sharp featherlight hit
  },
  {
    id:        "matrix",
    name:      "Red Light Matrix",
    category:  "Explore Together",
    cardClass: "card-red-light",
    locked:    true,
  },
  {
    id:        "wrapped",
    name:      "Tether Wrapped",
    category:  "Just for Two",
    cardClass: "card-wrapped",
    seasonal:  true,
    tapHaptic: "celebration",
  },
];

function getVisibleGames(): Game[] {
  return GAMES.filter(g => !g.seasonal || isWrappedSeason());
}

// ── Static card art (CSS-painted via games-hub.css) ────────────────
//
// Each card's signature decoration (silhouettes, masks, compass,
// infinity, etc.) is purely CSS. This component just emits the
// stable DOM hooks the painted classes attach to.
function CardArt({ game }: { game: Game }) {
  const particles = useMemo(() => {
    if (!game.artExtras?.some(e => e.type === "particles")) return [];
    return Array.from({ length: 6 }).map((_, i) => ({
      key:  i,
      left: 20 + Math.random() * 60,
      bottom: 20 + Math.random() * 30,
      dur:  Math.random() * 2 + 1.5,
      del:  Math.random() * 2,
    }));
  }, [game.artExtras]);

  return (
    <div className="card-art">
      {game.artExtras?.map((e, i) => {
        if (e.type === "glow")    return <div key={i} className="card-glow" />;
        if (e.type === "compass") return <div key={i} className="card-compass" />;
        return null;
      })}
      {particles.map(p => (
        <span
          key={p.key}
          className="card-particle"
          style={{
            left: `${p.left}%`,
            bottom: `${p.bottom}%`,
            animationDuration: `${p.dur}s`,
            animationDelay:    `${p.del}s`,
          }}
        />
      ))}
    </div>
  );
}

// ── Single grid card ───────────────────────────────────────────────
function GridCard({
  game, illuminating, onTap, cardRef, index,
}: {
  game: Game;
  illuminating: boolean;
  onTap: () => void;
  cardRef: (el: HTMLDivElement | null) => void;
  /** Position in the visible games list — drives the staggered
   * flicker entry animation. */
  index: number;
}) {
  return (
    <motion.div
      ref={cardRef}
      className={`ghp-card ${game.cardClass}${game.locked ? " locked" : ""}${illuminating ? " illuminating" : ""}`}
      data-game-id={game.id}
      initial={{ opacity: 0, y: 14, scale: 0.96 }}
      animate={{
        // "Flicker into existence" — quick on/off bursts before
        // settling, like neon catching. Sequenced left → right via
        // the per-card delay below.
        opacity: [0, 1, 0.25, 1, 0.6, 1],
        y: 0,
        scale: 1,
      }}
      transition={{
        duration: 0.7,
        delay: index * 0.09,
        ease: "easeOut",
        times: [0, 0.25, 0.45, 0.65, 0.82, 1],
      }}
      onClick={() => { if (!game.locked) onTap(); }}
    >
      <div className="ghp-card-face">
        {/* Layer 1 — Nebula: per-game themed mesh gradient that
         * slowly drifts behind the painted art. Sits at the very
         * back of the stack so transparent areas of the art reveal
         * the colored aura. Scaled to 1.2 so it can drift with a
         * parallax "window" feel without showing edges. */}
        <div className="ghp-card-nebula" aria-hidden />
        {/* Layer 1b — Per-game cinematic motion accent (cosmic
         * streaks, light leaks, drifting glyphs, bokeh). */}
        <div className="ghp-card-cine" aria-hidden />
        <CardArt game={game} />
        <div className="card-overlay" />
        {/* Per-game "Live Cover" — each card class targets this layer
         * with its own looping animation (puck streak, smoke pulse,
         * rotating ?, glitch split, heartbeat ring). */}
        <div className="ghp-card-live" aria-hidden />
        {/* Layer 3 — Specular: a diagonal white-to-transparent
         * gradient that sweeps across the card when it locks into
         * focus, simulating real light hitting glass. */}
        <div className="ghp-card-spec" aria-hidden />
        <div className="ghp-card-illuminate" />

        {game.locked && (
          <div className="ghp-card-locked-label">
            <span className="ghp-card-locked-icon">🔒</span>
            <span className="ghp-card-locked-text">{"Release Date\nComing Soon"}</span>
          </div>
        )}
      </div>
    </motion.div>
  );
}

// ── Card flip transition layer ─────────────────────────────────────
//
// Mounted once per launch. Renders a fixed-positioned 3D-preserved
// card that:
//   1. Starts at the tapped card's exact rect (front face visible).
//   2. Flips from rotateY 0 → 180 while simultaneously growing to
//      cover the whole viewport.
//   3. Once flipped, the front face is hidden behind, and the back
//      face (dark loading spinner) sits in front.
//   4. After ~1.1s the parent unmounts the FlipLayer and renders
//      the actual game underneath.
//
// `direction === 'reverse'` plays the same animation backwards so
// the back-button feels like the card flipping back into the grid.
type FlipState = {
  rect: { left: number; top: number; width: number; height: number };
  game: Game;
  direction: "open" | "reverse";
};

function FlipLayer({
  state, onComplete,
}: {
  state: FlipState;
  onComplete: () => void;
}) {
  // Compute open- and closed-position styles up-front so we can
  // interpolate purely with framer-motion's animate prop.
  const closed = {
    left:   state.rect.left,
    top:    state.rect.top,
    width:  state.rect.width,
    height: state.rect.height,
    rotateY: 0,
    borderRadius: 14,
    boxShadow:    "0 4px 20px rgba(0,0,0,0.4)",
  };
  const open = {
    left:   0,
    top:    0,
    width:  typeof window !== "undefined" ? window.innerWidth  : 360,
    height: typeof window !== "undefined" ? window.innerHeight : 640,
    rotateY: 180,
    borderRadius: 0,
    boxShadow:    "0 0 80px rgba(0,0,0,0.8)",
  };

  const from = state.direction === "open" ? closed : open;
  const to   = state.direction === "open" ? open   : closed;

  // We let framer-motion drive the handshake via
  // `onAnimationComplete` so there is no possibility of the parent
  // unmounting the FlipLayer before the rotateY/grow animation has
  // truly settled (avoids a flicker if the user spam-taps Back).
  return (
    <div className="cfc-wrap active">
      <motion.div
        className="cfc-card"
        initial={from}
        animate={to}
        transition={{ duration: 0.7, ease: [0.4, 0, 0.2, 1] }}
        onAnimationComplete={onComplete}
      >
        {/* Front face — clones the card art class so the source card
            visually persists through the flip. */}
        <div className={`cfc-front ghp-card-face ${state.game.cardClass}`}>
          <CardArt game={state.game} />
          <div className="card-overlay" />
          <div className="ghp-card-label">{state.game.category}</div>
          <div className="ghp-card-name">{state.game.name}</div>
        </div>

        {/* Back face — dark loader. */}
        <div className="cfc-back">
          <div className="cfc-spinner" />
        </div>
      </motion.div>
    </div>
  );
}

// ── Game overlay (the launched game itself) ────────────────────────
function GameOverlay({
  game, onBack,
}: {
  game: Game;
  onBack: () => void;
}) {
  return (
    <motion.div
      key={game.id}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.25, ease: "easeOut" }}
      style={{
        position: "absolute", inset: 0,
        background: "#000000", zIndex: 50,
        display: "flex", flexDirection: "column",
        overflow: "hidden",
      }}
    >
      {/* Back button */}
      <div style={{
        flexShrink: 0,
        position: "sticky",
        top: 0,
        paddingTop: "max(16px, calc(env(safe-area-inset-top, 16px) + 8px))",
        paddingLeft: 16, paddingRight: 16,
        paddingBottom: 8,
        background: "#000000",
        zIndex: 20,
      }}>
        <motion.button
          onClick={() => { haptic("light"); onBack(); }}
          whileTap={{ scale: 0.88 }}
          style={{
            display: "flex", alignItems: "center", gap: 6,
            padding: "7px 14px 7px 10px",
            borderRadius: 20,
            background: "rgba(255,255,255,0.06)",
            backdropFilter: "blur(12px)",
            WebkitBackdropFilter: "blur(12px)",
            border: "1px solid rgba(255,255,255,0.18)",
            color: "rgba(255,255,255,0.85)", cursor: "pointer",
            fontFamily: "'Quicksand', sans-serif",
            fontWeight: 700, fontSize: "0.8rem",
          }}
        >
          <span style={{ fontSize: "1rem", lineHeight: 1 }}>‹</span>
          Games Hub
        </motion.button>
      </div>

      {/* Game body */}
      <div style={{ flex: 1, overflow: "auto" }}>
        {game.id === "corner"           && <CouplesCornerPage />}
        {game.id === "trivia"           && <TriviaPage />}
        {game.id === "twotruths"        && <TwoTruthsPage />}
        {game.id === "daily-connection" && <DailyConnectionGame />}
        {game.id === "after-dark"       && <AfterDarkPage />}
        {game.id === "strike"           && <TetherStrike />}
        {game.id === "wrapped"          && <TetherWrappedPage onBack={onBack} />}
      </div>
    </motion.div>
  );
}

// ── Main GamesHubPage ──────────────────────────────────────────────
export default function GamesHubPage() {
  const [loadingDone, setLoadingDone] = useState(false);
  const [illuminatingId, setIlluminatingId] = useState<string | null>(null);
  const [flip, setFlip]               = useState<FlipState | null>(null);
  const [activeGame, setActiveGame]   = useState<Game | null>(null);

  // Refs to each card so we can read their bounding rect on tap.
  const cardRefs = useRef<Map<string, HTMLDivElement | null>>(new Map());
  // Refs to each carousel item wrapper so we can compute distance
  // from viewport center on scroll.
  const itemRefs = useRef<Map<string, HTMLDivElement | null>>(new Map());
  const carouselRef = useRef<HTMLDivElement | null>(null);

  const visibleGames = useMemo(getVisibleGames, []);

  // ── visionOS focus tracking ──
  // Tracks which carousel card is closest to the horizontal center
  // of the scroll viewport. Updated on every scroll frame via rAF
  // throttle. Drives the .focused / .unfocused classes that scale
  // and blur cards, and fires a soft snap-haptic when focus shifts.
  const [focusedId, setFocusedId] = useState<string | null>(null);
  const focusedRef = useRef<string | null>(null);
  const rafRef = useRef<number | null>(null);

  function recomputeFocus() {
    rafRef.current = null;
    const carousel = carouselRef.current;
    if (!carousel) return;
    const cRect = carousel.getBoundingClientRect();
    const center = cRect.left + cRect.width / 2;
    let bestId: string | null = null;
    let bestDist = Infinity;
    itemRefs.current.forEach((el, id) => {
      if (!el) return;
      const r = el.getBoundingClientRect();
      const mid = r.left + r.width / 2;
      const dist = Math.abs(mid - center);
      if (dist < bestDist) { bestDist = dist; bestId = id; }
    });
    if (bestId !== focusedRef.current) {
      focusedRef.current = bestId;
      setFocusedId(bestId);
      // Soft snap-haptic when focus genuinely changes — the
      // visionOS "click" as a card locks into the spotlight.
      if (bestId) haptic("soft");
    }
  }

  function handleCarouselScroll() {
    if (rafRef.current != null) return;
    rafRef.current = requestAnimationFrame(recomputeFocus);
  }

  // Initial focus computation after mount + on resize.
  useEffect(() => {
    recomputeFocus();
    const onResize = () => recomputeFocus();
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      if (rafRef.current != null) cancelAnimationFrame(rafRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Launch flow: tap → illuminate (180ms) → flip → mount game ──
  function handleCardTap(game: Game) {
    if (game.locked || flip || activeGame) return;
    haptic(game.tapHaptic ?? "medium");
    setIlluminatingId(game.id);

    setTimeout(() => {
      setIlluminatingId(null);
      const el = cardRefs.current.get(game.id);
      if (!el) return;
      const r = el.getBoundingClientRect();
      setFlip({
        rect: { left: r.left, top: r.top, width: r.width, height: r.height },
        game,
        direction: "open",
      });
    }, 180);
  }

  // ── Back flow: tap back button → reverse flip → return to grid ──
  function handleBack() {
    if (!activeGame) return;
    haptic("light");
    const el = cardRefs.current.get(activeGame.id);
    if (!el) {
      // No card to fly back into — just close.
      setActiveGame(null);
      return;
    }
    const r = el.getBoundingClientRect();
    setActiveGame(null);
    setFlip({
      rect: { left: r.left, top: r.top, width: r.width, height: r.height },
      game: activeGame,
      direction: "reverse",
    });
  }

  // When the open-flip finishes, mount the game; the FlipLayer
  // unmounts on the same beat.
  function handleFlipComplete() {
    if (!flip) return;
    if (flip.direction === "open") {
      setActiveGame(flip.game);
    }
    setFlip(null);
  }

  // ── Dock-orb mode for Tether Strike ──────────────────────────
  // When Tether Strike is launched, shrink the bottom dock down
  // to a single glass ball anchored bottom-left so it doesn't
  // crowd the air-hockey table or compete with the mallet for
  // touches in that corner. The morph is pure CSS — see the
  // `body.tsp-dock-orb` rules in index.css. We add the class on
  // mount and ALWAYS strip it on unmount / game close so the
  // dock never gets stuck in orb form if the user navigates away
  // via gesture, page change, hot-reload, etc.
  useEffect(() => {
    const isStrike = activeGame?.id === "strike";
    if (isStrike) {
      document.body.classList.add("tsp-dock-orb");
    } else {
      document.body.classList.remove("tsp-dock-orb");
    }
    return () => {
      document.body.classList.remove("tsp-dock-orb");
    };
  }, [activeGame?.id]);

  return (
    <motion.div style={{
      position: "relative",
      width: "100%",
      height: "100%",
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
    }}
    initial={{ y: 0 }}
    animate={{ y: 0 }}
    transition={{ duration: 0.35, ease: [0.25, 0.46, 0.45, 0.94] }}
    >
      {/* Velvet+leather background */}
      <div className="ghp-bg" />

      {/* Header — slides up via App.tsx, but we keep it here for the
          17+ badge and "TAP A CARD TO PLAY" which must remain anchored
          to the top of the expanded layout. Its content is hidden when
          the companion header in App.tsx slides up. */}
      <motion.div style={{
        flexShrink: 0,
        padding: "calc(env(safe-area-inset-top, 0px) + 20px) 20px 16px",
        textAlign: "center",
        position: "relative",
        zIndex: 1,
      }}
      initial={{ opacity: 1, y: 0 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.25, 0.46, 0.45, 0.94] }}
      >
        <h1 style={{
          fontFamily: "'Georgia', serif",
          fontSize: "28px",
          fontWeight: 400,
          color: "rgba(255,255,255,0.9)",
          margin: "0 0 4px",
          letterSpacing: "0.06em",
          textShadow: "0 0 30px rgba(180,0,0,0.5)",
        }}>
          Games Hub
        </h1>
        <p style={{
          fontFamily: "'Quicksand', sans-serif",
          fontSize: "10px",
          letterSpacing: "0.2em",
          color: "rgba(255,255,255,0.30)",
          margin: 0,
          textTransform: "uppercase",
        }}>
          Tap a card to play
        </p>

        {/* Floating 17+ age-gate badge — purely decorative chrome
         * matching the premium-card-app aesthetic. Soft red outer
         * glow + a slow breathing pulse so it feels alive. Always
         * visible at the top of the expanded layout. */}
        <div className="ghp-age-badge" aria-hidden>
          <span>17+</span>
        </div>
      </motion.div>

      {/* visionOS-style horizontal Spatial Focus Carousel.
       *
       * One card visible at a time, peeking at neighbors on either
       * side. Scroll-snap mandatory + center alignment locks each
       * card into the spotlight when swiped. The focused card scales
       * up + clears, others scale down + blur. Each card has its own
       * floating frosted-glass title plate hovering below it. */}
      <div
        ref={carouselRef}
        className="ghp-carousel"
        onScroll={handleCarouselScroll}
      >
        {visibleGames.map((game, i) => {
          const isFocused = focusedId === game.id;
          return (
            <div
              key={game.id}
              ref={el => { itemRefs.current.set(game.id, el); }}
              className={`ghp-carousel-item ${isFocused ? "focused" : "unfocused"}`}
              data-game-id={game.id}
            >
              <GridCard
                game={game}
                index={i}
                illuminating={illuminatingId === game.id}
                onTap={() => handleCardTap(game)}
                cardRef={el => { cardRefs.current.set(game.id, el); }}
              />
              {/* Floating frosted-glass title plate, separated from
               * the card by a small gap so the title reads as a
               * distinct surface hovering beneath the artwork. */}
              <div className="ghp-card-plate">
                <div className="ghp-card-plate-label">{game.category}</div>
                <div className="ghp-card-plate-name">{game.name}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Loading screen — shown on initial mount, then unmounts. */}
      <AnimatePresence>
        {!loadingDone && (
          <GamesLoadingScreen onComplete={() => setLoadingDone(true)} />
        )}
      </AnimatePresence>

      {/* Flip transition layer — mounted only during a launch/reverse. */}
      <AnimatePresence>
        {flip && (
          <FlipLayer state={flip} onComplete={handleFlipComplete} />
        )}
      </AnimatePresence>

      {/* Active game overlay — mounted after open-flip completes. */}
      <AnimatePresence>
        {activeGame && (
          <GameOverlay game={activeGame} onBack={handleBack} />
        )}
      </AnimatePresence>
    </motion.div>
  );
}
