/**
 * After Dark — deck data
 * ────────────────────────────────────────────────────────────────────
 * Private, intimate game for the couple. Three escalating decks.
 *
 * NO AI: every prompt is hand-written. Cards are intentionally
 * gender-neutral and orientation-neutral — every prompt addresses
 * "you" and "me" / "us" / "your partner" so the deck applies to
 * any couple regardless of identity. Names and gendered nouns are
 * deliberately omitted.
 *
 * Card schema:
 *   id      — stable string used to dedupe within a session.
 *   type    — visual category badge ("Question" / "Dare" / "Fantasy").
 *   content — the prompt itself.
 */
export type AfterDarkCardType = "Question" | "Dare" | "Fantasy";

export interface AfterDarkCard {
  id:      string;
  type:    AfterDarkCardType;
  content: string;
}

export type AfterDarkDeckKey = "warm-up" | "heat" | "inferno";

export interface AfterDarkDeck {
  key:         AfterDarkDeckKey;
  name:        string;
  rating:      string;
  /** Single accent color used for borders / glow / type badge. */
  accentColor: string;
  /** Soft tagline shown beneath the deck name on the picker. */
  tagline:     string;
  cards:       AfterDarkCard[];
}

// ── Warm Up ────────────────────────────────────────────────────────
const WARM_UP_CARDS: AfterDarkCard[] = [
  { id: "wu-q-1",  type: "Question", content: "What was your very first impression of me when we met?" },
  { id: "wu-q-2",  type: "Question", content: "When did you first know you were falling for me?" },
  { id: "wu-q-3",  type: "Question", content: "What's one thing I do that always makes you smile, even on a hard day?" },
  { id: "wu-q-4",  type: "Question", content: "What's a memory of us that you replay in your head most often?" },
  { id: "wu-q-5",  type: "Question", content: "If you could relive one of our dates exactly as it happened, which one would it be?" },
  { id: "wu-q-6",  type: "Question", content: "What's the most romantic thing I've ever said to you?" },
  { id: "wu-d-1",  type: "Dare",     content: "Whisper something you've been wanting to tell me in my ear for 30 seconds." },
  { id: "wu-d-2",  type: "Dare",     content: "Look me in the eyes for one full minute without speaking." },
  { id: "wu-d-3",  type: "Dare",     content: "Tell me three things you find attractive about me right now." },
  { id: "wu-d-4",  type: "Dare",     content: "Give me a slow hug and don't let go until I do." },
  { id: "wu-d-5",  type: "Dare",     content: "Kiss me somewhere you've never kissed me before." },
  { id: "wu-d-6",  type: "Dare",     content: "Send me a voice note right now saying what you love about us." },
];

// ── Heat ───────────────────────────────────────────────────────────
const HEAT_CARDS: AfterDarkCard[] = [
  { id: "ht-q-1", type: "Question", content: "What's one thing I do that instantly turns you on?" },
  { id: "ht-q-2", type: "Question", content: "Where on your body do you most love being kissed?" },
  { id: "ht-q-3", type: "Question", content: "What outfit of mine has the strongest effect on you?" },
  { id: "ht-q-4", type: "Question", content: "Describe the best kiss we've ever shared." },
  { id: "ht-q-5", type: "Question", content: "What's something I do in bed that you wish I'd do more often?" },
  { id: "ht-f-1", type: "Fantasy",  content: "Describe a scenario you've thought about with me but haven't mentioned yet." },
  { id: "ht-f-2", type: "Fantasy",  content: "Pick a place — not our bed — where you'd want to be alone with me right now. Describe it." },
  { id: "ht-f-3", type: "Fantasy",  content: "If you could undress me anywhere in the world, where would it be and why?" },
  { id: "ht-f-4", type: "Fantasy",  content: "Describe a hotel-room weekend with me. What's the first thing that happens after the door closes?" },
  { id: "ht-d-1", type: "Dare",     content: "Kiss me the way you'd want to be kissed if we were alone right now." },
  { id: "ht-d-2", type: "Dare",     content: "Show me — slowly — exactly where you most like to be touched." },
  { id: "ht-d-3", type: "Dare",     content: "Take off one piece of my clothing using only your teeth." },
];

// ── Inferno ────────────────────────────────────────────────────────
const INFERNO_CARDS: AfterDarkCard[] = [
  { id: "if-q-1", type: "Question", content: "What's the filthiest thing you've thought about doing with me but haven't said out loud?" },
  { id: "if-q-2", type: "Question", content: "What position do you wish we'd do more often, and why?" },
  { id: "if-q-3", type: "Question", content: "Be honest — do you want to take the lead, follow my lead, or trade off tonight?" },
  { id: "if-q-4", type: "Question", content: "What's a kink of yours I might not know about yet?" },
  { id: "if-f-1", type: "Fantasy",  content: "Describe in detail a roleplay scenario you'd want to act out with me — characters, setting, what happens." },
  { id: "if-f-2", type: "Fantasy",  content: "We're locked in a hotel suite for 24 hours with no rules. Walk me through how the first hour goes." },
  { id: "if-f-3", type: "Fantasy",  content: "Tell me a fantasy where I'm completely in charge — what do I make you do?" },
  { id: "if-f-4", type: "Fantasy",  content: "Tell me a fantasy where you're completely in charge — what do you make me do?" },
  { id: "if-f-5", type: "Fantasy",  content: "Describe a scene where we're caught between needing to stay quiet and not being able to." },
  { id: "if-d-1", type: "Dare",     content: "Show me, with your hands on me, exactly how you want to be touched right now." },
  { id: "if-d-2", type: "Dare",     content: "Whisper the dirtiest thing you can think of into my ear." },
  { id: "if-d-3", type: "Dare",     content: "Strip one item of clothing off the other person — your choice which one and how." },
  { id: "if-d-4", type: "Dare",     content: "Pin me down for 30 seconds and tell me what you'd do if we had all night." },
  { id: "if-d-5", type: "Dare",     content: "Send me the most explicit text you've ever wanted to send me. Right now. From across the room." },
];

export const AFTER_DARK_DECKS: Record<AfterDarkDeckKey, AfterDarkDeck> = {
  "warm-up": {
    key:         "warm-up",
    name:        "Warm Up",
    rating:      "MA15+",
    accentColor: "#a855f7",
    tagline:     "Playful. Soft. Easy to start.",
    cards:       WARM_UP_CARDS,
  },
  "heat": {
    key:         "heat",
    name:        "Heat",
    rating:      "R",
    accentColor: "#f43f5e",
    tagline:     "Sensual. Honest. The temperature climbs.",
    cards:       HEAT_CARDS,
  },
  "inferno": {
    key:         "inferno",
    name:        "Inferno",
    rating:      "XXX",
    accentColor: "#ef4444",
    tagline:     "Uncensored. No filters. Just us.",
    cards:       INFERNO_CARDS,
  },
};

export const AFTER_DARK_DECK_ORDER: AfterDarkDeckKey[] = ["warm-up", "heat", "inferno"];
