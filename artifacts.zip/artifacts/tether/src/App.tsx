import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { motion, AnimatePresence, LayoutGroup, useMotionValue, animate } from "framer-motion";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider, useAuth } from "@/lib/AuthContext";
import { ThemeProvider } from "@/components/ThemeProvider";
import { ThemeDecorations } from "@/components/ThemeDecorations";
import { DynamicIsland } from "@/components/DynamicIsland";
import { usePulseIsland } from "@/hooks/usePulseIsland";
import { haptic } from "@/lib/haptics";
import { playSound, warmAudio } from "@/lib/audioManager";
import LoginPage from "@/pages/LoginPage";
import HomePage from "@/pages/HomePage";
import ScrapbookPage from "@/pages/ScrapbookPage";
import DatePlannerPage from "@/pages/DatePlannerPage";
import CapsulesPage from "@/pages/CapsulesPage";
import GamesHubPage from "@/pages/GamesHubPage";
import ProfilePage from "@/pages/ProfilePage";
import confetti from "canvas-confetti";
import { registerServiceWorker, setupPushNotifications } from "@/lib/notifications";
import { supabase } from "@/lib/supabaseClient";
import { TetherAura } from "@/components/TetherAura";
import { SensorSyncIcon } from "@/components/SensorSyncIcon";
import { VIBES } from "@/components/VibeCheckSection";
import { EditModeProvider } from "@/lib/EditModeContext";
import { SafeViewProvider, useSafeView } from "@/lib/safeView";
import { AppGuideMenu } from "@/components/AppGuideMenu";
import { EditModeFooter } from "@/components/EditModeFooter";
import { useViewportFix } from "@/hooks/useViewportFix";
import { useLgParallax } from "@/hooks/useLgParallax";
import { SplashScreen } from "@/components/SplashScreen";
import { RippleOverlay } from "@/components/RippleOverlay";
import { SettingsPage } from "@/pages/SettingsPage";
import { PageErrorBoundary } from "@/components/PageErrorBoundary";
import { WelcomeGuide } from "@/components/welcome/WelcomeGuide";
import { AgeGate } from "@/components/AgeGate";
import {
  HomeNavIcon,
  ScrapbookNavIcon,
  GamesNavIcon,
  UsNavIcon,
  DatesNavIcon,
  CapsulesNavIcon,
  SettingsNavIcon,
} from "@/components/NavIcons";
import {
  HeartbeatPulseBorder,
  triggerHeartbeatPulse,
} from "@/components/HeartbeatPulseBorder";
import { MeshGradientBackground } from "@/components/MeshGradientBackground";
import { LiquidRealism } from "@/components/LiquidRealism";
import { BeachShoreline } from "@/components/BeachShoreline";
import { ContactHigh } from "@/components/ContactHigh";

type Tab = "home" | "scrapbook" | "dates" | "games" | "capsules" | "profile" | "settings";

// ── Dock notification system ─────────────────────────────────────────
// Tabs that surface "new content from your partner" — the matching
// dock button glows until the user navigates to that section. Only the
// 4 content sections are tracked (home/profile have no incoming partner
// content of this nature).
type NotifTab = "scrapbook" | "dates" | "games" | "capsules";

// Maps each notif-tracked tab to its supabase table + the column that
// holds the author's user id. `userCol: null` means we cannot tell who
// authored the row, so we fall back to "if you weren't on this tab when
// the row appeared, it's probably from your partner."
const NOTIF_TABLES: Record<NotifTab, { table: string; userCol: string | null }> = {
  scrapbook: { table: "posts",          userCol: "author_id" },
  dates:     { table: "date_plans",     userCol: null        },
  games:     { table: "trivia_answers", userCol: "user_id"   },
  capsules:  { table: "time_capsules",  userCol: "sender_id" },
};

const SEEN_KEY = (tab: NotifTab) => `tether_seen_${tab}`;

// Left-to-right order of tabs — used to derive slide direction on navigation
const TAB_ORDER: Record<Tab, number> = {
  home: 0, scrapbook: 1, dates: 2, games: 3, capsules: 4, profile: 5, settings: 6,
};

// ── Page transition variants — Liquid Morph ─────────────────────────
// Each new page "settles" into the screen glass: it scales 0.98 → 1.0
// while opacity fades in.  Exiting page mirrors the motion.  No
// directional sliding — the UI feels like it's resolving in-place
// rather than swapping.  `dir` retained for backward compat / future use.
const PAGE_VARIANTS = {
  enter: (_dir: number) => ({
    opacity: 0,
    scale:   0.98,
    filter:  "blur(6px)",
  }),
  center: {
    opacity: 1,
    scale:   1,
    filter:  "blur(0px)",
  },
  exit: (_dir: number) => ({
    opacity: 0,
    scale:   0.98,
    filter:  "blur(4px)",
  }),
};

const PAGE_TRANSITION = {
  opacity: { duration: 0.32, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] },
  scale:   { duration: 0.42, ease: [0.22, 1, 0.36, 1] as [number, number, number, number] },
  filter:  { duration: 0.30 },
};

// ── Shared date constants ───────────────────────────────────────────
// Legacy fallback start date for the original Tether (Kyle & Nathan,
// invite code 070425) when their `tether.start_date` column hasn't
// been backfilled yet. New couples get their real start_date from the
// onboarding wizard and never hit this fallback.
const ANNIVERSARY = new Date("2025-04-07");

function daysTogether(since: Date): number {
  const now = new Date(); now.setHours(0, 0, 0, 0);
  const s   = new Date(since); s.setHours(0, 0, 0, 0);
  return Math.floor((now.getTime() - s.getTime()) / (1000 * 60 * 60 * 24));
}

// Legacy birthday fallback for Kyle & Nathan (pre-onboarding-v1).
// New users have `profiles.birthday` set during sign-up; we prefer that
// when present and only fall back to this map for the original couple.
const BIRTHDAYS: Record<string, { month: number; day: number }> = {
  nathan: { month: 3, day: 16 },
  kyle:   { month: 1, day: 7  },
};

// Parse an ISO `YYYY-MM-DD` date string into {month, day} without
// timezone drift. Returns null if the input is missing or malformed.
function parseBirthdayISO(iso: string | null | undefined): { month: number; day: number } | null {
  if (!iso) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  if (!m) return null;
  return { month: Number(m[2]), day: Number(m[3]) };
}
const CONFETTI_KEY_PREFIX = "tether_birthday_confetti_";

function triggerBirthdayConfetti() {
  const duration = 4500;
  const end = Date.now() + duration;
  const colors = ["#C53030", "#ffffff", "#ffd700", "#ff69b4", "#7B1313"];
  (function frame() {
    confetti({ particleCount: 7, angle: 60, spread: 58, origin: { x: 0 }, colors });
    confetti({ particleCount: 7, angle: 120, spread: 58, origin: { x: 1 }, colors });
    if (Date.now() < end) requestAnimationFrame(frame);
  })();
}

// ── Trivia sparkle-star icon ───────────────────────────────────────
function SparkleStar({ size = 22, color = "currentColor" }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M12 2l2.09 6.26L20 9.27l-4.95 4.82L16.18 21 12 17.77 7.82 21l1.13-6.91L4 9.27l5.91-1.01L12 2z"
        fill={color}
        fillOpacity="0.9"
      />
      <circle cx="12" cy="12" r="2.5" fill={color} fillOpacity="0.35" />
      <line x1="12" y1="1" x2="12" y2="3.5"  stroke={color} strokeWidth="1.5" strokeLinecap="round" />
      <line x1="12" y1="20.5" x2="12" y2="23" stroke={color} strokeWidth="1.5" strokeLinecap="round" />
      <line x1="1"  y1="12"  x2="3.5" y2="12" stroke={color} strokeWidth="1.5" strokeLinecap="round" />
      <line x1="20.5" y1="12" x2="23" y2="12" stroke={color} strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

// ── Profile Mirror nav icon ────────────────────────────────────────
function ProfileMirrorIcon({ active }: { active: boolean }) {
  const color = active ? "#ffffff" : "rgba(147,197,253,0.55)";
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="10" cy="6.5" r="3.5" stroke={color} strokeWidth="1.4" fill="none" />
      <path d="M3 17.5c0-3.314 3.134-6 7-6s7 2.686 7 6" stroke={color} strokeWidth="1.4" strokeLinecap="round" fill="none" />
    </svg>
  );
}

// ── Capsule Orb nav icon ───────────────────────────────────────────
function CapsuleOrb({ active }: { active: boolean }) {
  const color = active ? "#ffffff" : "rgba(147,197,253,0.55)";
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="10" cy="10" rx="7" ry="7" stroke={color} strokeWidth="1.4" fill="none" />
      <ellipse cx="10" cy="10" rx="3.5" ry="3.5" fill={color} fillOpacity={active ? 0.9 : 0.5} />
      <line x1="10" y1="3" x2="10" y2="17" stroke={color} strokeWidth="1" strokeOpacity="0.35" />
      <line x1="3" y1="10" x2="17" y2="10" stroke={color} strokeWidth="1" strokeOpacity="0.35" />
    </svg>
  );
}

// ── Liquid Glass Nav Tab ───────────────────────────────────────────
// renderIcon receives `active` so callers can tint custom SVG icons.
// The active glass bubble lives separately (DraggableNavBubble) and
// is positioned absolutely over the entire nav bar — not per-tab.
interface NavTabProps {
  icon?: string;
  renderIcon?: (active: boolean) => React.ReactNode;
  label: string;
  active: boolean;
  onClick: () => void;
  /** Tab id used by `data-tab` so external selectors / DOM tools can find it. */
  tabId?: Tab;
  /** When true, partner has unseen content for this section — adds the
   *  `nav-tab-has-new` class which drives the purple glow + dot indicator. */
  hasNew?: boolean;
}

function NavTab({ icon, renderIcon, label, active, onClick, tabId, hasNew }: NavTabProps) {
  // Inactive icon colour bumped from 0.55 → 0.80 alpha so glyphs stay
  // legible against the heavy backdrop blur.  Active stays pure white.
  const iconColor = active ? "#ffffff" : "rgba(199,219,253,0.80)";

  return (
    <motion.button
      onClick={() => {
        haptic("soft");
        onClick();
      }}
      data-tab={tabId}
      className={hasNew ? "nav-tab-has-new" : undefined}
      whileHover={{ scale: 1.06 }}
      whileTap={{ scale: 0.95 }}
      /* Per spec: 150–200 ms ease-out, no bounce.  Tween (not spring)
       * keeps the hover lift quiet and predictable. */
      transition={{ duration: 0.18, ease: [0.22, 1, 0.36, 1] }}
      style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center",
               paddingTop: 6, paddingBottom: 6, gap: 2, position: "relative",
               background: "none", border: "none", cursor: "pointer" }}
    >
      {/* ── Icon — each tab has its own frosted glass circle ── */}
      <motion.span
        className="nav-tab-icon"
        animate={{ scale: active ? 1.10 : 1 }}
        transition={{ type: "spring", stiffness: 400, damping: 22 }}
        style={{
          lineHeight:           1,
          display:              "flex",
          alignItems:           "center",
          justifyContent:       "center",
          width:                38,
          height:               38,
          borderRadius:         "50%",
          position:             "relative",
          zIndex:               1,
          color:                iconColor,
          /* Frosted glass circle — visible only on inactive tabs;
           * the DraggableNavBubble provides the active glass sphere */
          background:           active ? "transparent" : "rgba(255,255,255,0.058)",
          backdropFilter:       active ? "none" : "blur(15px)",
          WebkitBackdropFilter: active ? "none" : "blur(15px)",
          border:               active ? "none" : "1px solid rgba(255,255,255,0.09)",
          /* ── Premium icon polish ──
           * Per Refractive-Material spec: every tab icon carries a
           * `drop-shadow(0 2px 4px rgba(0,0,0,0.5))` so the glyph
           * stays perfectly legible against any background colour
           * the dock might be transmitting through it.  Active state
           * adds a soft white inner glow on top of the legibility
           * shadow so the lit tab looks self-illuminated. */
          filter: active
            ? "drop-shadow(0 2px 4px rgba(0,0,0,0.5)) drop-shadow(0 0 4px rgba(255,255,255,0.55)) drop-shadow(0 0 10px rgba(255,255,255,0.25))"
            : "drop-shadow(0 2px 4px rgba(0,0,0,0.5)) contrast(1.10) brightness(1.05)",
          transition: "filter 0.25s ease-out, color 0.25s ease-out",
        } as React.CSSProperties}
      >
        {renderIcon
          ? renderIcon(active)
          : <span style={{ fontSize: "1.2rem" }}>{icon}</span>}
      </motion.span>

      {/* ── Label ── */}
      <motion.span
        animate={{ color: active ? "#ffffff" : "rgba(199,219,253,0.85)" }}
        transition={{ duration: 0.2 }}
        style={{
          fontSize:       "0.62rem",
          /* Refractive-Material spec: Semibold (600) so labels stay
           * crisp against any colour the dock transmits through. */
          fontWeight:     600,
          letterSpacing:  "0.04em",
          position:       "relative",
          zIndex:         1,
          /* Per spec: a single subtle drop-shadow at
           * `0 2px 4px rgba(0,0,0,0.5)` keeps text legible against
           * the brand-red and brand-blue gradients showing through
           * the glass without ever reading as an effect. */
          textShadow:     active
            ? "0 2px 4px rgba(0,0,0,0.5), 0 0 6px rgba(255,255,255,0.40)"
            : "0 2px 4px rgba(0,0,0,0.5)",
        }}
      >
        {label}
      </motion.span>
    </motion.button>
  );
}

// ── Draggable Liquid Glass Nav Bubble ─────────────────────────────
// A single absolutely-positioned glass capsule that slides across the
// nav pill.  Programmatic navigation springs it to the target tab;
// direct touch-drag uses raw pointer events + setPointerCapture so it
// works reliably on iOS Safari without Framer Motion gesture conflicts.
//
// Vertical: 3 px inset from top & bottom of the nav pill (centred).
// Horizontal: BUBBLE_MARGIN px inset from each tab cell edge.
const TABS_ORDERED: Tab[] = ["home", "scrapbook", "dates", "games", "capsules", "profile", "settings"];
const NAV_COUNT    = TABS_ORDERED.length; // 7
const BUBBLE_MARGIN = 5; // horizontal inset from tab cell edge (each side)
const BUBBLE_V      = 3; // vertical inset from nav pill edge (top & bottom)

interface DraggableNavBubbleProps {
  tab: Tab;
  navigateTo: (t: Tab) => void;
  auraColor: string;
  onSnapComplete: () => void;
  navEl: HTMLElement | null;
}

function DraggableNavBubble({ tab, navigateTo, auraColor, onSnapComplete, navEl }: DraggableNavBubbleProps) {
  const [navWidth, setNavWidth] = useState(0);

  // Measure nav bar width — ResizeObserver keeps it current on rotation
  useEffect(() => {
    if (!navEl) return;
    const measure = () => setNavWidth(navEl.offsetWidth);
    const ro = new ResizeObserver(measure);
    ro.observe(navEl);
    measure();
    return () => ro.disconnect();
  }, [navEl]);

  const tabWidth = navWidth > 0 ? navWidth / NAV_COUNT : 0;
  const bubbleW  = tabWidth > 0 ? tabWidth - BUBBLE_MARGIN * 2 : 0;

  // Absolute left-edge x for each tab
  const snapX = useCallback(
    (idx: number) => idx * tabWidth + BUBBLE_MARGIN,
    [tabWidth],
  );

  const targetX = snapX(TAB_ORDER[tab]);

  // x motion value — animate() tweens it; pointer events set() it directly.
  // scaleX  — bubble elongates 22 % mid-slide (Liquid Bubble stretch).
  // scaleY  — bubble BULGES 25 % vertically while being dragged so it
  //           visibly protrudes above and below the pill perimeter,
  //           matching the iOS 26 reference (image 2 in the brief).
  const x           = useMotionValue(0);
  const scaleX      = useMotionValue(1);
  const scaleY      = useMotionValue(1);
  // pressGlow drives the soft white halo overlay (0 = off, 1 = full).
  // Bumped to 1 on pointerDown over 120 ms, eased back to 0 over 380 ms
  // on release — gives the bubble a quick "pop" of light that fades
  // before you've consciously registered it (premium iOS feel).
  const pressGlow   = useMotionValue(0);
  const initialized = useRef(false);
  const isDragging  = useRef(false);
  const ptrStartX   = useRef(0);   // client x where drag started
  const motStartX   = useRef(0);   // motion value x where drag started
  const lastDragIdx = useRef(TAB_ORDER[tab]);
  // For drag-velocity-driven liquid stretch.
  const lastMoveX   = useRef(0);
  const lastMoveT   = useRef(0);

  // SPEC: Liquid-Bubble morph easing — 300 ms with an overshoot curve.
  // The y-axis 1.5 control point pushes scaleX past 1 mid-flight then
  // settles, giving the pill its trademark "stretch & snap" feel.
  const BUBBLE_DURATION = 0.3;
  const BUBBLE_EASE: [number, number, number, number] = [0.5, 0, 0.5, 1.5];

  // Refractive-Material spec: the active bubble slides into place on
  // a single `cubic-bezier(0.4, 0, 0.2, 1.4)` curve.  The y-axis
  // value of 1.4 overshoots the target by ~5 % before snapping back —
  // a "bouncy spring" feel without the multi-oscillation of physics.
  // 260 ms keeps it within the iOS-pill response window.
  const SNAP_TWEEN = {
    type: "tween" as const,
    duration: 0.26,
    ease: [0.4, 0, 0.2, 1.4] as [number, number, number, number],
  };

  // ── Sync x to targetX on tab change or first width measurement ──
  useEffect(() => {
    if (navWidth === 0) return;
    if (!initialized.current) {
      initialized.current = true;
      x.set(targetX);           // instant on first mount — no boot animation
      return;
    }
    if (isDragging.current) return;
    // Programmatic tab change → spring physics on x for natural snap.
    const ctrlX = animate(x, targetX, {
      ...SNAP_TWEEN,
      onComplete: onSnapComplete,
    });
    // Stretch keyframes — bubble elongates 22% mid-slide, then rebounds.
    const ctrlS = animate(scaleX, [1, 1.22, 1], {
      duration: BUBBLE_DURATION,
      ease:     "easeInOut",
      times:    [0, 0.55, 1],
    });
    // Vertical lift — small 12 % bulge so a tab change reads as a
    // physical "pop" of the lens, not just a horizontal slide.
    const ctrlY = animate(scaleY, [1, 1.12, 1], {
      duration: BUBBLE_DURATION,
      ease:     "easeInOut",
      times:    [0, 0.55, 1],
    });
    return () => { ctrlX.stop(); ctrlS.stop(); ctrlY.stop(); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [targetX, navWidth]);

  if (!navWidth || bubbleW <= 0) return null;

  const minX = BUBBLE_MARGIN;
  const maxX = (NAV_COUNT - 1) * tabWidth + BUBBLE_MARGIN;

  // ── Pointer handlers — bypass Framer Motion gesture system ──
  // setPointerCapture keeps events flowing even when pointer leaves the
  // element (essential for fast swipes across the nav on mobile).
  function onPointerDown(e: React.PointerEvent<HTMLDivElement>) {
    isDragging.current  = true;
    ptrStartX.current   = e.clientX;
    motStartX.current   = x.get();
    lastDragIdx.current = TAB_ORDER[tab];
    lastMoveX.current   = e.clientX;
    lastMoveT.current   = performance.now();
    e.currentTarget.setPointerCapture(e.pointerId);
    haptic("soft");
    // Bulge the lens vertically while being dragged — the bubble
    // visibly protrudes above & below the pill, like a soft jelly
    // being pinched between two fingers (matches iOS 26 reference).
    animate(scaleY, 1.25, { duration: 0.18, ease: [0.34, 1.56, 0.64, 1] });
    // Press glow — soft white halo punches in fast, fades out below.
    animate(pressGlow, 1, { duration: 0.12, ease: "easeOut" });
  }

  function onPointerMove(e: React.PointerEvent<HTMLDivElement>) {
    if (!isDragging.current) return;
    const newX  = Math.max(minX, Math.min(maxX, motStartX.current + (e.clientX - ptrStartX.current)));
    x.set(newX);

    // ── Liquid drag-stretch ────────────────────────────────────────
    // While dragging, the bubble elongates along the drag axis in
    // proportion to instantaneous velocity (px / ms).  Capped so a
    // very fast swipe still tops out at scaleX 1.18 — mimics the way
    // a viscous liquid blob distorts as it's pulled across a surface.
    const now    = performance.now();
    const dt     = Math.max(1, now - lastMoveT.current);
    const vel    = (e.clientX - lastMoveX.current) / dt;   // px/ms, signed
    lastMoveX.current = e.clientX;
    lastMoveT.current = now;
    const stretch = Math.min(0.18, Math.abs(vel) * 0.06);
    // Compress on the cross-axis as it stretches (volume-preserving).
    animate(scaleX, 1 + stretch,         { duration: 0.10, ease: "easeOut" });
    animate(scaleY, 1.25 - stretch * 0.6, { duration: 0.10, ease: "easeOut" });

    // Light haptic tick each time the bubble crosses a tab boundary
    const idx = Math.max(0, Math.min(NAV_COUNT - 1, Math.round((newX - BUBBLE_MARGIN) / tabWidth)));
    if (idx !== lastDragIdx.current) {
      haptic("light");
      lastDragIdx.current = idx;
    }
  }

  function onPointerUp(e: React.PointerEvent<HTMLDivElement>) {
    if (!isDragging.current) return;
    isDragging.current = false;

    const curX      = x.get();
    const nearestIdx = Math.max(0, Math.min(NAV_COUNT - 1, Math.round((curX - BUBBLE_MARGIN) / tabWidth)));
    const target     = snapX(nearestIdx);

    // Spring snap to the nearest tab — same physics as programmatic
    // tab changes, so direct-tap and drag-release feel identical.
    animate(x, target, {
      ...SNAP_TWEEN,
      onComplete: onSnapComplete,
    });
    // Liquid-stretch keyframes layered on the spring snap.
    animate(scaleX, [scaleX.get(), 1.18, 1], {
      duration: 0.40,
      ease:     "easeOut",
      times:    [0, 0.40, 1],
    });
    // Squish-and-rebound the vertical bulge back to rest — the
    // [1.25 → 0.94 → 1] keyframes give the lens its trademark
    // "splat" recovery on release.
    animate(scaleY, [scaleY.get(), 0.94, 1.04, 1], {
      duration: 0.42,
      ease:     "easeOut",
      times:    [0, 0.45, 0.75, 1],
    });
    // Fade the press glow back out — quick enough that you only
    // perceive it as a residual gleam after release.
    animate(pressGlow, 0, { duration: 0.38, ease: "easeOut" });
    navigateTo(TABS_ORDERED[nearestIdx]);
  }

  return (
    <motion.div
      className="liquid-glass-bubble"
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
      style={{
        // ── Layout ──
        position:    "absolute",
        top:          BUBBLE_V,
        bottom:       BUBBLE_V,
        left:         0,
        width:        bubbleW,
        x,
        scaleX,
        scaleY,                         // vertical bulge during drag (see handlers)
        transformOrigin: "50% 50%",
        zIndex:       5,
        borderRadius: "var(--active-pill-radius)",
        touchAction:  "none",
        cursor:       "grab",
        userSelect:   "none",

        // ── iOS 26 Liquid Glass Lens ──
        // All tunables are driven by the `--active-pill-*` CSS custom
        // properties hoisted at the top of `index.css`, so the visual
        // weight of the bubble can be retuned in one place without
        // editing this inline style block.  The pill uses 1.5 × the
        // dock's backdrop blur (per spec) so the active tab visibly
        // reads as a denser, more-refractive piece of glass than the
        // surrounding pill.  Inset shadows give the pill its 3-D edge
        // (bright top, dark bottom, faint inner top drop for thickness),
        // and the SVG #liquid-refract displacement map adds the lens
        // magnification of whatever sits behind it.
        backdropFilter:       "blur(var(--active-pill-blur)) saturate(var(--active-pill-saturate)) brightness(var(--active-pill-brightness)) contrast(var(--active-pill-contrast)) url(#liquid-refract)",
        WebkitBackdropFilter: "blur(var(--active-pill-blur)) saturate(var(--active-pill-saturate)) brightness(var(--active-pill-brightness)) contrast(var(--active-pill-contrast))",
        // ── Refractive Material — Specular Edge & Shine ─────────────
        // 1.2 px gradient border painted via the dual-background mask
        // trick: the `--active-pill-bg` (rgba(255,255,255,0.10) per spec)
        // sits on padding-box, layered under a bright-to-faint white
        // stroke on border-box that traces the rounded rim and reads as
        // a "light-catching" edge.  The inset top highlight (in the
        // boxShadow stack below) adds the sharp specular glint that
        // sells curved glass.
        background: [
          "linear-gradient(var(--active-pill-bg), var(--active-pill-bg)) padding-box",
          "linear-gradient(to bottom, rgba(255,255,255,0.45), rgba(255,255,255,0.05)) border-box",
        ].join(", "),
        border:               "1.2px solid transparent",
        boxShadow: [
          "inset 0 1px 1px rgba(255,255,255,0.30)",   // sharp top-edge specular shine
          "inset 0  2px 4px rgba(0,0,0,0.06)",        // very subtle inner depth shadow
          "inset 0 -1px 0 rgba(0,0,0,0.10)",          // bottom refraction line
          "0 4px 14px rgba(0,0,0,0.18)",              // grounding shadow
          tab === "games"
            ? "0 0 22px 4px rgba(197,48,48,0.40)"
            : `0 0 18px 4px ${auraColor}30`,           // colour-matched aura
        ].join(", "),
        willChange: "transform",
      }}
    >
      {/* Press-glow halo — soft white radial that punches in on
          pointerDown and fades on release.  Sits behind the bubble's
          lens content, expanding 8 px past the rim so the glow looks
          like light bleeding through the glass edge. */}
      <motion.div
        style={{
          position: "absolute",
          inset: -8,
          borderRadius: 24,
          background: "radial-gradient(circle, rgba(255,255,255,0.55) 0%, rgba(255,255,255,0.15) 40%, transparent 70%)",
          opacity: pressGlow,
          pointerEvents: "none",
          zIndex: -1,
          willChange: "opacity",
        }}
      />

      {/* Tab-change sheen — a slim diagonal white-to-transparent strip
          that sweeps across the bubble whenever the active tab changes.
          Re-mounts via `key={tab}` so it plays exactly once per change.
          The CSS `.bubble-sheen-hover` overlay below handles the
          desktop-hover variant of the same effect. */}
      <motion.div
        key={`sheen-${tab}`}
        initial={{ x: "-110%", opacity: 0 }}
        animate={{ x: "110%",  opacity: [0, 0.55, 0] }}
        transition={{ duration: 0.72, ease: [0.22, 1, 0.36, 1] }}
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: "inherit",
          overflow: "hidden",
          pointerEvents: "none",
          background: "linear-gradient(105deg, transparent 35%, rgba(255,255,255,0.45) 50%, transparent 65%)",
          mixBlendMode: "screen",
          willChange: "transform, opacity",
        }}
      />

      {/* Hover-only sheen — pure CSS keyframe sweep on `:hover` of
          `.liquid-glass-bubble`.  Driven entirely by `.bubble-sheen-hover`
          rules in `index.css` so it costs no JS frames. */}
      <span className="bubble-sheen-hover" aria-hidden="true" />

      {/* Pulsing crimson ring when Games tab is active */}
      {tab === "games" && (
        <motion.div
          animate={{ opacity: [0.35, 0.80, 0.35], scale: [0.90, 1.10, 0.90] }}
          transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
          style={{
            position: "absolute", inset: -4, borderRadius: 20,
            border: "1.5px solid rgba(197,48,48,0.75)",
            boxShadow: "0 0 14px 3px rgba(197,48,48,0.40)",
            pointerEvents: "none",
          }}
        />
      )}
    </motion.div>
  );
}

// ── Dock notification hook ─────────────────────────────────────────
// Subscribes to INSERT realtime events on the 4 partner-content tables
// (filtered by tether_id) and tracks per-tab "has unseen content" state.
//
//   • On mount: fetches the latest row id per table and reconciles
//     against localStorage (`tether_seen_<tab>`) — sets initial flags.
//   • On INSERT: if the row was authored by the current user, ignored.
//     If currentTab matches the tab it belongs to, marked seen
//     immediately. Otherwise the tab's flag is raised.
//   • When `currentTab` changes, the corresponding flag (if any) is
//     cleared and that table's latest id is written to localStorage.
//
// Returns a `Record<NotifTab, boolean>` consumed by <NavTab hasNew>.
function useDockNotifications(
  tetherId: string | null | undefined,
  myId: string | null | undefined,
  currentTab: Tab,
): Record<NotifTab, boolean> {
  const [hasNew, setHasNew] = useState<Record<NotifTab, boolean>>({
    scrapbook: false, dates: false, games: false, capsules: false,
  });

  // Mark a single tab as seen — writes the latest id to localStorage and
  // clears the in-memory flag. Stable identity so realtime callbacks
  // can call it without resubscribing.
  const markSeen = useCallback((tab: NotifTab, latestId: string | null) => {
    if (latestId != null) {
      try { localStorage.setItem(SEEN_KEY(tab), String(latestId)); } catch { /* quota / private mode */ }
    }
    setHasNew(prev => (prev[tab] ? { ...prev, [tab]: false } : prev));
  }, []);

  // currentTab needs to be readable inside async callbacks without
  // forcing them to re-run; declared up-front so the reconciliation
  // effect (below) and the realtime subscription effect (further down)
  // can both consult it via ref.
  const currentTabRef = useRef(currentTab);
  useEffect(() => { currentTabRef.current = currentTab; }, [currentTab]);

  // ── Initial reconciliation: fetch the latest id per table and
  //    compare with localStorage. Runs once when tetherId becomes
  //    known. ────────────────────────────────────────────────────────
  useEffect(() => {
    if (!tetherId) return;
    let cancelled = false;

    (async () => {
      const next: Partial<Record<NotifTab, boolean>> = {};

      await Promise.all((Object.keys(NOTIF_TABLES) as NotifTab[]).map(async tab => {
        const { table, userCol } = NOTIF_TABLES[tab];
        const cols = userCol ? `id, ${userCol}` : "id";
        const { data, error } = await supabase
          .from(table)
          .select(cols)
          .eq("tether_id", tetherId)
          .order("created_at", { ascending: false })
          .limit(1);

        if (error || !data || data.length === 0) return;
        // Cast via unknown — supabase's PostgrestSingleResponse types
        // the row union as `T | GenericStringError` which doesn't
        // overlap our generic record shape.
        const row = data[0] as unknown as Record<string, unknown>;
        const latestId = String(row.id);

        // If the latest row was authored by the current user there's
        // nothing "new from the partner" — silently mark seen.
        const author = userCol ? (row[userCol] as string | undefined) : undefined;
        if (author && author === myId) {
          try { localStorage.setItem(SEEN_KEY(tab), latestId); } catch { /* ignore */ }
          return;
        }

        let lastSeen: string | null = null;
        try { lastSeen = localStorage.getItem(SEEN_KEY(tab)); } catch { /* ignore */ }
        // If the user is already viewing this tab, don't raise the
        // flag — the clear-on-navigate effect will mark it seen anyway.
        // Skipping prevents a brief purple-dot flicker on first load.
        if (lastSeen !== latestId && currentTabRef.current !== tab) {
          next[tab] = true;
        }
      }));

      if (cancelled) return;
      if (Object.keys(next).length > 0) {
        setHasNew(prev => ({ ...prev, ...next }));
      }
    })();

    return () => { cancelled = true; };
  }, [tetherId, myId]);

  // ── Realtime: subscribe to INSERTs on each table for this tether.
  //    `currentTabRef` (declared above) lets the callback know which
  //    tab the user is on without re-subscribing on every navigation.
  useEffect(() => {
    if (!tetherId) return;

    const channels = (Object.keys(NOTIF_TABLES) as NotifTab[]).map(tab => {
      const { table, userCol } = NOTIF_TABLES[tab];
      return supabase
        .channel(`dock-notif-${table}-${tetherId}`)
        .on(
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          "postgres_changes" as any,
          { event: "INSERT", schema: "public", table, filter: `tether_id=eq.${tetherId}` },
          (payload: { new: Record<string, unknown> }) => {
            const row = payload.new ?? {};
            const author = userCol ? (row[userCol] as string | undefined) : undefined;
            // Author === me → not a partner notification.
            if (author && author === myId) return;
            const id = row.id != null ? String(row.id) : null;

            // If we're already viewing that tab, mark it seen immediately
            // (no glow needed — they're literally looking at the section).
            if (currentTabRef.current === tab) {
              if (id) {
                try { localStorage.setItem(SEEN_KEY(tab), id); } catch { /* ignore */ }
              }
              return;
            }
            setHasNew(prev => (prev[tab] ? prev : { ...prev, [tab]: true }));
          },
        )
        .subscribe();
    });

    return () => {
      channels.forEach(ch => { supabase.removeChannel(ch); });
    };
  }, [tetherId, myId]);

  // ── Clear the flag whenever the user navigates TO a tracked tab.
  //    Also writes that table's current latest id to localStorage so
  //    future inserts are correctly compared. ───────────────────────
  useEffect(() => {
    if (!tetherId) return;
    if (!(currentTab in NOTIF_TABLES)) return;
    const tab = currentTab as NotifTab;

    let cancelled = false;
    (async () => {
      const { table } = NOTIF_TABLES[tab];
      const { data } = await supabase
        .from(table)
        .select("id")
        .eq("tether_id", tetherId)
        .order("created_at", { ascending: false })
        .limit(1);
      if (cancelled) return;
      const latestId = data && data.length > 0 ? String((data[0] as { id: unknown }).id) : null;
      markSeen(tab, latestId);
    })();

    return () => { cancelled = true; };
  }, [currentTab, tetherId, markSeen]);

  return hasNew;
}

// ── App shell ──────────────────────────────────────────────────────
/**
 * PageFrame — wraps each tab page so the signature CSS entry
 * animation in dynamic-island.css plays on every mount. The
 * `data-page` attribute selects which keyframe runs. Uses flex column
 * + min-height:0 so the wrapped page fills the motion.div slot
 * without affecting the page's own layout.
 */
function PageFrame({ page, children }: { page: string; children: React.ReactNode }) {
  return (
    <div
      data-page={page}
      style={{ flex: 1, minHeight: 0, display: "flex", flexDirection: "column" }}
    >
      {children}
    </div>
  );
}

function AppShell() {
  // Global Liquid-Glass parallax — drives `--lg-px` / `--lg-py` on
  // every element marked `[data-lg-parallax]` or `.lg-parallax`.
  // Single-listener implementation, throttled to rAF, automatically
  // disabled under `prefers-reduced-motion: reduce`.
  useLgParallax();
  // Global pulse listener — fires the Dynamic Island when a partner
  // sends a Love-You, regardless of which tab is active.
  usePulseIsland();

  const { profile, partnerProfile, tether, loading, logout } = useAuth();
  const [tab,           setTab]           = useState<Tab>("home");
  const [prevTab,       setPrevTab]       = useState<Tab>("home");
  const [transitionKey, setTransitionKey] = useState(0);
  const [birthdayBanner, setBirthdayBanner] = useState(false);
  // navEl: reference to the <nav> DOM node, needed by DraggableNavBubble
  // to measure its width via ResizeObserver.  Using state (not ref) means
  // the bubble re-renders once the nav mounts and the measurement is valid.
  const [navEl, setNavEl] = useState<HTMLElement | null>(null);

  // ── Age gate — one-time 17+ confirmation ─────────────────────────
  // Initialise from localStorage so the gate is skipped immediately
  // for any browser where the user has already confirmed. Supabase
  // is used as a durable fallback: once the profile loads and
  // profile.age_verified === true we mirror that into localStorage
  // so subsequent visits on this device are instant.
  const [ageVerified, setAgeVerified] = React.useState<boolean>(() => {
    try { return localStorage.getItem("tether-age-verified") === "true"; } catch { return false; }
  });
  React.useEffect(() => {
    if (profile?.age_verified) {
      setAgeVerified(true);
      try { localStorage.setItem("tether-age-verified", "true"); } catch { /* ignore */ }
    }
  }, [profile?.age_verified]);
  const handleAgeVerified = React.useCallback(() => setAgeVerified(true), []);

  // ── Cursor-tracking specular sheen + dock parallax ──────────────
  // One rAF loop drives THREE custom-property channels on the dock:
  //
  //   1. `--nav-mx` / `--nav-my`  — centre of the radial spotlight
  //      (in % of the dock's bounding box) for the moving highlight
  //      on `.glass-nav::before`.
  //   2. `--nav-px` / `--nav-py`  — small px offset (±5 / ±2) for
  //      the icon parallax — icons drift opposite the cursor.
  //   3. `--dock-tx` / `--dock-ty` — even smaller px offset (±2 / ±1)
  //      applied to the entire dock pill — gives the whole element a
  //      subtle "floating" parallax separate from the icon parallax.
  //
  // Disabled entirely when the user has set
  // `prefers-reduced-motion: reduce` — the dock then stays perfectly
  // still and the resting spotlight position is set once at mount.
  useEffect(() => {
    if (!navEl) return;
    const reduced = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      // Static rest position only — no movement at all.
      navEl.style.setProperty("--nav-mx", "50%");
      navEl.style.setProperty("--nav-my", "-20%");
      navEl.style.setProperty("--nav-px", "0px");
      navEl.style.setProperty("--nav-py", "0px");
      navEl.style.setProperty("--dock-tx", "0px");
      navEl.style.setProperty("--dock-ty", "0px");
      return;
    }

    let rafId = 0;
    let targetX = 50, targetY = -20;
    let curX = 50,    curY = -20;

    const tick = () => {
      // Lerp toward the target so the highlight glides instead of snaps.
      curX += (targetX - curX) * 0.18;
      curY += (targetY - curY) * 0.18;
      navEl.style.setProperty("--nav-mx", `${curX.toFixed(2)}%`);
      navEl.style.setProperty("--nav-my", `${curY.toFixed(2)}%`);
      // Icon parallax — drifts opposite the cursor by ±5/±2 px.
      const px = ((50 - curX) / 50) * 5;
      const py = ((50 - curY) / 50) * 2;
      navEl.style.setProperty("--nav-px", `${px.toFixed(2)}px`);
      navEl.style.setProperty("--nav-py", `${py.toFixed(2)}px`);
      // Whole-dock parallax — much subtler (capped ±2 px X / ±1 px Y)
      // so the pill itself sways gently in the opposite direction.
      const dx = ((50 - curX) / 50) * 2;
      const dy = ((50 - curY) / 50) * 1;
      navEl.style.setProperty("--dock-tx", `${dx.toFixed(2)}px`);
      navEl.style.setProperty("--dock-ty", `${dy.toFixed(2)}px`);
      rafId = requestAnimationFrame(tick);
    };

    const onMove = (e: PointerEvent) => {
      const r = navEl.getBoundingClientRect();
      // Allow a small "halo zone" outside the dock so the highlight
      // begins drifting toward the finger before it actually enters
      // the pill — feels more anticipatory.
      const HALO = 80;
      if (
        e.clientX < r.left - HALO || e.clientX > r.right + HALO ||
        e.clientY < r.top  - HALO || e.clientY > r.bottom + HALO
      ) {
        targetX = 50; targetY = -20;       // resting position
        return;
      }
      targetX = ((e.clientX - r.left) / r.width)  * 100;
      targetY = ((e.clientY - r.top)  / r.height) * 100;
    };

    document.addEventListener("pointermove", onMove, { passive: true });
    rafId = requestAnimationFrame(tick);
    return () => {
      document.removeEventListener("pointermove", onMove);
      cancelAnimationFrame(rafId);
    };
  }, [navEl]);

  // ── Scroll-aware dock reveal ────────────────────────────────────
  // When content is actively scrolling (window OR any inner scrollable
  // ancestor — capture phase catches both), the .glass-nav pill picks
  // up the `.scrolling` class for 800 ms, lightening the background so
  // moving content shows through more clearly. Throttled by clearing
  // the timer on each event.
  useEffect(() => {
    if (!navEl) return;
    let timer: number | null = null;
    const onScroll = () => {
      navEl.classList.add("scrolling");
      if (timer !== null) window.clearTimeout(timer);
      timer = window.setTimeout(() => navEl.classList.remove("scrolling"), 800);
    };
    // capture: true catches scroll events on inner scrollable elements
    // (PullToRefresh wrapper, modal sheets, etc.) since scroll doesn't
    // bubble. passive: true keeps the listener off the main thread path.
    window.addEventListener("scroll", onScroll, { passive: true, capture: true });
    return () => {
      window.removeEventListener("scroll", onScroll, { capture: true } as EventListenerOptions);
      if (timer !== null) window.clearTimeout(timer);
      navEl.classList.remove("scrolling");
    };
  }, [navEl]);

  // ── Partner-content notification flags for the dock ──────────────
  // Drives the purple glow + dot indicator on scrapbook/dates/games/
  // capsules nav buttons whenever the partner has posted new content
  // the current user hasn't seen yet. Cleared automatically when the
  // user navigates to that tab.
  const dockHasNew = useDockNotifications(tether?.id ?? null, profile?.id ?? null, tab);

  // Direction the new page enters from: +1 = right, -1 = left
  const slideDir = TAB_ORDER[tab] >= TAB_ORDER[prevTab] ? 1 : -1;

  // ── Navigate with fluid transition + haptic sync ───────────────
  const navigateTo = useCallback((newTab: Tab) => {
    if (newTab === tab) return;
    setPrevTab(tab);
    setTab(newTab);
    setTransitionKey(k => k + 1);
    // Midpoint haptic fires when the two pages overlap (~120 ms into spring)
    setTimeout(() => haptic("soft"), 120);
  }, [tab]);

  // ── Partner vibe for TetherAura ────────────────────────────────────
  const [partnerVibeId, setPartnerVibeId] = useState<string | null>(
    partnerProfile?.current_vibe ?? null,
  );

  // Sync when partnerProfile first loads
  useEffect(() => {
    setPartnerVibeId(partnerProfile?.current_vibe ?? null);
  }, [partnerProfile?.id, partnerProfile?.current_vibe]);

  // Realtime: watch for vibe changes on partner's profile row
  useEffect(() => {
    if (!partnerProfile?.id) return;
    const channel = supabase
      .channel("aura-vibe-" + partnerProfile.id)
      .on(
        "postgres_changes",
        {
          event:  "UPDATE",
          schema: "public",
          table:  "profiles",
          filter: `id=eq.${partnerProfile.id}`,
        },
        (payload) => {
          const row = payload.new as { current_vibe?: string | null };
          setPartnerVibeId(row.current_vibe ?? null);
        },
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [partnerProfile?.id]);

  // Real start date if the tether has one. Legacy K&N (invite_code
  // 070425) gets the hard-coded ANNIVERSARY fallback so their UI
  // doesn't go missing. Other couples see no days-together strip
  // until they enter their anniversary in Settings → Edit Info.
  const startDate: Date | null = tether?.start_date
    ? new Date(tether.start_date)
    : (tether?.invite_code === "070425" ? ANNIVERSARY : null);
  const together  = startDate ? daysTogether(startDate) : null;
  const isHome    = tab === "home";

  // Safe View: when ON, the partner's mood aura must always render as
  // the calm "Content" vibe regardless of what they actually selected.
  // We DON'T touch `partnerVibeId` itself — Supabase realtime keeps it
  // in sync in the background — we only override the *displayed* vibe,
  // so flipping Safe View off instantly snaps the aura back to the
  // partner's true current vibe.
  const { enabled: safeViewOn } = useSafeView();
  const effectivePartnerVibeId = safeViewOn ? "content" : partnerVibeId;

  // Resolve the partner's vibe color for the liquid-glass pill glow.
  // Falls back to Crimson (#C53030) when no vibe is set.
  const auraColor = useMemo(() => {
    if (!effectivePartnerVibeId) return "#C53030";
    return VIBES.find(v => v.id === effectivePartnerVibeId)?.color ?? "#C53030";
  }, [effectivePartnerVibeId]);

  useEffect(() => {
    const handler = () => warmAudio();
    document.addEventListener("touchstart", handler, { once: true });
    document.addEventListener("pointerdown", handler, { once: true });
    document.addEventListener("click", handler, { once: true });
    return () => {
      document.removeEventListener("touchstart", handler);
      document.removeEventListener("pointerdown", handler);
      document.removeEventListener("click", handler);
    };
  }, []);

  const handleSnapComplete = useCallback(() => { haptic("medium"); playSound("glassClick"); }, []);

  useEffect(() => {
    if (!profile || !tether) return;
    let cancelled = false;
    (async () => {
      const reg = await registerServiceWorker();
      if (cancelled || !reg) return;
      // Always attempt — setupPushNotifications handles the permission prompt
      // internally and is a no-op if the user denies or the API is unavailable.
      await setupPushNotifications(reg, profile.id, tether.id);
    })();
    return () => { cancelled = true; };
  }, [profile, tether]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const screen = params.get("screen") as Tab | null;
    if (screen && TAB_ORDER[screen] !== undefined) {
      navigateTo(screen);
      const url = new URL(window.location.href);
      url.searchParams.delete("screen");
      window.history.replaceState({}, "", url.pathname + url.search);
    }

    const handleSWMessage = (event: MessageEvent) => {
      if (event.data?.type === "TETHER_NAVIGATE") {
        const s = event.data.screen as Tab;
        if (s && TAB_ORDER[s] !== undefined) navigateTo(s);
      }
    };
    navigator.serviceWorker?.addEventListener("message", handleSWMessage);
    return () => {
      navigator.serviceWorker?.removeEventListener("message", handleSWMessage);
    };
  }, [navigateTo]);

  useEffect(() => {
    if (!profile) return;
    // Prefer the explicit profile.birthday set during onboarding;
    // fall back to the legacy hard-coded map ONLY for the original
    // K&N tether (invite_code 070425). Other couples whose names
    // happen to match "kyle" or "nathan" must NOT be assigned K&N's
    // birthdays.
    const explicit = parseBirthdayISO(profile.birthday);
    const isLegacy = tether?.invite_code === "070425";
    const fallback = isLegacy
      ? BIRTHDAYS[(profile.full_name ?? "").toLowerCase()]
      : undefined;
    const bday     = explicit ?? fallback ?? null;
    if (!bday) return;
    const now = new Date();
    const birthdayThis = new Date(now.getFullYear(), bday.month - 1, bday.day);
    const daysSince = Math.floor((now.getTime() - birthdayThis.getTime()) / (1000 * 60 * 60 * 24));
    const isNear = daysSince >= 0 && daysSince <= 3;
    // Key the once-per-year flag on profile.id so it works for any
    // couple regardless of name. Falls back to full_name for safety.
    const key    = CONFETTI_KEY_PREFIX + (profile.id ?? profile.full_name ?? "anon");
    if (isNear && localStorage.getItem(key) !== String(now.getFullYear())) {
      localStorage.setItem(key, String(now.getFullYear()));
      setBirthdayBanner(true);
      setTimeout(() => {
        triggerBirthdayConfetti();
        setTimeout(() => setBirthdayBanner(false), 5500);
      }, 700);
    }
  }, [profile]);

  // ── Splash Screen — Cinematic Entrance ──────────────────────────
  // The splash stays on screen until BOTH (a) auth has finished
  // loading and (b) the splash's own warm-up + expand-out animation
  // has played through.  The cinematic-entry CSS class — which makes
  // every .glass-card on the next screen play a single neon-blue
  // border pulse — is attached only when we are about to actually
  // render app content (both conditions true), so the pulse always
  // lands at the visible hand-off moment regardless of network speed.
  const [splashDone, setSplashDone] = React.useState(false);
  // ── First-time welcome guide ─────────────────────────────────────
  // Shows ONCE after the user lands post-splash. The "Tether Up"
  // button on the final slide (or Skip on any slide) marks the
  // localStorage flag and the overlay never appears again unless
  // the user opens it again from Settings → App Guide.
  const WELCOME_KEY = "tether_welcome_seen_v1";
  const [showWelcome, setShowWelcome] = React.useState(false);
  React.useEffect(() => {
    if (!splashDone || loading || !profile) return;
    // Only auto-show on the Home tab — if the user happens to be on a
    // deep-linked tab when this fires, defer until they're back home.
    if (tab !== "home") return;
    try {
      if (localStorage.getItem(WELCOME_KEY) === "1") return;
    } catch {
      return;
    }
    // Slight delay so the home screen is visibly behind the overlay
    // when it fades in — matches the prompt's 800ms timing.
    const t = setTimeout(() => setShowWelcome(true), 800);
    return () => clearTimeout(t);
  }, [splashDone, loading, profile, tab]);
  const closeWelcome = React.useCallback(() => {
    try {
      localStorage.setItem(WELCOME_KEY, "1");
    } catch {
      /* ignore */
    }
    setShowWelcome(false);
  }, []);

  // App Guide bottom-sheet — opened from Settings → App Guide. Lives
  // at AppShell scope so the menu portal mounts above EVERY in-app
  // screen (not only the Settings tab) and survives tab switches.
  const [showGuideMenu, setShowGuideMenu] = React.useState(false);
  const closeGuideMenu = React.useCallback(() => setShowGuideMenu(false), []);
  // Ripple state — origin is captured from the user's tap on the
  // splash's Enter button so the rings radiate from the exact pixel
  // they touched. Sound is played from inside the SplashScreen's
  // click handler (mandatory for iOS audio unlock); we own the
  // visual + the splash-dismissal here.
  const [showRipple, setShowRipple]     = React.useState(false);
  const [rippleOrigin, setRippleOrigin] = React.useState<{ x: number; y: number } | undefined>(undefined);
  const handleSplashEnter = React.useCallback((origin: { x: number; y: number }) => {
    setRippleOrigin(origin);
    setShowRipple(true);
    // Reveal the home screen partway through the ripple — by the
    // time it's at full bloom (~380ms in), the home is already
    // fading in underneath, so the user sees the ripple dissolving
    // INTO the app rather than over an empty screen.
    setTimeout(() => setSplashDone(true), 380);
  }, []);
  const handleRippleComplete = React.useCallback(() => setShowRipple(false), []);

  React.useEffect(() => {
    if (loading || !splashDone) return;
    document.documentElement.classList.add("cinematic-entry");
    const t = setTimeout(() => {
      document.documentElement.classList.remove("cinematic-entry");
    }, 1600);
    return () => clearTimeout(t);
  }, [loading, splashDone]);

  // Ripple overlay is rendered ONCE at the very bottom of the JSX
  // (after the conditional branches) so its React instance stays
  // stable when the splash unmounts and the home/login takes over.
  // If we instead mounted <RippleOverlay/> inside each branch, every
  // branch swap would tear it down and remount a fresh one — the
  // canvas animation would visibly snap back to frame 0 partway
  // through the run. See bottom of this component for the mount.
  const rippleNode = showRipple
    ? <RippleOverlay onComplete={handleRippleComplete} origin={rippleOrigin} />
    : null;

  // Content is computed once and returned at the bottom alongside
  // {rippleNode}, so RippleOverlay's React position (index 1 of the
  // outer Fragment) is identical across the splash → login → home
  // transitions. That preserves its component instance — and the
  // canvas animation continues uninterrupted when the splash dismisses
  // mid-ripple at +380ms after tap.
  let content: React.ReactNode;
  if (loading || !splashDone) {
    content = <SplashScreen onEnter={handleSplashEnter} />;
  } else if (!ageVerified) {
    content = <AgeGate profileId={profile?.id ?? null} onVerified={handleAgeVerified} />;
  } else if (!profile) {
    content = <LoginPage />;
  } else {
    content = (
    // LayoutGroup enables layoutId morphs across all children
    <LayoutGroup id="tether-header">
      <div className="animated-bg app-shell">

        {/* GPU-composited animated background — own compositor layer, zero repaint */}
        <div className="animated-bg-layer" />

        {/* Ambient orbs */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden z-0">
          <div className="absolute -top-20 -left-20 w-72 h-72 rounded-full bg-[#C53030]/12 blur-3xl" />
          <div className="absolute top-1/3 -right-20 w-60 h-60 rounded-full bg-white/5 blur-3xl" />
          <div className="absolute bottom-24 left-1/3 w-52 h-52 rounded-full bg-[#7B1313]/15 blur-3xl" />
        </div>

        {/* ── Tether Aura — glowing border synced to partner's vibe.
             Uses `effectivePartnerVibeId` so Safe View masks the real
             vibe with "content" without losing the realtime
             subscription value held in `partnerVibeId`.            ── */}
        <AnimatePresence mode="wait">
          {effectivePartnerVibeId && (
            <motion.div
              key={effectivePartnerVibeId}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1.2 }}
              style={{
                // position:fixed pins the aura to the TRUE physical screen perimeter
                // (not to the parent container) — the glow traces every edge including
                // the bottom bezel behind the home indicator.
                position: "fixed", inset: 0, pointerEvents: "none", zIndex: 9995,
              }}
            >
              <TetherAura vibeId={effectivePartnerVibeId} />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Birthday banner */}
        {birthdayBanner && (
          <div className="absolute left-0 right-0 z-50 bg-gradient-to-r from-[#7B1313] via-[#C53030] to-pink-500 text-white text-center px-4 text-sm shadow-xl"
            style={{ top: 0, paddingTop: "max(12px, calc(env(safe-area-inset-top, 12px) + 4px))", paddingBottom: 12 }}>
            <span style={{ fontFamily: "'Playfair Display', serif" }}>
              {(() => {
                const meName      = profile.first_name ?? profile.full_name ?? "you";
                const partnerName = partnerProfile?.first_name ?? partnerProfile?.full_name ?? "your partner";
                return `🎂 Happy Birthday, ${meName}! 🎉 ${partnerName} loves you endlessly! 💓`;
              })()}
            </span>
          </div>
        )}

        {/* Top bar — paddingTop uses safe-area-inset-top so content sits
            below the status bar on all iPhone models (notched, Dynamic Island,
            home-button). Falls back to 20px on devices/browsers where the
            env() variable isn't supported. */}
        <div
          className="relative z-10 flex items-center justify-between px-5 pb-1 flex-shrink-0"
          style={{ paddingTop: "max(20px, env(safe-area-inset-top, 20px))" }}
        >
          <div className="flex items-center gap-2">
            <img
              src={`${import.meta.env.BASE_URL}icon-192.png`}
              alt="Tether"
              className="w-8 h-8 rounded-lg shadow-lg"
            />
            <span className="text-white font-bold text-xl"
              style={{ fontFamily: "'Playfair Display', serif" }}>
              Tether
            </span>
          </div>
          <motion.button
            onClick={() => { haptic("light"); logout(); }}
            whileTap={{ scale: 0.92 }}
            className="text-blue-300/70 text-xs hover:text-white transition-colors tracking-wide"
          >
            Sign out
          </motion.button>
        </div>

        {/* ── Compact header — visible on all non-home tabs ── */}
        {/* Uses layoutId so "Kyle & Nathan" morphs from the hero sky header */}
        {/* Slides up out of viewport when Games Hub is active to maximize */}
        {/* screen real estate; slides back down when leaving Games. */}
        <AnimatePresence>
          {!isHome && (
            <motion.div
              key="compact-header"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: tab === "games" ? 0 : 1, y: tab === "games" ? "-100%" : 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.35, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="relative z-10 flex-shrink-0 flex flex-col items-center py-3 px-5"
              style={{
                background: "rgba(10, 18, 48, 0.55)",
                backdropFilter: "blur(20px)",
                WebkitBackdropFilter: "blur(20px)",
                borderBottom: "1px solid rgba(255,255,255,0.10)",
              }}
            >
              <motion.h2
                layoutId="couple-name"
                layout="position"
                style={{
                  fontFamily: "'Playfair Display', serif",
                  color: "white",
                  fontSize: "1.15rem",
                  fontWeight: 700,
                  margin: 0,
                  lineHeight: 1.2,
                }}
              >
                {profile?.first_name ?? profile?.full_name ?? "You"}
                {" "}&amp;{" "}
                {partnerProfile?.first_name ?? partnerProfile?.full_name ?? "Partner"}
                <SensorSyncIcon size={11} />
              </motion.h2>
              {together !== null && (
                <motion.p
                  layoutId="couple-days"
                  layout="position"
                  style={{
                    fontFamily: "'Caveat', cursive",
                    color: "rgba(147,197,253,0.75)",
                    fontSize: "0.9rem",
                    margin: "2px 0 0",
                  }}
                >
                  {together.toLocaleString()} days together
                </motion.p>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── Page content — Liquid Fluid transitions ── */}
        {/* Wrapper is position:relative + overflow:hidden so sliding pages   */}
        {/* are clipped to their bounds. Both enter/exit animate in parallel. */}
        <div className="relative z-10 flex-1 min-h-0 overflow-hidden" style={{ position: "relative" }}>

          {/* ── Liquid Glass Wave — sweeps across in the nav direction ── */}
          {/* A bright vertical shimmer band that travels with the new page, */}
          {/* creating the "glass washing over the screen" effect.           */}
          <AnimatePresence>
            {transitionKey > 0 && (
              <motion.div
                key={transitionKey}
                initial={{ x: slideDir >= 0 ? "-80%" : "80%", opacity: 0 }}
                animate={{ x: slideDir >= 0 ? "180%" : "-180%", opacity: [0, 1, 1, 0] }}
                transition={{ duration: 0.52, ease: [0.25, 0.1, 0.25, 1] }}
                style={{
                  position:      "absolute",
                  inset:         0,
                  zIndex:        30,
                  pointerEvents: "none",
                  background:    "linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.04) 25%, rgba(255,255,255,0.13) 50%, rgba(255,255,255,0.04) 75%, transparent 100%)",
                  backdropFilter: "blur(2px)",
                  WebkitBackdropFilter: "blur(2px)",
                }}
              />
            )}
          </AnimatePresence>

          {/* ── Pages — simultaneously enter/exit with directional spring ── */}
          {/* Both pages are absolute-fill so they overlap during the cross.  */}
          {/* `custom` propagates slideDir to the exit variant of the leaving */}
          {/* page — without this, exit would use the stale direction value.  */}
          <AnimatePresence initial={false} custom={slideDir}>
            <motion.div
              key={tab}
              custom={slideDir}
              variants={PAGE_VARIANTS}
              initial="enter"
              animate="center"
              exit="exit"
              transition={PAGE_TRANSITION}
              style={{
                position:       "absolute",
                inset:          0,
                display:        "flex",
                flexDirection:  "column",
                overflow:       "hidden",
                willChange:     "transform, opacity",
              }}
            >
              {/* Each page is wrapped with `data-page=...` so the
                  signature entry animation in dynamic-island.css runs
                  on every tab mount (AnimatePresence remounts on tab
                  change → CSS keyframe replays). The wrapper is a
                  flex column that fills the slot so existing page
                  layouts are unaffected. */}
              <PageErrorBoundary pageKey={tab} onReset={() => navigateTo("home")}>
                {tab === "home"      && <PageFrame page="home"><HomePage together={together ?? undefined} onNavigateToCapsules={() => navigateTo("capsules")} /></PageFrame>}
                {tab === "scrapbook" && <PageFrame page="scrapbook"><ScrapbookPage /></PageFrame>}
                {tab === "dates"     && <PageFrame page="dates"><DatePlannerPage /></PageFrame>}
                {tab === "games"     && <PageFrame page="games"><GamesHubPage /></PageFrame>}
                {tab === "capsules"  && <PageFrame page="capsules"><CapsulesPage /></PageFrame>}
                {tab === "profile"   && <PageFrame page="profile"><ProfilePage /></PageFrame>}
                {tab === "settings"  && <PageFrame page="settings"><SettingsPage onOpenGuideMenu={() => setShowGuideMenu(true)} /></PageFrame>}
              </PageErrorBoundary>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* ── Bottom nav — Liquid Glass pill ─────────────────────────
             position:fixed on .glass-nav creates a containing block so the
             DraggableNavBubble (position:absolute) stays inside the nav.
             overflow:visible lets the bubble protrude slightly above/below. */}
        <nav ref={setNavEl} className="glass-nav flex">

          {/* Idle light-refraction shimmer — slow chromatic drift
              behind everything else in the dock.  Sits at z-index 0
              so the icons (z=1), cursor sheen (z=1) and bubble (z=5)
              all stack above it. */}
          <div className="glass-shimmer" aria-hidden="true" />

          {/* Tabs — icons + labels only; no bubble rendered here.
              Home / Scrapbook / Games / Us use morphing SVG glyphs
              that spring-bloom into a filled state when active. */}
          <NavTab
            tabId="home"
            label="Home"
            active={isHome}
            onClick={() => navigateTo("home")}
            renderIcon={(active) => <HomeNavIcon active={active} />}
          />
          <NavTab
            tabId="scrapbook"
            label="Scrapbook"
            active={tab === "scrapbook"}
            onClick={() => navigateTo("scrapbook")}
            hasNew={dockHasNew.scrapbook}
            renderIcon={(active) => <ScrapbookNavIcon active={active} />}
          />
          <NavTab
            tabId="dates"
            label="Dates"
            active={tab === "dates"}
            onClick={() => navigateTo("dates")}
            hasNew={dockHasNew.dates}
            renderIcon={(active) => <DatesNavIcon active={active} />}
          />
          <NavTab
            tabId="games"
            label="Games"
            active={tab === "games"}
            onClick={() => navigateTo("games")}
            hasNew={dockHasNew.games}
            renderIcon={(active) => <GamesNavIcon active={active} />}
          />
          <NavTab
            tabId="capsules"
            label="Capsules"
            active={tab === "capsules"}
            onClick={() => navigateTo("capsules")}
            hasNew={dockHasNew.capsules}
            renderIcon={(active) => <CapsulesNavIcon active={active} />}
          />
          <NavTab
            tabId="profile"
            label="Us"
            active={tab === "profile"}
            onClick={() => navigateTo("profile")}
            renderIcon={(active) => <UsNavIcon active={active} />}
          />
          <NavTab
            tabId="settings"
            label="Settings"
            active={tab === "settings"}
            onClick={() => navigateTo("settings")}
            renderIcon={(active) => <SettingsNavIcon active={active} />}
          />

          {/* Single draggable glass bubble — travels across the full nav */}
          <DraggableNavBubble
            tab={tab}
            navigateTo={navigateTo}
            auraColor={auraColor}
            onSnapComplete={handleSnapComplete}
            navEl={navEl}
          />
        </nav>

      </div>
    </LayoutGroup>
    );
  }

  return (
    <>
      {/* Living mesh gradient — sits beneath every UI surface,
          recolours from the active theme's CSS custom properties,
          and gently drifts on four independent loops. */}
      <MeshGradientBackground />
      {/* Liquid realism — rain / waves / caustics / touch ripples.
          Idle by default; activate via setLiquidWeather("rainy" |
          "ocean" | "deepsea") from anywhere. */}
      <LiquidRealism />
      {/* Tidal Beach shoreline — mounts itself only when the
          Beach theme is active. Layered morphing waves + foam
          bubbles + gyroscope parallax + wet-sand mesh pulse. */}
      <BeachShoreline />
      {/* Contact High — synchronised spark + vortex + flash when
          you and your partner tap phones. Triggers via Supabase
          realtime broadcast on the shared tether channel. */}
      <ContactHigh />
      {content}
      {rippleNode}
      {/* Global heartbeat pulse — fires when triggerHeartbeatPulse() is called.
          Sits above all UI but ignores pointer events. */}
      <HeartbeatPulseBorder />
      <AnimatePresence>
        {showWelcome && (
          <WelcomeGuide open={showWelcome} onClose={closeWelcome} />
        )}
      </AnimatePresence>
      <AppGuideMenu open={showGuideMenu} onClose={closeGuideMenu} />
    </>
  );
}

export default function App() {
  // iOS Visual-Viewport restoration — see hooks/useViewportFix.ts.
  // Installed at the App root so the listeners exist for the full
  // session, regardless of which page is mounted.
  useViewportFix();

  return (
    <AuthProvider>
      <EditModeProvider>
        <SafeViewProvider>
          {/* ThemeProvider applies the user's theme (or partner-gifted theme)
              by setting --theme-* CSS vars on :root, and subscribes to
              realtime updates so a partner's gift appears live. */}
          <ThemeProvider />
          {/* ThemeDecorations renders global animations (snowflakes,
              Santa, balloons, confetti) for themes that have them.
              Sits at z 9999 (above tint, below Dynamic Island). */}
          <ThemeDecorations />
          {/* DynamicIsland — pill banner at the very top, mounted at
              App root so it floats above every page and the dock. */}
          <DynamicIsland />
          {/* Wet Glass — global droplet texture (mirrors the app icon).
              Rendered once at App root so it's present on the splash,
              login, and every in-app screen without per-page wiring. */}
          <div className="wet-glass-overlay" aria-hidden="true" />
          <AppShell />
          <EditModeFooter />
          <Toaster />
        </SafeViewProvider>
      </EditModeProvider>
    </AuthProvider>
  );
}
