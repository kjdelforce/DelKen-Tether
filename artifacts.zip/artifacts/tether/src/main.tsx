import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import "./styles/ai.css";
import "./styles/welcome.css";
import "./styles/app-guide.css";
import "./styles/two-truths.css";
import "./styles/tether-wrapped.css";
import "./styles/themes.css";
import "./styles/dynamic-island.css";
import "./styles/font-size.css";
import "./styles/games-hub.css";
import { initFontSize } from "./lib/fontSize";

// Apply the saved user-content font size as early as possible so
// the very first paint already reflects the user's preference —
// avoids a flash of default-size text on cold loads.
initFontSize();

createRoot(document.getElementById("root")!).render(<App />);
