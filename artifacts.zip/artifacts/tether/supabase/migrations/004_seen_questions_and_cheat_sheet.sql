-- ═══════════════════════════════════════════════════════════
--  Migration 004 — seen_questions + cheat-sheet expansion
--  Run this in the Supabase SQL Editor before deploying the
--  matching client build. All statements are idempotent.
-- ═══════════════════════════════════════════════════════════

-- ── 1. seen_questions ──────────────────────────────────────
-- Tracks which questions a couple has already been shown so
-- we never repeat across Trivia / Daily Connection / Daily
-- Naughty / Couples Corner. The composite primary key keeps
-- inserts idempotent (re-marking is a no-op).
CREATE TABLE IF NOT EXISTS seen_questions (
  tether_id    UUID         NOT NULL REFERENCES tethers(id) ON DELETE CASCADE,
  game_key     TEXT         NOT NULL CHECK (
    game_key IN ('trivia', 'daily_connection', 'daily_naughty', 'couples_corner')
  ),
  question_id  TEXT         NOT NULL,
  seen_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  PRIMARY KEY (tether_id, game_key, question_id)
);

CREATE INDEX IF NOT EXISTS seen_questions_tether_game_idx
  ON seen_questions (tether_id, game_key);

ALTER TABLE seen_questions ENABLE ROW LEVEL SECURITY;

-- Allow members of a tether to read + write their own rows.
DROP POLICY IF EXISTS seen_questions_member_select ON seen_questions;
CREATE POLICY seen_questions_member_select
  ON seen_questions FOR SELECT
  USING (
    tether_id IN (
      SELECT tether_id FROM profiles WHERE auth_user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS seen_questions_member_insert ON seen_questions;
CREATE POLICY seen_questions_member_insert
  ON seen_questions FOR INSERT
  WITH CHECK (
    tether_id IN (
      SELECT tether_id FROM profiles WHERE auth_user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS seen_questions_member_delete ON seen_questions;
CREATE POLICY seen_questions_member_delete
  ON seen_questions FOR DELETE
  USING (
    tether_id IN (
      SELECT tether_id FROM profiles WHERE auth_user_id = auth.uid()
    )
  );

-- ── 2. profile_details — new Cheat Sheet columns ──────────
-- Eight new TEXT fields. Default to '' so legacy rows render
-- cleanly without backfill.
ALTER TABLE profile_details
  ADD COLUMN IF NOT EXISTS favourite_colour       TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS favourite_food         TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS ring_size              TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS size_shirt             TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS size_shorts            TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS favourite_movies_shows TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS wind_down              TEXT NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS music_preference       TEXT NOT NULL DEFAULT '';

-- ── 3. naughty_questions — scrub literal names ────────────
-- Replace "Kyle" / "Nathan" anywhere in already-posted naughty
-- questions with neutral pronouns. Uses regexp_replace with a
-- word-boundary so it doesn't touch substrings.
UPDATE naughty_questions
   SET question_text = regexp_replace(
                          regexp_replace(question_text, '\mKyle\M',   'you',  'gi'),
                          '\mNathan\M', 'them', 'gi'
                       )
 WHERE question_text ~* '\m(Kyle|Nathan)\M';
