# Tether — Row-Level Security Audit

This document tracks every Supabase table in the Tether project, the
RLS policy applied, and the column used to scope rows to a single
couple. Every per-couple table follows the same template established
in `onboarding_v1_part2_security.sql` and extended across the rest of
the schema in `onboarding_v1_part3_table_security.sql`.

When you add a NEW per-couple table, copy the template at the bottom
of this file, drop it into a new migration, and add the row to this
table.

## Coverage matrix

| Table | RLS | Scope column | Policy template | Migration |
|---|---|---|---|---|
| `profiles` | enabled | `tether_id` | tenant + legacy anon | part 2 |
| `tethers` | enabled | `id` | tenant + legacy anon | part 2 |
| `posts` | enabled | `tether_id` | direct | part 3 |
| `date_plans` | enabled | `tether_id` | direct | part 3 |
| `tether_likes` | enabled | `tether_id` | direct | part 3 |
| `tether_comments` | enabled | `tether_id` | direct | part 3 |
| `time_capsules` | enabled | `tether_id` | direct | part 3 |
| `capsule_reactions` | enabled | `time_capsules.tether_id` | indirect (via parent) | part 3 |
| `temporary_whispers` | enabled | `tether_id` | direct | part 3 |
| `daily_answers` | enabled | `tether_id` | direct | part 3 |
| `trivia_answers` | enabled | `tether_id` | direct | part 3 |
| `naughty_questions` | enabled | `tether_id` | direct | part 3 |
| `naughty_answers` | enabled | `tether_id` | direct | part 3 |
| `kink_matrix` | enabled | `tether_id` | direct | part 3 |
| `love_messages` | enabled | `tether_id` | direct | part 3 |
| `two_truths_rounds` | enabled | `couple_id` (= `tether.id`) | direct + RPC writes | part 3 |
| `profile_details` | enabled | `profiles.id → tether_id` | indirect (via owning profile) | part 3 |
| `app_content` | enabled | n/a | global read, Kyle-only write | part 3 |
| storage `memories` | enabled | folder name = `tether_id` | tenant | part 1 |
| storage `avatars` | n/a (public bucket) | n/a | intentionally public | part 1 |

## Helper functions

Both functions live in `onboarding_v1_part3_table_security.sql` and
run as `SECURITY DEFINER` so they can read `profiles` without being
filtered by its RLS policies.

- `is_couple_member(tether_id uuid) → boolean`
  True when `auth.uid()` resolves to a profile with the given
  `tether_id`. Used in every authenticated tenant policy.

- `is_legacy_tether(tether_id uuid) → boolean`
  True when no profile in the tether has been bridged to Supabase
  Auth yet. Gates the transitional anon policies that keep Kyle &
  Nathan's invite-code login working.

## Direct-tenant template

For a new table with a `tether_id` column:

```sql
ALTER TABLE public.<your_table> ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "<your_table>_select_couple"   ON public.<your_table>;
DROP POLICY IF EXISTS "<your_table>_insert_couple"   ON public.<your_table>;
DROP POLICY IF EXISTS "<your_table>_update_couple"   ON public.<your_table>;
DROP POLICY IF EXISTS "<your_table>_delete_couple"   ON public.<your_table>;
DROP POLICY IF EXISTS "<your_table>_legacy_anon_all" ON public.<your_table>;

CREATE POLICY "<your_table>_select_couple" ON public.<your_table>
  FOR SELECT TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "<your_table>_insert_couple" ON public.<your_table>
  FOR INSERT TO authenticated
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "<your_table>_update_couple" ON public.<your_table>
  FOR UPDATE TO authenticated
  USING (public.is_couple_member(tether_id))
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "<your_table>_delete_couple" ON public.<your_table>
  FOR DELETE TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "<your_table>_legacy_anon_all" ON public.<your_table>
  FOR ALL TO anon
  USING (public.is_legacy_tether(tether_id))
  WITH CHECK (public.is_legacy_tether(tether_id));
```

## Indirect-tenant template

For a new table that does NOT have its own `tether_id` but joins to
a parent table that does (e.g. `capsule_reactions → time_capsules`):

```sql
ALTER TABLE public.<your_table> ENABLE ROW LEVEL SECURITY;

CREATE POLICY "<your_table>_select_couple" ON public.<your_table>
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.<parent_table> parent
      WHERE parent.id = <your_table>.<parent_fk>
        AND public.is_couple_member(parent.tether_id)
    )
  );

-- (insert / update / delete follow the same EXISTS pattern)

CREATE POLICY "<your_table>_legacy_anon_all" ON public.<your_table>
  FOR ALL TO anon
  USING (
    EXISTS (
      SELECT 1 FROM public.<parent_table> parent
      WHERE parent.id = <your_table>.<parent_fk>
        AND public.is_legacy_tether(parent.tether_id)
    )
  )
  WITH CHECK (...same...);
```

## Verifying

Run the cross-couple isolation test from the project root:

```
node artifacts/tether/supabase/tests/cross_couple_isolation.mjs
```

It signs up two fresh test couples (couple A and couple B), writes
data as couple A across every per-couple table, then signs in as
couple B and asserts that none of A's rows are visible. See the
script header for prerequisites.

## Decommission plan for the legacy anon bridge

Once Kyle & Nathan have both signed up via email (i.e. their
`profiles.auth_user_id` is set), drop every `*_legacy_anon_*` policy
created here. Suggested grep:

```
grep -E '"\w+_legacy_anon_' artifacts/tether/supabase/migrations/*.sql
```
