-- ═══════════════════════════════════════════════════════════
--  Migration 006 — love_notes
--  Sealed handwritten notes a partner leaves for the other.
--  Floats on Home until opened, then archived in the Keepsake
--  Drawer in the Profile Hub. All statements are idempotent.
-- ═══════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS love_notes (
  id            UUID         NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tether_id    UUID         NOT NULL REFERENCES tethers(id)  ON DELETE CASCADE,
  sender_id    UUID         NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  recipient_id UUID         NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  note_text    TEXT         NOT NULL CHECK (length(note_text) > 0 AND length(note_text) <= 400),
  is_read      BOOLEAN      NOT NULL DEFAULT FALSE,
  read_at      TIMESTAMPTZ,
  created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS love_notes_recipient_unread_idx
  ON love_notes (recipient_id, is_read, created_at DESC);

CREATE INDEX IF NOT EXISTS love_notes_tether_idx
  ON love_notes (tether_id, created_at DESC);

ALTER TABLE love_notes ENABLE ROW LEVEL SECURITY;

-- Drop and recreate so re-runs are clean.
DROP POLICY IF EXISTS love_notes_select_couple        ON love_notes;
DROP POLICY IF EXISTS love_notes_insert_couple        ON love_notes;
DROP POLICY IF EXISTS love_notes_update_recipient     ON love_notes;
DROP POLICY IF EXISTS love_notes_delete_couple        ON love_notes;
DROP POLICY IF EXISTS love_notes_legacy_anon_all      ON love_notes;

-- Members of the same tether can read every note in their tether.
CREATE POLICY love_notes_select_couple ON love_notes
  FOR SELECT
  USING (
    tether_id IN (
      SELECT tether_id FROM profiles WHERE auth_user_id = auth.uid()
    )
  );

-- Authenticated members can insert notes for their tether (sender
-- must belong to the same tether — recipient defaults to the partner
-- but we still scope to tether membership for safety).
CREATE POLICY love_notes_insert_couple ON love_notes
  FOR INSERT
  WITH CHECK (
    tether_id IN (
      SELECT tether_id FROM profiles WHERE auth_user_id = auth.uid()
    )
  );

-- Only the recipient may flip is_read / set read_at.
CREATE POLICY love_notes_update_recipient ON love_notes
  FOR UPDATE
  USING (
    recipient_id IN (
      SELECT id FROM profiles WHERE auth_user_id = auth.uid()
    )
  );

CREATE POLICY love_notes_delete_couple ON love_notes
  FOR DELETE
  USING (
    tether_id IN (
      SELECT tether_id FROM profiles WHERE auth_user_id = auth.uid()
    )
  );

-- Legacy anon path — Kyle & Nathan's original profiles still use
-- localStorage-only auth (no auth.uid()). Mirror the same fall-back
-- policy used by daily_answers / trivia_answers / naughty_questions
-- so the feature works for them too. New email-auth users always
-- match the auth-scoped policies above first.
CREATE POLICY love_notes_legacy_anon_all ON love_notes
  FOR ALL
  TO anon
  USING (true)
  WITH CHECK (true);
