-- Migration 005 — Age Verification gate
-- Run once in the Supabase SQL editor.
-- ─────────────────────────────────────────────────────────────────
-- Adds an age_verified boolean column to the profiles table so
-- the one-time age gate confirmation persists across devices /
-- browsers once the user is logged in.
--
-- Defaults to FALSE so all existing and future rows start
-- unverified (the client's localStorage check fires first for
-- returning users; Supabase is used as the durable source of
-- truth when localStorage has been cleared).
-- ─────────────────────────────────────────────────────────────────

ALTER TABLE profiles
  ADD COLUMN IF NOT EXISTS age_verified boolean NOT NULL DEFAULT false;
