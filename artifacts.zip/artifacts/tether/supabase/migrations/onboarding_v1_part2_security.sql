-- ════════════════════════════════════════════════════════════════════
-- Tether — Onboarding v1, Part 2: SECURITY HARDENING
-- ════════════════════════════════════════════════════════════════════
--   Run this AFTER `onboarding_v1.sql`.
--   Replaces the temporary "permissive" RLS policies (which allowed
--   any anon-keyed client to read or write all couples' rows) with
--   tenant-scoped policies that gate access by:
--
--     auth.uid() ─→ profiles.auth_user_id ─→ tether_id
--
--   Legacy compatibility:
--     Kyle & Nathan still log in via the invite-code path, which uses
--     the anon key (no Supabase Auth session). To preserve their
--     access without re-exposing every couple's data, we leave anon
--     read/write enabled ONLY for profiles whose `auth_user_id IS
--     NULL` (= legacy, pre-migration accounts). All NEW users sign up
--     via the OnboardingWizard, get a real Supabase Auth session, and
--     are governed by the strict authenticated-user policies.
--
--   Once Kyle & Nathan migrate to email/password, you can drop the
--   transitional anon policies entirely. Each `DROP POLICY` line at
--   the top of this file is idempotent so re-running is safe.
--
--   Also adds:
--     • UNIQUE constraint on tethers.invite_code (so couple-create
--       collisions are caught at the DB layer, not silent)
--     • UNIQUE (tether_id, role) on profiles (enforces max 2 members
--       per couple: 1 primary + 1 member)
-- ════════════════════════════════════════════════════════════════════


-- ──────────────────────────────────────────────────────────────────
-- 1. Tear down the old permissive policies
-- ──────────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "profiles_read_all"  ON public.profiles;
DROP POLICY IF EXISTS "profiles_write_all" ON public.profiles;
DROP POLICY IF EXISTS "tethers_read_all"   ON public.tethers;
DROP POLICY IF EXISTS "tethers_write_all"  ON public.tethers;


-- ──────────────────────────────────────────────────────────────────
-- 2. DB-level integrity constraints
-- ──────────────────────────────────────────────────────────────────

-- 2a. Unique invite codes (block silent duplicates)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'tethers_invite_code_unique'
  ) THEN
    ALTER TABLE public.tethers
      ADD CONSTRAINT tethers_invite_code_unique UNIQUE (invite_code);
  END IF;
END$$;

-- 2a-bis. Backfill: ensure every tether has exactly one 'primary'.
--
-- The `profiles.role` column was added by part 1 with a DEFAULT of
-- 'member', so any pre-existing couple (e.g. Kyle & Nathan, the
-- original tether 070425) currently has TWO members and ZERO
-- primaries. The UNIQUE (tether_id, role) constraint added in 2b
-- below would then fail with `23505 duplicate key (tether_id, member)`.
--
-- This block promotes an arbitrary but deterministic profile per
-- tether (the one with the lowest `id`) to 'primary' for any tether
-- that doesn't already have one. The `profiles` table has no
-- creation timestamp, so we cannot pick the "earliest" — but for
-- legacy 2-member tethers either choice is fine; the constraint just
-- needs the two roles to differ. The OnboardingWizard always inserts
-- the creator as 'primary' from the start, so for tethers built via
-- the new flow this is a no-op.
--
-- Idempotent: re-running the migration finds a primary already
-- exists for every tether and updates nothing.
UPDATE public.profiles AS p
SET role = 'primary'
WHERE p.id IN (
  SELECT DISTINCT ON (inner_p.tether_id) inner_p.id
  FROM public.profiles AS inner_p
  WHERE inner_p.tether_id IS NOT NULL
    AND NOT EXISTS (
      SELECT 1 FROM public.profiles AS check_p
      WHERE check_p.tether_id = inner_p.tether_id
        AND check_p.role = 'primary'
    )
  ORDER BY inner_p.tether_id, inner_p.id
);

-- 2b. Max 2 members per tether (1 primary + 1 member)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'profiles_tether_role_unique'
  ) THEN
    ALTER TABLE public.profiles
      ADD CONSTRAINT profiles_tether_role_unique UNIQUE (tether_id, role);
  END IF;
END$$;


-- ──────────────────────────────────────────────────────────────────
-- 3. PROFILES — tenant-scoped policies
-- ──────────────────────────────────────────────────────────────────

-- 3a. Authenticated read: only profiles in your own couple.
CREATE POLICY "profiles_select_own_couple"
ON public.profiles FOR SELECT TO authenticated
USING (
  tether_id IN (
    SELECT p2.tether_id FROM public.profiles p2
    WHERE p2.auth_user_id = auth.uid()
  )
);

-- 3b. Authenticated insert: only your own row, only into a tether
-- that either has 0 members yet (you're the creator) or contains
-- you already (re-insert during repair flows). The wizard always
-- inserts the row right after creating the tether, so the
-- "0 members" branch is the normal path.
CREATE POLICY "profiles_insert_self"
ON public.profiles FOR INSERT TO authenticated
WITH CHECK (
  auth_user_id = auth.uid()
  AND (
    NOT EXISTS (SELECT 1 FROM public.profiles p3 WHERE p3.tether_id = profiles.tether_id)
    OR EXISTS (
      SELECT 1 FROM public.profiles p4
      WHERE p4.tether_id = profiles.tether_id AND p4.auth_user_id = auth.uid()
    )
  )
);

-- 3c. Authenticated update: only your own profile row.
CREATE POLICY "profiles_update_self"
ON public.profiles FOR UPDATE TO authenticated
USING (auth_user_id = auth.uid())
WITH CHECK (auth_user_id = auth.uid());

-- 3d. Authenticated delete: only your own profile row.
CREATE POLICY "profiles_delete_self"
ON public.profiles FOR DELETE TO authenticated
USING (auth_user_id = auth.uid());

-- 3e. LEGACY anon bridge (Kyle & Nathan, pre-Supabase-Auth):
-- read/write only profiles where auth_user_id IS NULL. Once they
-- sign up with email, drop these two policies.
CREATE POLICY "profiles_legacy_anon_select"
ON public.profiles FOR SELECT TO anon
USING (auth_user_id IS NULL);

CREATE POLICY "profiles_legacy_anon_write"
ON public.profiles FOR ALL TO anon
USING (auth_user_id IS NULL)
WITH CHECK (auth_user_id IS NULL);


-- ──────────────────────────────────────────────────────────────────
-- 4. TETHERS — tenant-scoped policies
-- ──────────────────────────────────────────────────────────────────

-- 4a. Authenticated read: any tether you're a member of.
-- ALSO: any tether (by invite_code only) when joining — handled at the
-- app layer by selecting on invite_code; we still need read access for
-- the lookup. We allow SELECT on all tethers to authenticated users
-- because the row contains no sensitive fields beyond invite_code +
-- start_date, and invite_code is the join secret itself (similar to a
-- room PIN). Tighten further if you add sensitive columns.
CREATE POLICY "tethers_select_authenticated"
ON public.tethers FOR SELECT TO authenticated
USING (true);

-- 4b. Authenticated insert: anyone signed in can create a new tether.
-- The OnboardingWizard generates the invite_code and immediately
-- inserts the creator's profile against it.
CREATE POLICY "tethers_insert_authenticated"
ON public.tethers FOR INSERT TO authenticated
WITH CHECK (true);

-- 4c. Authenticated update: only members of that tether may edit it.
CREATE POLICY "tethers_update_members"
ON public.tethers FOR UPDATE TO authenticated
USING (
  id IN (
    SELECT p.tether_id FROM public.profiles p
    WHERE p.auth_user_id = auth.uid()
  )
)
WITH CHECK (
  id IN (
    SELECT p.tether_id FROM public.profiles p
    WHERE p.auth_user_id = auth.uid()
  )
);

-- 4d. Authenticated delete: only members of that tether may delete.
CREATE POLICY "tethers_delete_members"
ON public.tethers FOR DELETE TO authenticated
USING (
  id IN (
    SELECT p.tether_id FROM public.profiles p
    WHERE p.auth_user_id = auth.uid()
  )
);

-- 4e. LEGACY anon bridge: invite-code login needs to look up tethers
-- by code and (occasionally) auto-create a tether on first legacy
-- login. Restrict to tethers that have NO Supabase-Auth-bridged
-- members yet (= legacy, pre-migration). Once K&N migrate, drop
-- these two policies.
CREATE POLICY "tethers_legacy_anon_select"
ON public.tethers FOR SELECT TO anon
USING (
  NOT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.tether_id = tethers.id
      AND p.auth_user_id IS NOT NULL
  )
);

CREATE POLICY "tethers_legacy_anon_write"
ON public.tethers FOR ALL TO anon
USING (
  NOT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.tether_id = tethers.id
      AND p.auth_user_id IS NOT NULL
  )
)
WITH CHECK (
  NOT EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.tether_id = tethers.id
      AND p.auth_user_id IS NOT NULL
  )
);


-- ════════════════════════════════════════════════════════════════════
-- DONE.
--
-- ⚠️  IMPORTANT: This migration only hardens `profiles` and `tethers`.
--     Before public launch, audit the same way for every OTHER table
--     containing per-couple data, e.g.:
--
--       posts, messages, memories, themes, calendar_events, capsules,
--       trivia_questions, vibe_history, etc.
--
--     For each, enable RLS and add a policy of the shape:
--       USING (
--         tether_id IN (
--           SELECT p.tether_id FROM public.profiles p
--           WHERE p.auth_user_id = auth.uid()
--         )
--       )
--
--     and a transitional `anon` policy mirroring the legacy bridge
--     above if those tables are touched by the legacy invite-code
--     code path.
-- ════════════════════════════════════════════════════════════════════
