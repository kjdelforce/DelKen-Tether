-- ════════════════════════════════════════════════════════════════════
-- Tether — Onboarding v1, Part 3: PER-COUPLE TABLE SECURITY HARDENING
-- ════════════════════════════════════════════════════════════════════
--   Run this AFTER `onboarding_v1_part2_security.sql`.
--
--   Part 2 locked down `profiles` and `tethers`. Part 3 applies the
--   same tenant-scoped RLS pattern to every OTHER table that holds
--   per-couple data, so that once the public release is live, a
--   second couple can never read or write the original couple's
--   rows by guessing IDs or sniffing the anon key.
--
--   Tables hardened in this migration:
--
--     posts                  daily_answers
--     date_plans             trivia_answers
--     tether_likes           naughty_questions
--     tether_comments        naughty_answers
--     time_capsules          kink_matrix
--     capsule_reactions      love_messages
--     temporary_whispers     two_truths_rounds
--     profile_details        app_content (admin-only write, not couple data)
--
--   Every policy follows the same shape from part 2:
--
--     auth.uid() ─→ profiles.auth_user_id ─→ tether_id ─→ row
--
--   Legacy compatibility:
--     Two helper functions (`is_couple_member`, `is_legacy_tether`)
--     run as SECURITY DEFINER so they bypass RLS on `profiles`
--     when checking membership. Without that, the legacy-anon
--     subqueries in part 2 would never see auth-bridged profiles
--     (they'd be filtered out by the profile policies) and would
--     incorrectly classify post-migration tethers as legacy.
--
--   The migration is idempotent — every CREATE POLICY is preceded
--   by DROP POLICY IF EXISTS, so re-running is safe.
--
--   See `RLS_AUDIT.md` for the per-table audit table.
-- ════════════════════════════════════════════════════════════════════


-- ──────────────────────────────────────────────────────────────────
-- 0. Helper functions
-- ──────────────────────────────────────────────────────────────────

-- Is `auth.uid()` a member of the given tether?
-- SECURITY DEFINER: bypass RLS so we can see ALL profiles in the
-- tether, not just the ones visible to the current role.
CREATE OR REPLACE FUNCTION public.is_couple_member(t_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT t_id IS NOT NULL
     AND auth.uid() IS NOT NULL
     AND EXISTS (
       SELECT 1 FROM public.profiles p
       WHERE p.tether_id = t_id
         AND p.auth_user_id = auth.uid()
     )
$$;

-- Has the given tether NOT yet migrated anyone to Supabase Auth?
-- (i.e. it's a legacy invite-code-only couple, eligible for the
-- transitional anon bridge.)
CREATE OR REPLACE FUNCTION public.is_legacy_tether(t_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT t_id IS NOT NULL
     AND NOT EXISTS (
       SELECT 1 FROM public.profiles p
       WHERE p.tether_id = t_id
         AND p.auth_user_id IS NOT NULL
     )
$$;

GRANT EXECUTE ON FUNCTION public.is_couple_member(uuid) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.is_legacy_tether(uuid) TO anon, authenticated;


-- ──────────────────────────────────────────────────────────────────
-- 1. POSTS  (tether_id, author_id)
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "posts_read_all"          ON public.posts;
DROP POLICY IF EXISTS "posts_write_all"         ON public.posts;
DROP POLICY IF EXISTS "posts_select_couple"     ON public.posts;
DROP POLICY IF EXISTS "posts_insert_couple"     ON public.posts;
DROP POLICY IF EXISTS "posts_update_couple"     ON public.posts;
DROP POLICY IF EXISTS "posts_delete_couple"     ON public.posts;
DROP POLICY IF EXISTS "posts_legacy_anon_all"   ON public.posts;

CREATE POLICY "posts_select_couple" ON public.posts
  FOR SELECT TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "posts_insert_couple" ON public.posts
  FOR INSERT TO authenticated
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "posts_update_couple" ON public.posts
  FOR UPDATE TO authenticated
  USING (public.is_couple_member(tether_id))
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "posts_delete_couple" ON public.posts
  FOR DELETE TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "posts_legacy_anon_all" ON public.posts
  FOR ALL TO anon
  USING (public.is_legacy_tether(tether_id))
  WITH CHECK (public.is_legacy_tether(tether_id));


-- ──────────────────────────────────────────────────────────────────
-- 2. DATE_PLANS  (tether_id)
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.date_plans ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "date_plans_read_all"        ON public.date_plans;
DROP POLICY IF EXISTS "date_plans_write_all"       ON public.date_plans;
DROP POLICY IF EXISTS "date_plans_select_couple"   ON public.date_plans;
DROP POLICY IF EXISTS "date_plans_insert_couple"   ON public.date_plans;
DROP POLICY IF EXISTS "date_plans_update_couple"   ON public.date_plans;
DROP POLICY IF EXISTS "date_plans_delete_couple"   ON public.date_plans;
DROP POLICY IF EXISTS "date_plans_legacy_anon_all" ON public.date_plans;

CREATE POLICY "date_plans_select_couple" ON public.date_plans
  FOR SELECT TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "date_plans_insert_couple" ON public.date_plans
  FOR INSERT TO authenticated
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "date_plans_update_couple" ON public.date_plans
  FOR UPDATE TO authenticated
  USING (public.is_couple_member(tether_id))
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "date_plans_delete_couple" ON public.date_plans
  FOR DELETE TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "date_plans_legacy_anon_all" ON public.date_plans
  FOR ALL TO anon
  USING (public.is_legacy_tether(tether_id))
  WITH CHECK (public.is_legacy_tether(tether_id));


-- ──────────────────────────────────────────────────────────────────
-- 3. TETHER_LIKES  (tether_id, target_type, target_id, user_id)
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.tether_likes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "tether_likes_read_all"        ON public.tether_likes;
DROP POLICY IF EXISTS "tether_likes_write_all"       ON public.tether_likes;
DROP POLICY IF EXISTS "tether_likes_select_couple"   ON public.tether_likes;
DROP POLICY IF EXISTS "tether_likes_insert_couple"   ON public.tether_likes;
DROP POLICY IF EXISTS "tether_likes_update_couple"   ON public.tether_likes;
DROP POLICY IF EXISTS "tether_likes_delete_couple"   ON public.tether_likes;
DROP POLICY IF EXISTS "tether_likes_legacy_anon_all" ON public.tether_likes;

CREATE POLICY "tether_likes_select_couple" ON public.tether_likes
  FOR SELECT TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "tether_likes_insert_couple" ON public.tether_likes
  FOR INSERT TO authenticated
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "tether_likes_update_couple" ON public.tether_likes
  FOR UPDATE TO authenticated
  USING (public.is_couple_member(tether_id))
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "tether_likes_delete_couple" ON public.tether_likes
  FOR DELETE TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "tether_likes_legacy_anon_all" ON public.tether_likes
  FOR ALL TO anon
  USING (public.is_legacy_tether(tether_id))
  WITH CHECK (public.is_legacy_tether(tether_id));


-- ──────────────────────────────────────────────────────────────────
-- 4. TETHER_COMMENTS  (tether_id, target_type, target_id, author_id)
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.tether_comments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "tether_comments_read_all"        ON public.tether_comments;
DROP POLICY IF EXISTS "tether_comments_write_all"       ON public.tether_comments;
DROP POLICY IF EXISTS "tether_comments_select_couple"   ON public.tether_comments;
DROP POLICY IF EXISTS "tether_comments_insert_couple"   ON public.tether_comments;
DROP POLICY IF EXISTS "tether_comments_update_couple"   ON public.tether_comments;
DROP POLICY IF EXISTS "tether_comments_delete_couple"   ON public.tether_comments;
DROP POLICY IF EXISTS "tether_comments_legacy_anon_all" ON public.tether_comments;

CREATE POLICY "tether_comments_select_couple" ON public.tether_comments
  FOR SELECT TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "tether_comments_insert_couple" ON public.tether_comments
  FOR INSERT TO authenticated
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "tether_comments_update_couple" ON public.tether_comments
  FOR UPDATE TO authenticated
  USING (public.is_couple_member(tether_id))
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "tether_comments_delete_couple" ON public.tether_comments
  FOR DELETE TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "tether_comments_legacy_anon_all" ON public.tether_comments
  FOR ALL TO anon
  USING (public.is_legacy_tether(tether_id))
  WITH CHECK (public.is_legacy_tether(tether_id));


-- ──────────────────────────────────────────────────────────────────
-- 5. TIME_CAPSULES  (tether_id)
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.time_capsules ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "time_capsules_read_all"        ON public.time_capsules;
DROP POLICY IF EXISTS "time_capsules_write_all"       ON public.time_capsules;
DROP POLICY IF EXISTS "time_capsules_select_couple"   ON public.time_capsules;
DROP POLICY IF EXISTS "time_capsules_insert_couple"   ON public.time_capsules;
DROP POLICY IF EXISTS "time_capsules_update_couple"   ON public.time_capsules;
DROP POLICY IF EXISTS "time_capsules_delete_couple"   ON public.time_capsules;
DROP POLICY IF EXISTS "time_capsules_legacy_anon_all" ON public.time_capsules;

CREATE POLICY "time_capsules_select_couple" ON public.time_capsules
  FOR SELECT TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "time_capsules_insert_couple" ON public.time_capsules
  FOR INSERT TO authenticated
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "time_capsules_update_couple" ON public.time_capsules
  FOR UPDATE TO authenticated
  USING (public.is_couple_member(tether_id))
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "time_capsules_delete_couple" ON public.time_capsules
  FOR DELETE TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "time_capsules_legacy_anon_all" ON public.time_capsules
  FOR ALL TO anon
  USING (public.is_legacy_tether(tether_id))
  WITH CHECK (public.is_legacy_tether(tether_id));


-- ──────────────────────────────────────────────────────────────────
-- 6. CAPSULE_REACTIONS  (capsule_id, user_id)
--    No direct tether_id; scope through the parent capsule.
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.capsule_reactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "capsule_reactions_read_all"        ON public.capsule_reactions;
DROP POLICY IF EXISTS "capsule_reactions_write_all"       ON public.capsule_reactions;
DROP POLICY IF EXISTS "capsule_reactions_select_couple"   ON public.capsule_reactions;
DROP POLICY IF EXISTS "capsule_reactions_insert_couple"   ON public.capsule_reactions;
DROP POLICY IF EXISTS "capsule_reactions_update_couple"   ON public.capsule_reactions;
DROP POLICY IF EXISTS "capsule_reactions_delete_couple"   ON public.capsule_reactions;
DROP POLICY IF EXISTS "capsule_reactions_legacy_anon_all" ON public.capsule_reactions;

CREATE POLICY "capsule_reactions_select_couple" ON public.capsule_reactions
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.time_capsules tc
      WHERE tc.id = capsule_reactions.capsule_id
        AND public.is_couple_member(tc.tether_id)
    )
  );

CREATE POLICY "capsule_reactions_insert_couple" ON public.capsule_reactions
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.time_capsules tc
      WHERE tc.id = capsule_reactions.capsule_id
        AND public.is_couple_member(tc.tether_id)
    )
  );

CREATE POLICY "capsule_reactions_update_couple" ON public.capsule_reactions
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.time_capsules tc
      WHERE tc.id = capsule_reactions.capsule_id
        AND public.is_couple_member(tc.tether_id)
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.time_capsules tc
      WHERE tc.id = capsule_reactions.capsule_id
        AND public.is_couple_member(tc.tether_id)
    )
  );

CREATE POLICY "capsule_reactions_delete_couple" ON public.capsule_reactions
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.time_capsules tc
      WHERE tc.id = capsule_reactions.capsule_id
        AND public.is_couple_member(tc.tether_id)
    )
  );

CREATE POLICY "capsule_reactions_legacy_anon_all" ON public.capsule_reactions
  FOR ALL TO anon
  USING (
    EXISTS (
      SELECT 1 FROM public.time_capsules tc
      WHERE tc.id = capsule_reactions.capsule_id
        AND public.is_legacy_tether(tc.tether_id)
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.time_capsules tc
      WHERE tc.id = capsule_reactions.capsule_id
        AND public.is_legacy_tether(tc.tether_id)
    )
  );


-- ──────────────────────────────────────────────────────────────────
-- 7. TEMPORARY_WHISPERS  (tether_id)
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.temporary_whispers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "temporary_whispers_read_all"        ON public.temporary_whispers;
DROP POLICY IF EXISTS "temporary_whispers_write_all"       ON public.temporary_whispers;
DROP POLICY IF EXISTS "temporary_whispers_select_couple"   ON public.temporary_whispers;
DROP POLICY IF EXISTS "temporary_whispers_insert_couple"   ON public.temporary_whispers;
DROP POLICY IF EXISTS "temporary_whispers_update_couple"   ON public.temporary_whispers;
DROP POLICY IF EXISTS "temporary_whispers_delete_couple"   ON public.temporary_whispers;
DROP POLICY IF EXISTS "temporary_whispers_legacy_anon_all" ON public.temporary_whispers;

CREATE POLICY "temporary_whispers_select_couple" ON public.temporary_whispers
  FOR SELECT TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "temporary_whispers_insert_couple" ON public.temporary_whispers
  FOR INSERT TO authenticated
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "temporary_whispers_update_couple" ON public.temporary_whispers
  FOR UPDATE TO authenticated
  USING (public.is_couple_member(tether_id))
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "temporary_whispers_delete_couple" ON public.temporary_whispers
  FOR DELETE TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "temporary_whispers_legacy_anon_all" ON public.temporary_whispers
  FOR ALL TO anon
  USING (public.is_legacy_tether(tether_id))
  WITH CHECK (public.is_legacy_tether(tether_id));


-- ──────────────────────────────────────────────────────────────────
-- 8. DAILY_ANSWERS  (tether_id, user_id, question_date, question_index)
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.daily_answers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "daily_answers_read_all"        ON public.daily_answers;
DROP POLICY IF EXISTS "daily_answers_write_all"       ON public.daily_answers;
DROP POLICY IF EXISTS "daily_answers_select_couple"   ON public.daily_answers;
DROP POLICY IF EXISTS "daily_answers_insert_couple"   ON public.daily_answers;
DROP POLICY IF EXISTS "daily_answers_update_couple"   ON public.daily_answers;
DROP POLICY IF EXISTS "daily_answers_delete_couple"   ON public.daily_answers;
DROP POLICY IF EXISTS "daily_answers_legacy_anon_all" ON public.daily_answers;

CREATE POLICY "daily_answers_select_couple" ON public.daily_answers
  FOR SELECT TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "daily_answers_insert_couple" ON public.daily_answers
  FOR INSERT TO authenticated
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "daily_answers_update_couple" ON public.daily_answers
  FOR UPDATE TO authenticated
  USING (public.is_couple_member(tether_id))
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "daily_answers_delete_couple" ON public.daily_answers
  FOR DELETE TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "daily_answers_legacy_anon_all" ON public.daily_answers
  FOR ALL TO anon
  USING (public.is_legacy_tether(tether_id))
  WITH CHECK (public.is_legacy_tether(tether_id));


-- ──────────────────────────────────────────────────────────────────
-- 9. TRIVIA_ANSWERS  (tether_id, user_id, day_key, …)
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.trivia_answers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "trivia_answers_read_all"        ON public.trivia_answers;
DROP POLICY IF EXISTS "trivia_answers_write_all"       ON public.trivia_answers;
DROP POLICY IF EXISTS "trivia_answers_select_couple"   ON public.trivia_answers;
DROP POLICY IF EXISTS "trivia_answers_insert_couple"   ON public.trivia_answers;
DROP POLICY IF EXISTS "trivia_answers_update_couple"   ON public.trivia_answers;
DROP POLICY IF EXISTS "trivia_answers_delete_couple"   ON public.trivia_answers;
DROP POLICY IF EXISTS "trivia_answers_legacy_anon_all" ON public.trivia_answers;

CREATE POLICY "trivia_answers_select_couple" ON public.trivia_answers
  FOR SELECT TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "trivia_answers_insert_couple" ON public.trivia_answers
  FOR INSERT TO authenticated
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "trivia_answers_update_couple" ON public.trivia_answers
  FOR UPDATE TO authenticated
  USING (public.is_couple_member(tether_id))
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "trivia_answers_delete_couple" ON public.trivia_answers
  FOR DELETE TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "trivia_answers_legacy_anon_all" ON public.trivia_answers
  FOR ALL TO anon
  USING (public.is_legacy_tether(tether_id))
  WITH CHECK (public.is_legacy_tether(tether_id));


-- ──────────────────────────────────────────────────────────────────
-- 10. NAUGHTY_QUESTIONS  (tether_id, posted_by, …)
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.naughty_questions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "naughty_questions_read_all"        ON public.naughty_questions;
DROP POLICY IF EXISTS "naughty_questions_write_all"       ON public.naughty_questions;
DROP POLICY IF EXISTS "naughty_questions_select_couple"   ON public.naughty_questions;
DROP POLICY IF EXISTS "naughty_questions_insert_couple"   ON public.naughty_questions;
DROP POLICY IF EXISTS "naughty_questions_update_couple"   ON public.naughty_questions;
DROP POLICY IF EXISTS "naughty_questions_delete_couple"   ON public.naughty_questions;
DROP POLICY IF EXISTS "naughty_questions_legacy_anon_all" ON public.naughty_questions;

CREATE POLICY "naughty_questions_select_couple" ON public.naughty_questions
  FOR SELECT TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "naughty_questions_insert_couple" ON public.naughty_questions
  FOR INSERT TO authenticated
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "naughty_questions_update_couple" ON public.naughty_questions
  FOR UPDATE TO authenticated
  USING (public.is_couple_member(tether_id))
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "naughty_questions_delete_couple" ON public.naughty_questions
  FOR DELETE TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "naughty_questions_legacy_anon_all" ON public.naughty_questions
  FOR ALL TO anon
  USING (public.is_legacy_tether(tether_id))
  WITH CHECK (public.is_legacy_tether(tether_id));


-- ──────────────────────────────────────────────────────────────────
-- 11. NAUGHTY_ANSWERS  (tether_id, question_id, user_id, …)
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.naughty_answers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "naughty_answers_read_all"        ON public.naughty_answers;
DROP POLICY IF EXISTS "naughty_answers_write_all"       ON public.naughty_answers;
DROP POLICY IF EXISTS "naughty_answers_select_couple"   ON public.naughty_answers;
DROP POLICY IF EXISTS "naughty_answers_insert_couple"   ON public.naughty_answers;
DROP POLICY IF EXISTS "naughty_answers_update_couple"   ON public.naughty_answers;
DROP POLICY IF EXISTS "naughty_answers_delete_couple"   ON public.naughty_answers;
DROP POLICY IF EXISTS "naughty_answers_legacy_anon_all" ON public.naughty_answers;

CREATE POLICY "naughty_answers_select_couple" ON public.naughty_answers
  FOR SELECT TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "naughty_answers_insert_couple" ON public.naughty_answers
  FOR INSERT TO authenticated
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "naughty_answers_update_couple" ON public.naughty_answers
  FOR UPDATE TO authenticated
  USING (public.is_couple_member(tether_id))
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "naughty_answers_delete_couple" ON public.naughty_answers
  FOR DELETE TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "naughty_answers_legacy_anon_all" ON public.naughty_answers
  FOR ALL TO anon
  USING (public.is_legacy_tether(tether_id))
  WITH CHECK (public.is_legacy_tether(tether_id));


-- ──────────────────────────────────────────────────────────────────
-- 12. KINK_MATRIX  (tether_id, user_id, item_key, rating)
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.kink_matrix ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "kink_matrix_read_all"        ON public.kink_matrix;
DROP POLICY IF EXISTS "kink_matrix_write_all"       ON public.kink_matrix;
DROP POLICY IF EXISTS "kink_matrix_select_couple"   ON public.kink_matrix;
DROP POLICY IF EXISTS "kink_matrix_insert_couple"   ON public.kink_matrix;
DROP POLICY IF EXISTS "kink_matrix_update_couple"   ON public.kink_matrix;
DROP POLICY IF EXISTS "kink_matrix_delete_couple"   ON public.kink_matrix;
DROP POLICY IF EXISTS "kink_matrix_legacy_anon_all" ON public.kink_matrix;

CREATE POLICY "kink_matrix_select_couple" ON public.kink_matrix
  FOR SELECT TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "kink_matrix_insert_couple" ON public.kink_matrix
  FOR INSERT TO authenticated
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "kink_matrix_update_couple" ON public.kink_matrix
  FOR UPDATE TO authenticated
  USING (public.is_couple_member(tether_id))
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "kink_matrix_delete_couple" ON public.kink_matrix
  FOR DELETE TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "kink_matrix_legacy_anon_all" ON public.kink_matrix
  FOR ALL TO anon
  USING (public.is_legacy_tether(tether_id))
  WITH CHECK (public.is_legacy_tether(tether_id));


-- ──────────────────────────────────────────────────────────────────
-- 13. LOVE_MESSAGES  (tether_id, sender_id, read_at)
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.love_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "love_messages_read_all"        ON public.love_messages;
DROP POLICY IF EXISTS "love_messages_write_all"       ON public.love_messages;
DROP POLICY IF EXISTS "love_messages_select_couple"   ON public.love_messages;
DROP POLICY IF EXISTS "love_messages_insert_couple"   ON public.love_messages;
DROP POLICY IF EXISTS "love_messages_update_couple"   ON public.love_messages;
DROP POLICY IF EXISTS "love_messages_delete_couple"   ON public.love_messages;
DROP POLICY IF EXISTS "love_messages_legacy_anon_all" ON public.love_messages;

CREATE POLICY "love_messages_select_couple" ON public.love_messages
  FOR SELECT TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "love_messages_insert_couple" ON public.love_messages
  FOR INSERT TO authenticated
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "love_messages_update_couple" ON public.love_messages
  FOR UPDATE TO authenticated
  USING (public.is_couple_member(tether_id))
  WITH CHECK (public.is_couple_member(tether_id));

CREATE POLICY "love_messages_delete_couple" ON public.love_messages
  FOR DELETE TO authenticated
  USING (public.is_couple_member(tether_id));

CREATE POLICY "love_messages_legacy_anon_all" ON public.love_messages
  FOR ALL TO anon
  USING (public.is_legacy_tether(tether_id))
  WITH CHECK (public.is_legacy_tether(tether_id));


-- ──────────────────────────────────────────────────────────────────
-- 14. TWO_TRUTHS_ROUNDS  (couple_id ─ alias of tether_id)
--
--   Writes happen via SECURITY DEFINER RPCs (`ttol_insert_round`,
--   `ttol_submit_guess`) which bypass RLS, so we only need a SELECT
--   policy here. We still add an "all" policy for symmetry in case
--   someone later moves to direct INSERT/UPDATE.
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.two_truths_rounds ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "two_truths_rounds_select_couple"   ON public.two_truths_rounds;
DROP POLICY IF EXISTS "two_truths_rounds_insert_couple"   ON public.two_truths_rounds;
DROP POLICY IF EXISTS "two_truths_rounds_update_couple"   ON public.two_truths_rounds;
DROP POLICY IF EXISTS "two_truths_rounds_delete_couple"   ON public.two_truths_rounds;
DROP POLICY IF EXISTS "two_truths_rounds_legacy_anon_all" ON public.two_truths_rounds;

CREATE POLICY "two_truths_rounds_select_couple" ON public.two_truths_rounds
  FOR SELECT TO authenticated
  USING (public.is_couple_member(couple_id));

CREATE POLICY "two_truths_rounds_insert_couple" ON public.two_truths_rounds
  FOR INSERT TO authenticated
  WITH CHECK (public.is_couple_member(couple_id));

CREATE POLICY "two_truths_rounds_update_couple" ON public.two_truths_rounds
  FOR UPDATE TO authenticated
  USING (public.is_couple_member(couple_id))
  WITH CHECK (public.is_couple_member(couple_id));

CREATE POLICY "two_truths_rounds_delete_couple" ON public.two_truths_rounds
  FOR DELETE TO authenticated
  USING (public.is_couple_member(couple_id));

CREATE POLICY "two_truths_rounds_legacy_anon_all" ON public.two_truths_rounds
  FOR ALL TO anon
  USING (public.is_legacy_tether(couple_id))
  WITH CHECK (public.is_legacy_tether(couple_id));


-- ──────────────────────────────────────────────────────────────────
-- 15. PROFILE_DETAILS  (user_id → profiles.id)
--
--   Each profile_details row belongs to ONE profile. We let either
--   couple-member read/write either row, matching the in-app UX
--   (Kyle can edit Nathan's profile too).
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.profile_details ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profile_details_read_all"        ON public.profile_details;
DROP POLICY IF EXISTS "profile_details_write_all"       ON public.profile_details;
DROP POLICY IF EXISTS "profile_details_select_couple"   ON public.profile_details;
DROP POLICY IF EXISTS "profile_details_insert_couple"   ON public.profile_details;
DROP POLICY IF EXISTS "profile_details_update_couple"   ON public.profile_details;
DROP POLICY IF EXISTS "profile_details_delete_couple"   ON public.profile_details;
DROP POLICY IF EXISTS "profile_details_legacy_anon_all" ON public.profile_details;

CREATE POLICY "profile_details_select_couple" ON public.profile_details
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles target
      WHERE target.id = profile_details.user_id
        AND public.is_couple_member(target.tether_id)
    )
  );

CREATE POLICY "profile_details_insert_couple" ON public.profile_details
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles target
      WHERE target.id = profile_details.user_id
        AND public.is_couple_member(target.tether_id)
    )
  );

CREATE POLICY "profile_details_update_couple" ON public.profile_details
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles target
      WHERE target.id = profile_details.user_id
        AND public.is_couple_member(target.tether_id)
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles target
      WHERE target.id = profile_details.user_id
        AND public.is_couple_member(target.tether_id)
    )
  );

CREATE POLICY "profile_details_delete_couple" ON public.profile_details
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles target
      WHERE target.id = profile_details.user_id
        AND public.is_couple_member(target.tether_id)
    )
  );

-- Legacy anon: only profile_details belonging to a profile in a
-- legacy (un-bridged) tether. Falls open if user_id is unknown.
CREATE POLICY "profile_details_legacy_anon_all" ON public.profile_details
  FOR ALL TO anon
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles target
      WHERE target.id = profile_details.user_id
        AND public.is_legacy_tether(target.tether_id)
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles target
      WHERE target.id = profile_details.user_id
        AND public.is_legacy_tether(target.tether_id)
    )
  );


-- ──────────────────────────────────────────────────────────────────
-- 16. APP_CONTENT  (key, value, updated_at)
--
--   GLOBAL app branding/text (NOT per-couple). Everyone needs read
--   access to render the app. Only the app owner ("Kyle") should
--   write — the existing client-side gate is a UI suggestion, not a
--   security boundary, so we enforce it in the DB too.
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.app_content ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "app_content_read_all"     ON public.app_content;
DROP POLICY IF EXISTS "app_content_write_all"    ON public.app_content;
DROP POLICY IF EXISTS "app_content_public_read"  ON public.app_content;
DROP POLICY IF EXISTS "app_content_kyle_write_anon" ON public.app_content;
DROP POLICY IF EXISTS "app_content_kyle_write_auth" ON public.app_content;

CREATE POLICY "app_content_public_read" ON public.app_content
  FOR SELECT TO anon, authenticated USING (true);

-- Anon (legacy): writes allowed only while a legacy "kyle" profile
-- still exists (= pre-migration). Once Kyle migrates to email, this
-- policy stops matching and the auth policy below takes over.
CREATE POLICY "app_content_kyle_write_anon" ON public.app_content
  FOR ALL TO anon
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE LOWER(p.full_name) = 'kyle'
        AND p.auth_user_id IS NULL
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE LOWER(p.full_name) = 'kyle'
        AND p.auth_user_id IS NULL
    )
  );

-- Authenticated: writes only when the signed-in user IS Kyle.
CREATE POLICY "app_content_kyle_write_auth" ON public.app_content
  FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.auth_user_id = auth.uid()
        AND LOWER(p.full_name) = 'kyle'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.auth_user_id = auth.uid()
        AND LOWER(p.full_name) = 'kyle'
    )
  );


-- ════════════════════════════════════════════════════════════════════
-- DONE.
--
-- Coverage summary (see RLS_AUDIT.md for the canonical list):
--
--   per-couple, scoped by tether_id:
--     posts, date_plans, tether_likes, tether_comments,
--     time_capsules, temporary_whispers, daily_answers,
--     trivia_answers, naughty_questions, naughty_answers,
--     kink_matrix, love_messages
--
--   per-couple, scoped indirectly:
--     capsule_reactions  → via parent time_capsules
--     two_truths_rounds  → couple_id (= tether.id)
--     profile_details    → via owning profiles row
--
--   global / admin:
--     app_content        → public read, write only by Kyle
--
-- Storage bucket `avatars` is intentionally PUBLIC (file URLs are
-- shared via getPublicUrl); not hardened here.
-- ════════════════════════════════════════════════════════════════════
