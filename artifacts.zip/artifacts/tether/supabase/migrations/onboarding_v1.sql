-- ════════════════════════════════════════════════════════════════════
-- Tether — Onboarding v1 migration
-- ════════════════════════════════════════════════════════════════════
--   Run this once in your Supabase SQL Editor (project: Tether).
--   Safe / non-destructive: only ADDS columns, policies, and a view.
--   Existing data (Kyle & Nathan's profiles, tether 070425, posts,
--   memories, themes, etc.) is fully preserved.
-- ════════════════════════════════════════════════════════════════════


-- ──────────────────────────────────────────────────────────────────
-- 1. NEW COLUMNS on `tethers` (relationship metadata)
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.tethers
  ADD COLUMN IF NOT EXISTS start_date       date,
  ADD COLUMN IF NOT EXISTS anniversary_date date,
  ADD COLUMN IF NOT EXISTS display_name     text;

COMMENT ON COLUMN public.tethers.start_date
  IS 'When the couple started dating. Used for "X days together" counter.';
COMMENT ON COLUMN public.tethers.anniversary_date
  IS 'Optional formal anniversary (e.g. wedding date). Falls back to start_date.';


-- ──────────────────────────────────────────────────────────────────
-- 2. NEW COLUMNS on `profiles` (per-person data + auth bridge)
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS birthday      date,
  ADD COLUMN IF NOT EXISTS email         text,
  ADD COLUMN IF NOT EXISTS auth_user_id  uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS first_name    text,
  ADD COLUMN IF NOT EXISTS role          text DEFAULT 'member' CHECK (role IN ('primary','member'));

CREATE UNIQUE INDEX IF NOT EXISTS profiles_auth_user_id_unique
  ON public.profiles (auth_user_id) WHERE auth_user_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS profiles_email_idx
  ON public.profiles (lower(email));

COMMENT ON COLUMN public.profiles.auth_user_id
  IS 'Bridge to Supabase Auth. NULL for legacy invite-code-only profiles (Kyle, Nathan pre-migration).';


-- ──────────────────────────────────────────────────────────────────
-- 3. Backfill `first_name` from existing `full_name` (split on space)
--    Safe: only writes where first_name IS NULL.
-- ──────────────────────────────────────────────────────────────────
UPDATE public.profiles
SET first_name = split_part(full_name, ' ', 1)
WHERE first_name IS NULL
  AND full_name IS NOT NULL;


-- ──────────────────────────────────────────────────────────────────
-- 4. `couples` VIEW — spec-compatible alias for `tethers`
--    Lets you write spec-style SQL (couple_id, couples.start_date)
--    without renaming the underlying table the app code depends on.
-- ──────────────────────────────────────────────────────────────────
CREATE OR REPLACE VIEW public.couples AS
SELECT
  id,
  invite_code,
  created_at,
  start_date,
  anniversary_date,
  display_name
FROM public.tethers;


-- ──────────────────────────────────────────────────────────────────
-- 5. RLS — enable on profiles + tethers
--    Policies stay PERMISSIVE for the anon key so the existing
--    custom-auth flow (localStorage profile.id) keeps working.
--    Future tightening: gate writes on auth.uid() = auth_user_id once
--    every active profile has been migrated to Supabase Auth.
-- ──────────────────────────────────────────────────────────────────
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tethers  ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles_read_all"  ON public.profiles;
DROP POLICY IF EXISTS "profiles_write_all" ON public.profiles;
CREATE POLICY "profiles_read_all"  ON public.profiles FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "profiles_write_all" ON public.profiles FOR ALL    TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "tethers_read_all"  ON public.tethers;
DROP POLICY IF EXISTS "tethers_write_all" ON public.tethers;
CREATE POLICY "tethers_read_all"  ON public.tethers FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "tethers_write_all" ON public.tethers FOR ALL    TO anon, authenticated USING (true) WITH CHECK (true);


-- ──────────────────────────────────────────────────────────────────
-- 6. STORAGE — `memories` private bucket + couple-scoped policies
--    File path convention:  <tether_id>/<filename>
--    Only members of that tether can read or upload.
-- ──────────────────────────────────────────────────────────────────
INSERT INTO storage.buckets (id, name, public)
VALUES ('memories', 'memories', false)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "memories_select_couple" ON storage.objects;
DROP POLICY IF EXISTS "memories_insert_couple" ON storage.objects;
DROP POLICY IF EXISTS "memories_delete_couple" ON storage.objects;

-- READ: any authenticated user whose profile.tether_id matches the
-- folder name (first path segment) can view the file.
CREATE POLICY "memories_select_couple"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id = 'memories'
  AND EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.auth_user_id = auth.uid()
      AND p.tether_id::text = (storage.foldername(name))[1]
  )
);

-- INSERT: same gate.
CREATE POLICY "memories_insert_couple"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'memories'
  AND EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.auth_user_id = auth.uid()
      AND p.tether_id::text = (storage.foldername(name))[1]
  )
);

-- DELETE: only your own couple's files.
CREATE POLICY "memories_delete_couple"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id = 'memories'
  AND EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.auth_user_id = auth.uid()
      AND p.tether_id::text = (storage.foldername(name))[1]
  )
);


-- ──────────────────────────────────────────────────────────────────
-- 7. (OPTIONAL) Seed Kyle & Nathan's relationship date
--    Their tether is 070425 (Apr 7, 2025). Uncomment and run after
--    confirming the date is correct.
-- ──────────────────────────────────────────────────────────────────
-- UPDATE public.tethers
-- SET start_date = DATE '2025-04-07'
-- WHERE invite_code = '070425';


-- ════════════════════════════════════════════════════════════════════
-- DONE. Verify with:
--   SELECT id, invite_code, start_date, anniversary_date FROM tethers;
--   SELECT id, full_name, first_name, email, birthday, auth_user_id
--     FROM profiles;
--   SELECT * FROM couples;
-- ════════════════════════════════════════════════════════════════════
