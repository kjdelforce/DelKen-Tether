-- ═══════════════════════════════════════════════════════════
--  Migration 007 — partner_locations
--  Backs the Proximity Pulse feature: each partner upserts
--  their own coarse coordinates every ~30s while the toggle
--  is on; the client computes distance locally and hides
--  everything when the partner has opted out.
--  Adapted to this codebase's tether-membership / profiles
--  RLS pattern (NOT the spec's auth.uid()=user_id, which
--  doesn't apply because profiles.id != auth.uid()).
-- ═══════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS partner_locations (
  id              UUID         NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tether_id       UUID         NOT NULL REFERENCES tethers(id)  ON DELETE CASCADE,
  user_id         UUID         NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  latitude        DOUBLE PRECISION NOT NULL,
  longitude       DOUBLE PRECISION NOT NULL,
  sharing_enabled BOOLEAN      NOT NULL DEFAULT TRUE,
  updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  UNIQUE (tether_id, user_id)
);

CREATE INDEX IF NOT EXISTS partner_locations_tether_idx
  ON partner_locations (tether_id);

ALTER TABLE partner_locations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS partner_locations_select_couple    ON partner_locations;
DROP POLICY IF EXISTS partner_locations_insert_self      ON partner_locations;
DROP POLICY IF EXISTS partner_locations_update_self      ON partner_locations;
DROP POLICY IF EXISTS partner_locations_delete_self      ON partner_locations;
DROP POLICY IF EXISTS partner_locations_legacy_anon_all  ON partner_locations;

-- Members of the same tether read both rows (theirs + partner's).
CREATE POLICY partner_locations_select_couple ON partner_locations
  FOR SELECT
  USING (
    tether_id IN (
      SELECT tether_id FROM profiles WHERE auth_user_id = auth.uid()
    )
  );

-- Each member may only insert / update / delete their own row,
-- and only inside their own tether.
CREATE POLICY partner_locations_insert_self ON partner_locations
  FOR INSERT
  WITH CHECK (
    user_id IN (
      SELECT id FROM profiles WHERE auth_user_id = auth.uid()
    )
    AND tether_id IN (
      SELECT tether_id FROM profiles WHERE auth_user_id = auth.uid()
    )
  );

CREATE POLICY partner_locations_update_self ON partner_locations
  FOR UPDATE
  USING (
    user_id IN (
      SELECT id FROM profiles WHERE auth_user_id = auth.uid()
    )
  );

CREATE POLICY partner_locations_delete_self ON partner_locations
  FOR DELETE
  USING (
    user_id IN (
      SELECT id FROM profiles WHERE auth_user_id = auth.uid()
    )
  );

-- Legacy anon path — Kyle & Nathan's localStorage-only profiles.
-- Same fall-back used by daily_answers / love_notes / etc.
CREATE POLICY partner_locations_legacy_anon_all ON partner_locations
  FOR ALL
  TO anon
  USING (true)
  WITH CHECK (true);
