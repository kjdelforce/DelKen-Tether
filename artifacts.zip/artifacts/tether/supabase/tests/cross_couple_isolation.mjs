// ════════════════════════════════════════════════════════════════════
// Cross-couple isolation test for Tether RLS policies.
//
//   Signs up two fresh test couples (A and B), writes one row per
//   per-couple table as couple A, then signs in as couple B and
//   asserts that none of couple A's rows are visible.
//
// Prerequisites:
//   1. The migrations have been applied to your Supabase project:
//        - onboarding_v1.sql
//        - onboarding_v1_part2_security.sql
//        - onboarding_v1_part3_table_security.sql
//        - migrations/two_truths_rounds.sql
//        - migrations/ttol_functions.sql
//   2. Email confirmations are DISABLED in Supabase Auth settings
//      (Authentication → Providers → Email → "Confirm email" off)
//      so that signUp returns a usable session immediately. If
//      confirmations are on, this test will fail at the signIn
//      step — re-enable confirmations after the test if needed.
//   3. Environment variables:
//        SUPABASE_URL=...        (your project URL)
//        SUPABASE_ANON_KEY=...   (your project's anon/public key)
//
// Run with:
//   node artifacts/tether/supabase/tests/cross_couple_isolation.mjs
//
// The script cleans up after itself: it deletes the rows it inserted
// and signs out both sessions. The test auth users themselves are
// left in place (Supabase doesn't allow deleting auth users from
// the anon key); you can purge them manually from the Auth dashboard
// if you want.
// ════════════════════════════════════════════════════════════════════

import { createClient } from "@supabase/supabase-js";

const URL  = process.env.SUPABASE_URL;
const ANON = process.env.SUPABASE_ANON_KEY;

if (!URL || !ANON) {
  console.error("Missing SUPABASE_URL or SUPABASE_ANON_KEY env vars.");
  process.exit(1);
}

const ts = Date.now();
const userA = { email: `tether-test-a-${ts}@example.com`, password: "Tether-test-pass-1!" };
const userB = { email: `tether-test-b-${ts}@example.com`, password: "Tether-test-pass-1!" };
const inviteA = `T${String(ts).slice(-5)}A`;
const inviteB = `T${String(ts).slice(-5)}B`;

// ── Helpers ───────────────────────────────────────────────────────
function freshClient() {
  return createClient(URL, ANON, { auth: { persistSession: false, autoRefreshToken: false } });
}

let failures = 0;
function expect(cond, label) {
  if (cond) {
    console.log(`  ✓ ${label}`);
  } else {
    console.error(`  ✗ ${label}`);
    failures += 1;
  }
}

async function signUpAndCreateCouple(client, { email, password }, inviteCode) {
  const up = await client.auth.signUp({ email, password });
  if (up.error) throw new Error(`signUp ${email}: ${up.error.message}`);
  const session = up.data.session
    ?? (await client.auth.signInWithPassword({ email, password })).data.session;
  if (!session) throw new Error(`No session for ${email} (email confirmations may be on).`);

  const tetherIns = await client
    .from("tethers")
    .insert({ invite_code: inviteCode, start_date: "2025-01-01" })
    .select()
    .single();
  if (tetherIns.error) throw new Error(`tether insert: ${tetherIns.error.message}`);

  const profileIns = await client
    .from("profiles")
    .insert({
      full_name: `Test ${email}`,
      first_name: "Test",
      email,
      auth_user_id: session.user.id,
      tether_id: tetherIns.data.id,
      role: "primary",
    })
    .select()
    .single();
  if (profileIns.error) throw new Error(`profile insert: ${profileIns.error.message}`);

  return { session, tether: tetherIns.data, profile: profileIns.data };
}

// ── Set-up ────────────────────────────────────────────────────────
const clientA = freshClient();
const clientB = freshClient();

console.log("→ Signing up couple A and couple B...");
const A = await signUpAndCreateCouple(clientA, userA, inviteA);
const B = await signUpAndCreateCouple(clientB, userB, inviteB);
console.log(`  A.tether=${A.tether.id}  B.tether=${B.tether.id}`);

// ── Seed couple A with one row per per-couple table ───────────────
const today = new Date().toISOString().slice(0, 10);
const futureIso = new Date(Date.now() + 86400000).toISOString();

console.log("→ Seeding couple A's data...");

const seeds = [
  ["posts", { tether_id: A.tether.id, author_id: A.profile.id, post_type: "note", content: "A-secret-post" }],
  ["date_plans", { tether_id: A.tether.id, title: "A-secret-plan", is_completed: false }],
  ["love_messages", { tether_id: A.tether.id, sender_id: A.profile.id }],
  ["temporary_whispers", { tether_id: A.tether.id, sender_id: A.profile.id, message: "A-whisper" }],
  ["daily_answers", { tether_id: A.tether.id, user_id: A.profile.id, question_date: today, question_index: 0, answer_text: "A-answer" }],
  ["trivia_answers", { tether_id: A.tether.id, user_id: A.profile.id, week_key: "2026-W01", answer: "A-trivia" }],
  ["naughty_questions", { tether_id: A.tether.id, posted_by: A.profile.id, question_text: "A-question", expires_at: futureIso }],
  ["kink_matrix", { tether_id: A.tether.id, user_id: A.profile.id, item_key: "test-item", rating: "yes" }],
];

const seededIds = {};
for (const [table, payload] of seeds) {
  const ins = await clientA.from(table).insert(payload).select().maybeSingle();
  if (ins.error) {
    console.warn(`    ! ${table}: skipped (${ins.error.message})`);
    continue;
  }
  seededIds[table] = ins.data.id;
  console.log(`    + ${table}: ${ins.data.id}`);
}

// time_capsules + capsule_reactions (need to seed in order)
const capIns = await clientA.from("time_capsules").insert({
  tether_id: A.tether.id,
  sender_id: A.profile.id,
  title: "A-capsule",
  message: "A-capsule-msg",
  unlock_type: "date",
  unlock_at: futureIso,
  unlocked: false,
}).select().maybeSingle();
if (capIns.error) {
  console.warn(`    ! time_capsules: skipped (${capIns.error.message})`);
} else {
  seededIds.time_capsules = capIns.data.id;
  console.log(`    + time_capsules: ${capIns.data.id}`);
  const rxIns = await clientA.from("capsule_reactions").insert({
    capsule_id: capIns.data.id,
    user_id: A.profile.id,
    reaction: "❤️",
  }).select().maybeSingle();
  if (rxIns.error) {
    console.warn(`    ! capsule_reactions: skipped (${rxIns.error.message})`);
  } else {
    seededIds.capsule_reactions = rxIns.data.id;
    console.log(`    + capsule_reactions: ${rxIns.data.id}`);
  }
}

// two_truths_rounds via the SECURITY DEFINER RPC (writes bypass RLS).
const ttolIns = await clientA.rpc("ttol_insert_round", {
  p_couple_id:   A.tether.id,
  p_writer_id:   A.profile.id,
  p_guesser_id:  A.profile.id,
  p_statement_1: "A-truth-1",
  p_statement_2: "A-truth-2",
  p_statement_3: "A-lie",
  p_lie_index:   2,
});
if (ttolIns.error) {
  console.warn(`    ! two_truths_rounds: skipped (${ttolIns.error.message})`);
} else {
  seededIds.two_truths_rounds = ttolIns.data;
  console.log(`    + two_truths_rounds: ${ttolIns.data}`);
}

// profile_details for A's profile
const pdIns = await clientA.from("profile_details").upsert({
  user_id: A.profile.id,
  vibe_text: "A-secret-vibe",
}, { onConflict: "user_id" }).select().maybeSingle();
if (pdIns.error) {
  console.warn(`    ! profile_details: skipped (${pdIns.error.message})`);
} else {
  seededIds.profile_details = pdIns.data.user_id;
  console.log(`    + profile_details: ${pdIns.data.user_id}`);
}

// ── Switch to couple B and try to read couple A's data ────────────
console.log("\n→ Asserting couple B cannot see couple A's rows...");

const tablesByTether = [
  "posts", "date_plans", "love_messages", "temporary_whispers",
  "daily_answers", "trivia_answers", "naughty_questions",
  "kink_matrix", "time_capsules",
];
for (const table of tablesByTether) {
  const r = await clientB.from(table).select("id").eq("tether_id", A.tether.id);
  if (r.error) {
    console.warn(`  ? ${table}: query errored (${r.error.message}) — treating as blocked`);
    continue;
  }
  expect((r.data ?? []).length === 0, `${table}: B sees 0 of A's rows (got ${r.data.length})`);
}

// two_truths_rounds (couple_id)
{
  const r = await clientB.from("two_truths_rounds").select("id").eq("couple_id", A.tether.id);
  if (r.error) {
    console.warn(`  ? two_truths_rounds: query errored (${r.error.message}) — treating as blocked`);
  } else {
    expect((r.data ?? []).length === 0, `two_truths_rounds: B sees 0 of A's rows (got ${r.data.length})`);
  }
}

// capsule_reactions (scoped via parent capsule)
{
  const r = await clientB.from("capsule_reactions").select("id");
  if (r.error) {
    console.warn(`  ? capsule_reactions: query errored (${r.error.message}) — treating as blocked`);
  } else {
    const hit = (r.data ?? []).some(row => row.id === seededIds.capsule_reactions);
    expect(!hit, `capsule_reactions: B cannot see A's reaction row`);
  }
}

// profile_details (scoped via owning profile)
{
  const r = await clientB.from("profile_details").select("user_id").eq("user_id", A.profile.id);
  if (r.error) {
    console.warn(`  ? profile_details: query errored (${r.error.message}) — treating as blocked`);
  } else {
    expect((r.data ?? []).length === 0, `profile_details: B cannot see A's detail row`);
  }
}

// profiles: B should NOT see A's profile row
{
  const r = await clientB.from("profiles").select("id").eq("id", A.profile.id);
  if (r.error) {
    console.warn(`  ? profiles: query errored (${r.error.message}) — treating as blocked`);
  } else {
    expect((r.data ?? []).length === 0, `profiles: B cannot see A's profile row`);
  }
}

// Sanity: B CAN still see B's OWN data (not over-locked)
{
  const r = await clientB.from("profiles").select("id").eq("id", B.profile.id);
  expect(!r.error && (r.data ?? []).length === 1, `profiles: B can still see B's own profile row`);
}

// ── Cleanup ───────────────────────────────────────────────────────
console.log("\n→ Cleaning up seeded rows...");
// Couple A is the only one with permission to delete A's rows.
for (const [table, id] of Object.entries(seededIds)) {
  if (table === "profile_details") {
    await clientA.from(table).delete().eq("user_id", id);
  } else {
    await clientA.from(table).delete().eq("id", id);
  }
}
await clientA.from("profiles").delete().eq("id", A.profile.id);
await clientA.from("tethers").delete().eq("id", A.tether.id);
await clientB.from("profiles").delete().eq("id", B.profile.id);
await clientB.from("tethers").delete().eq("id", B.tether.id);

await clientA.auth.signOut();
await clientB.auth.signOut();

console.log("");
if (failures === 0) {
  console.log("✅ ALL CHECKS PASSED — couples are isolated.");
  process.exit(0);
} else {
  console.error(`❌ ${failures} CHECK(S) FAILED — couple data is LEAKING. Investigate before publishing.`);
  process.exit(1);
}
